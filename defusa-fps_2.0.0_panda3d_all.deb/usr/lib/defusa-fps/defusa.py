#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Defusa FPS - shooter estilo Counter-Strike 1.6 (modo desactivar bomba) con LAN y bots.

Terroristas (T) plantan la bomba en el sitio A o B; Antiterroristas (CT) la desactivan.
Servidor autoritativo por UDP (puerto 27015). Descubrimiento LAN por broadcast.
"""
import argparse
import json
import math
import struct
import fcntl
import os
import random
import socket
import sys
import time
import zlib
import re
import shutil
import subprocess
import tempfile
import urllib.request
import urllib.error
from collections import deque

try:
    import r3d
except Exception:      # el servidor sin gráficos no necesita numpy
    r3d = None

VERSION = "2.0.0"


# Actualizador automático desde GitHub.
UPDATE_OWNER = "salessandroval"
UPDATE_REPO = "Defusa-FPS"
UPDATE_BRANCH = "main"
UPDATE_API = "https://api.github.com/repos/%s/%s/contents/?ref=%s" % (UPDATE_OWNER, UPDATE_REPO, UPDATE_BRANCH)
UPDATE_TIMEOUT = 8


def _version_key(v):
    """Convierte una versión x.y.z en una tupla comparable."""
    nums = re.findall(r"\d+", str(v))
    return tuple(int(x) for x in nums[:4]) or (0,)


def _github_latest_deb():
    req = urllib.request.Request(
        UPDATE_API,
        headers={"User-Agent": "Defusa-FPS/%s" % VERSION, "Accept": "application/vnd.github+json"},
    )
    with urllib.request.urlopen(req, timeout=UPDATE_TIMEOUT) as r:
        data = json.loads(r.read().decode("utf-8"))
    candidates = []
    for item in data if isinstance(data, list) else []:
        name = item.get("name", "")
        m = re.match(r"^defusa-fps_([0-9][0-9A-Za-z.~-]*)_all\.deb$", name)
        if not m:
            continue
        version = m.group(1)
        url = item.get("download_url")
        if url:
            candidates.append((version, name, url))
    if not candidates:
        return None
    return max(candidates, key=lambda x: _version_key(x[0]))


def _install_deb(path):
    """Instala el .deb mediante pkexec para que Debian solicite contraseña gráficamente."""
    env = os.environ.copy()
    env["DEBIAN_FRONTEND"] = "noninteractive"
    commands = []
    if shutil.which("pkexec"):
        commands.append(["pkexec", "apt-get", "install", "-y", path])
    if shutil.which("sudo"):
        commands.append(["sudo", "-n", "apt-get", "install", "-y", path])
    for cmd in commands:
        try:
            p = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=180)
            if p.returncode == 0:
                return True
        except (OSError, subprocess.SubprocessError):
            pass
    return False


def check_for_updates(silent=True):
    """Comprueba e instala automáticamente la versión superior disponible en GitHub."""
    try:
        latest = _github_latest_deb()
        if not latest:
            return False
        remote_version, filename, url = latest
        if _version_key(remote_version) <= _version_key(VERSION):
            return False

        fd, path = tempfile.mkstemp(prefix="defusa-update-", suffix=".deb")
        os.close(fd)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Defusa-FPS/%s" % VERSION})
            with urllib.request.urlopen(req, timeout=30) as r, open(path, "wb") as f:
                shutil.copyfileobj(r, f)
            if os.path.getsize(path) < 1024:
                return False
            if not _install_deb(path):
                return False
            return True
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, ValueError, json.JSONDecodeError):
        return False
PORT = 27015
TICK = 1.0 / 60.0
SNAP_HZ = 20
MAX_HUMANS = 8

# ---------------------------------------------------------------- reglas
FREEZE_T = 3.0
ROUND_T = 100.0
OVER_T = 5.0
PLANT_T = 3.0
DEFUSE_T = 5.0
BOMB_T = 35.0
WIN_ROUNDS = 7
SPEED = 3.4
TURN_BOT = 2.8
START_MONEY = 800
MAX_MONEY = 16000
ARMOR_PRICE = 650
KIT_PRICE = 200
BUY_WINDOW = 15.0
WEAPONS = {
    # Pistolas
    "usp": dict(name="USP", price=0, team="C", slot=2, dmg=20, cd=0.15, mag=12, reload=1.6, spread=0.010, move=0.035, pellets=1),
    "glock": dict(name="Glock-18", price=400, team="T", slot=2, dmg=18, cd=0.15, mag=20, reload=2.2, spread=0.018, move=0.040, pellets=1),
    "p228": dict(name="P228", price=600, team=None, slot=2, dmg=32, cd=0.20, mag=13, reload=2.0, spread=0.014, move=0.038, pellets=1),
    "deagle": dict(name="Desert Eagle", price=650, team=None, slot=2, dmg=46, cd=0.33, mag=7, reload=2.0, spread=0.008, move=0.04, pellets=1),
    "fiveseven": dict(name="Five-SeveN", price=750, team="C", slot=2, dmg=22, cd=0.15, mag=20, reload=2.2, spread=0.018, move=0.038, pellets=1),
    "elite": dict(name="Dual Berettas", price=800, team="T", slot=2, dmg=23, cd=0.14, mag=30, reload=2.6, spread=0.025, move=0.045, pellets=1),
    # Escopetas y SMG
    "m3": dict(name="Escopeta M3", price=1700, team=None, slot=1, dmg=11, cd=0.85, mag=8, reload=2.6, spread=0.07, move=0.02, pellets=8),
    "xm1014": dict(name="XM1014", price=3000, team=None, slot=1, dmg=9, cd=0.35, mag=7, reload=2.5, spread=0.075, move=0.025, pellets=8),
    "tmp": dict(name="TMP", price=1250, team="C", slot=1, dmg=14, cd=0.065, mag=30, reload=2.1, spread=0.032, move=0.035, pellets=1),
    "mac10": dict(name="MAC-10", price=1400, team="T", slot=1, dmg=17, cd=0.075, mag=30, reload=2.4, spread=0.035, move=0.04, pellets=1),
    "mp5": dict(name="MP5", price=1500, team=None, slot=1, dmg=17, cd=0.075, mag=30, reload=2.2, spread=0.028, move=0.03, pellets=1),
    "ump45": dict(name="UMP-45", price=1700, team=None, slot=1, dmg=20, cd=0.105, mag=25, reload=2.3, spread=0.032, move=0.035, pellets=1),
    "p90": dict(name="P90", price=2350, team=None, slot=1, dmg=17, cd=0.055, mag=50, reload=3.0, spread=0.035, move=0.035, pellets=1),
    # Rifles
    "galil": dict(name="Galil", price=2000, team="T", slot=1, dmg=27, cd=0.105, mag=35, reload=2.5, spread=0.025, move=0.042, pellets=1),
    "famas": dict(name="FAMAS", price=2250, team="C", slot=1, dmg=25, cd=0.105, mag=25, reload=2.4, spread=0.024, move=0.040, pellets=1),
    "ak47": dict(name="AK-47", price=2500, team="T", slot=1, dmg=28, cd=0.10, mag=30, reload=2.4, spread=0.020, move=0.04, pellets=1),
    "m4a1": dict(name="M4A1", price=3100, team="C", slot=1, dmg=24, cd=0.09, mag=30, reload=2.3, spread=0.014, move=0.035, pellets=1),
    "sg552": dict(name="SG 552", price=3500, team="T", slot=1, dmg=27, cd=0.09, mag=30, reload=2.4, spread=0.018, move=0.038, pellets=1),
    "aug": dict(name="AUG", price=3500, team="C", slot=1, dmg=28, cd=0.09, mag=30, reload=2.4, spread=0.016, move=0.035, pellets=1),
    # Francotiradores / pesada
    "scout": dict(name="Scout", price=2750, team=None, slot=1, dmg=75, cd=1.1, mag=10, reload=2.8, spread=0.006, move=0.10, pellets=1),
    "awp": dict(name="AWP", price=4750, team=None, slot=1, dmg=115, cd=1.4, mag=10, reload=3.0, spread=0.002, move=0.12, pellets=1),
    "g3sg1": dict(name="G3SG1", price=5000, team="T", slot=1, dmg=80, cd=0.25, mag=20, reload=3.2, spread=0.020, move=0.10, pellets=1),
    "sg550": dict(name="SG 550", price=4200, team="C", slot=1, dmg=80, cd=0.25, mag=30, reload=3.2, spread=0.020, move=0.10, pellets=1),
    "m249": dict(name="M249", price=5750, team=None, slot=1, dmg=32, cd=0.08, mag=100, reload=4.0, spread=0.035, move=0.07, pellets=1),
    # Cuchillo: siempre disponible, sin munición y con ataque cuerpo a cuerpo.
    "knife": dict(name="Cuchillo", price=0, team=None, slot=3, dmg=55, cd=0.45, mag=0, reload=0.0, spread=0.0, move=0.0, pellets=1, melee=True, range=1.65),
}

WEAPON_ORDER = list(WEAPONS)

# ---------------------------------------------------------------- mapas
# Cada mapa conserva las mismas dimensiones (32x24) para que el motor 3D,
# el raycasting y el minimapa sigan funcionando sin cambios estructurales.
# Lo que cambia entre mapas es la disposicion de paredes, cajas, sitios y
# spawns, lo que se traduce en tacticas distintas para cada arena.
W, H = 32, 24


def _rect(g, x0, y0, x1, y1, v=1):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            g[y][x] = v


class MapDef:
    """Definicion de un mapa de bomba.

    Atributos publicos:
      name  - identificador corto (de_dust2, de_aztec, ...)
      title - nombre legible para menus y HUD
      theme - clave de paleta/textura usada por el motor 3D
      grid  - matriz [H][W] con 0=vacio, 1=pared, 2=caja
      sites - {"A": (x0,y0,x1,y1), "B": (x0,y0,x1,y1)}
      spawns- {"T": [(x,y)...], "C": [(x,y)...]}
      site_cells - celdas libres dentro de cada sitio (precalculado)
    """

    def __init__(self, name, title, theme, grid, sites, spawns):
        self.name = name
        self.title = title
        self.theme = theme
        self.W, self.H = W, H
        self.grid = grid
        self.sites = dict(sites)
        # Filtra celdas bloqueadas de los spawns por seguridad: si un mapa
        # define un spawn que cae sobre una pared/caja, se ignora en lugar
        # de atrapar al jugador dentro del muro al reaparecer.
        self.spawns = {
            k: [(x, y) for (x, y) in v if 0 <= x < W and 0 <= y < H and grid[y][x] == 0]
            for k, v in spawns.items()
        }
        self.site_cells = {
            k: [(x, y) for x in range(r[0], r[2] + 1) for y in range(r[1], r[3] + 1)
                if self.grid[y][x] == 0]
            for k, r in self.sites.items()
        }

    def site_at(self, x, y):
        for k, (x0, y0, x1, y1) in self.sites.items():
            if x0 <= x < x1 + 1 and y0 <= y < y1 + 1:
                return k
        return None


# ---- Constructores de cada mapa --------------------------------------------

def _border(g):
    _rect(g, 0, 0, W - 1, 0); _rect(g, 0, H - 1, W - 1, H - 1)
    _rect(g, 0, 0, 0, H - 1); _rect(g, W - 1, 0, W - 1, H - 1)


def _build_dust2():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Calles en T, balcones laterales y patio central
    for y in range(3,21):
        if y not in (8,9,14,15): g[y][9]=1
        if y not in (5,6,17,18): g[y][22]=1
    for x in range(3,29):
        if x not in (12,13,18,19): g[11][x]=1
    for x,y in ((5,5),(6,5),(25,18),(26,18),(14,7),(17,16),(12,19),(19,4)):
        g[y][x]=2
    return g


def _build_aztec():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Templo con patio interior, columnas y agua
    _rect(g,11,7,20,16,1); _rect(g,13,9,18,14,0)
    g[8][15]=g[8][16]=0; g[15][15]=g[15][16]=0
    for x,y in ((7,5),(7,18),(24,5),(24,18),(10,11),(21,12)): g[y][x]=1
    for x,y in ((4,9),(5,9),(26,14),(27,14),(8,20),(23,3)): g[y][x]=2
    # puentes estrechos
    for x in range(2,11):
        if x not in (5,6): g[11][x]=1
    for x in range(21,30):
        if x not in (25,26): g[12][x]=1
    return g


def _build_nuke():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Dos plantas simuladas: corredores, salas y reactor central
    _rect(g,5,3,11,7,1); _rect(g,20,3,26,7,1)
    _rect(g,5,16,11,20,1); _rect(g,20,16,26,20,1)
    for y in range(8,16):
        if y not in (10,11,14): g[y][12]=1
        if y not in (9,10,13): g[y][19]=1
    _rect(g,14,9,17,14,1); _rect(g,15,10,16,13,0)
    for x,y in ((13,8),(18,8),(13,15),(18,15),(8,10),(23,13)): g[y][x]=2
    return g


def _build_inferno():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Barrio: calle central, casas irregulares y dos plazas
    for x in range(3,29):
        if x not in (8,9,15,16,22,23): g[12][x]=1
    _rect(g,4,3,9,8,1); _rect(g,22,15,27,20,1)
    _rect(g,12,3,14,7,1); _rect(g,17,16,19,20,1)
    for x,y in ((5,10),(7,10),(24,10),(26,10),(11,15),(20,8),(14,18),(17,5)): g[y][x]=2
    return g


def _build_mirage():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Palacio en L y plaza abierta con rampas de cobertura
    _rect(g,4,3,10,9,1); _rect(g,21,14,27,20,1)
    _rect(g,5,15,8,20,1); _rect(g,23,3,27,8,1)
    for y in range(5,19):
        if y not in (8,9,15,16): g[y][15]=1
        if y not in (11,12): g[y][18]=1
    for x,y in ((12,6),(13,6),(20,17),(21,17),(10,13),(23,11),(15,20),(18,3)): g[y][x]=2
    return g


def _build_cache():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Complejo industrial: almacenes, contenedores y patio de carga
    _rect(g,4,3,11,8,1); _rect(g,20,15,27,20,1)
    for y in range(4,8):
        if y not in (5,7): g[y][12]=1
    for y in range(16,20):
        if y not in (17,19): g[y][19]=1
    for x,y in ((13,8),(14,8),(17,15),(18,15),(13,12),(14,12),(17,11),(18,11),(6,12),(25,11)): g[y][x]=2
    return g


def _build_overpass():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Dos niveles visuales: pilares, carretera y refugios bajo puente
    for x in (6,7,24,25):
        _rect(g,x,4,x+1,8,1); _rect(g,x,15,x+1,19,1)
    for x in range(9,24):
        if x not in (13,14,19,20): g[10][x]=1
    for x in range(9,24):
        if x not in (11,12,17,18): g[13][x]=1
    for x,y in ((4,11),(8,14),(23,9),(27,12),(15,7),(16,16)): g[y][x]=2
    return g


def _build_train():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Tres filas de vagones y cruces transversales
    for x0,x1 in ((5,9),(14,18),(23,27)):
        _rect(g,x0,3,x1,8,1); _rect(g,x0,15,x1,20,1)
        for y in (4,7,16,19):
            g[y][x0]=g[y][x1]=0
    for x,y in ((11,10),(12,10),(20,13),(21,13),(4,12),(27,11),(14,5),(18,18)): g[y][x]=2
    for y in (9,14):
        for x in range(10,23):
            if x not in (13,14,18,19): g[y][x]=1
    return g


# ---- Registro y mapa activo -----------------------------------------------

def _make_maps():
    out=[]
    specs=[
      ("de_dust2","Dust II","desert",_build_dust2,{"A":(2,2,8,6),"B":(23,17,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_aztec","Aztec","temple",_build_aztec,{"A":(2,2,7,6),"B":(24,17,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(15,21)],"C":[(x,y) for x in range(27,31) for y in range(2,8)]}),
      ("de_nuke","Nuke","reactor",_build_nuke,{"A":(13,2,18,7),"B":(13,16,18,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_inferno","Inferno","town",_build_inferno,{"A":(1,2,9,9),"B":(22,14,30,21)}, {"T":[(x,y) for x in range(1,5) for y in range(14,21)],"C":[(x,y) for x in range(27,31) for y in range(2,9)]}),
      ("de_mirage","Mirage","palace",_build_mirage,{"A":(8,2,16,7),"B":(15,16,23,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_cache","Cache","warehouse",_build_cache,{"A":(2,2,8,7),"B":(23,16,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_overpass","Overpass","highway",_build_overpass,{"A":(2,3,8,7),"B":(23,16,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(14,21)],"C":[(x,y) for x in range(27,31) for y in range(2,9)]}),
      ("de_train","Train","rail",_build_train,{"A":(2,2,6,7),"B":(25,16,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
    ]
    for name,title,theme,builder,sites,spawns in specs: out.append((name,MapDef(name,title,theme,builder(),sites,spawns)))
    return dict(out)


MAPS = _make_maps()
MAP_ORDER = ["de_dust2", "de_aztec", "de_nuke", "de_inferno", "de_mirage", "de_cache", "de_overpass", "de_train"]
ACTIVE_MAP = MAPS["de_dust2"]

# Espejos module-level: el resto del codigo sigue usando W, H, GRID, SITES,
# SPAWNS y SITE_CELLS como antes. Cuando se cambia de mapa, estos se
# reasignan y todas las funciones (cast, bfs, solid, minimapa, etc.)
# reflejan el mapa actual sin mas cambios.
GRID = ACTIVE_MAP.grid
SITES = ACTIVE_MAP.sites
SPAWNS = ACTIVE_MAP.spawns
SITE_CELLS = ACTIVE_MAP.site_cells


def set_active_map(name):
    """Cambia el mapa activo y actualiza los espejos module-level."""
    global ACTIVE_MAP, GRID, SITES, SPAWNS, SITE_CELLS
    m = MAPS.get(name) or MAPS[MAP_ORDER[0]]
    ACTIVE_MAP = m
    GRID = m.grid
    SITES = m.sites
    SPAWNS = m.spawns
    SITE_CELLS = m.site_cells
    return m


def site_at(x, y):
    return ACTIVE_MAP.site_at(x, y)


def solid(x, y):
    ix, iy = int(math.floor(x)), int(math.floor(y))
    return not (0 <= ix < W and 0 <= iy < H) or GRID[iy][ix] != 0


def blocked(x, y, r=0.25):
    return solid(x - r, y - r) or solid(x + r, y - r) or solid(x - r, y + r) or solid(x + r, y + r)


def cast(x, y, dx, dy, maxd=40.0):
    """DDA. (dx,dy) unitario. Devuelve (distancia, lado, valor_celda, fraccion_en_pared)."""
    mx, my = int(math.floor(x)), int(math.floor(y))
    ddx = abs(1.0 / dx) if dx else 1e30
    ddy = abs(1.0 / dy) if dy else 1e30
    if dx < 0:
        sx, sdx = -1, (x - mx) * ddx
    else:
        sx, sdx = 1, (mx + 1 - x) * ddx
    if dy < 0:
        sy, sdy = -1, (y - my) * ddy
    else:
        sy, sdy = 1, (my + 1 - y) * ddy
    side = 0
    while True:
        if sdx < sdy:
            d = sdx
            sdx += ddx
            mx += sx
            side = 0
        else:
            d = sdy
            sdy += ddy
            my += sy
            side = 1
        if d > maxd:
            return maxd, side, 0, 0.0
        if not (0 <= mx < W and 0 <= my < H):
            return d, side, 1, 0.0
        v = GRID[my][mx]
        if v:
            wx = (y + d * dy) if side == 0 else (x + d * dx)
            return d, side, v, wx - math.floor(wx)


def bfs(start, goal):
    if start == goal:
        return []
    prev = {start: None}
    dq = deque([start])
    while dq:
        c = dq.popleft()
        if c == goal:
            break
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (c[0] + dx, c[1] + dy)
            if n not in prev and 0 <= n[0] < W and 0 <= n[1] < H and GRID[n[1]][n[0]] == 0:
                prev[n] = c
                dq.append(n)
    if goal not in prev:
        return []
    path, c = [], goal
    while c != start:
        path.append(c)
        c = prev[c]
    path.reverse()
    return path


def angdiff(a, b):
    d = (a - b + math.pi) % (2 * math.pi) - math.pi
    return d


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


# ---------------------------------------------------------------- simulación
class P:
    def __init__(self, pid, name, team, bot):
        self.id = pid
        self.name = name[:12]
        self.team = team
        self.bot = bot
        self.x = self.y = 1.5
        self.a = 0.0
        self.hp = 100
        self.alive = False
        self.money = START_MONEY
        self.armor = 0.0
        self.kit = False
        self.slots = {1: None, 2: ("glock" if team == "T" else "usp"), 3: "knife"}
        self.cur = 2
        self.mags = {"usp": WEAPONS["usp"]["mag"], "glock": WEAPONS["glock"]["mag"], "knife": 0}
        self.last_bq = 0
        self.last_wq = 0
        self.rel = 0.0
        self.cd = 0.0
        self.kills = 0
        self.deaths = 0
        self.headshots = 0
        self.inp = {"f": 0, "s": 0, "a": 0.0, "fire": False, "use": False, "rel": False,
                    "wq": 0, "w": 2, "bq": 0, "bi": ""}
        self.prog = 0.0
        self.has_bomb = False
        self.moving = False
        self.seen = time.time()
        # La habilidad del bot se mantiene en el rango historicamente suave
        # (0.24-0.62) para que la mejora de la IA sea tactica y no unfair:
        # los bots siguen fallando tiros, reaccionando con retardo y
        # disparando en rfagas cortas. Lo que cambia en 1.7 es la calidad
        # de las decisiones (defensa de sitio, recarga segura, cambio a
        # pistola, memoria de posicion, etc.).
        skill = random.uniform(0.24, 0.62)
        role = random.choice(("rush", "lurk", "anchor")) if bot else "human"
        self.ai = {"think": random.random() * 0.35, "target": None, "react": 0.0, "path": [],
                   "site": random.choice("AB"), "spot": (16, 4), "strafe_t": 0.0, "sd": 0,
                   "skill": skill, "aim_error": random.uniform(0.11, 0.24), "lost": 0.0,
                   "burst": random.randint(1, 4), "burst_left": 0, "pause": random.uniform(0.0, 0.5),
                   "last_seen": 0.0, "last_weapon": None,
                   # Nuevos campos 1.7: memoria, economia, rol y retreat.
                   "last_pos": None,            # (x, y, t) ultima posicion conocida del enemigo
                   "last_pos_t": -10.0,         # instante en que se registro
                   "role": role,                # rush / lurk / anchor (solo bots)
                   "save_until": 0,             # rondas de "eco" pendientes
                   "retreat": 0.0,              # temporizador de retirada cuando hp baja
                   "peek_t": 0.0,               # pequenas pausas antes de asomar a un angulo
                   "want_pistol": False}        # forzar cambio a pistola si primaria vacia

    def wname(self):
        return self.slots.get(self.cur) or self.slots[2]

    @property
    def ammo(self):
        return self.mags.get(self.wname(), 0)


class World:
    def __init__(self, team_size=4, start_map=None):
        self.players = {}
        self.next_id = 0
        self.team_size = team_size
        self.score = {"T": 0, "C": 0}
        self.round = 0
        self.phase = "wait"
        self.timer = 0.0
        self.msg = "Esperando jugadores..."
        self.match_over = False
        self.bomb = {"state": "none", "x": 0.0, "y": 0.0, "t": 0.0, "carrier": -1}
        self.ev = []
        self.evseq = 0
        self.feed = []
        self.clock = 0.0
        self.streak = {"T": 0, "C": 0}
        self.paused = False
        # Ciclo de mapas: el World guarda el indice actual dentro de MAP_ORDER
        # y avanza solo cuando termina una partida (WIN_ROUNDS alcanzados).
        # El modulo se sincroniza con set_active_map() para que el motor 3D
        # y el minimapa muestren el mapa correcto.
        self.map_index = 0
        if start_map in MAPS:
            self.map_index = MAP_ORDER.index(start_map)
        set_active_map(MAP_ORDER[self.map_index])
        self.map_name = MAP_ORDER[self.map_index]

    def current_map(self):
        return MAPS[self.map_name]

    def cycle_map(self):
        """Avanza al siguiente mapa del ciclo y reinicia el marcador."""
        self.map_index = (self.map_index + 1) % len(MAP_ORDER)
        self.map_name = MAP_ORDER[self.map_index]
        set_active_map(self.map_name)
        self.score = {"T": 0, "C": 0}
        self.streak = {"T": 0, "C": 0}
        self.round = 0
        for p in self.players.values():
            p.kills = p.deaths = p.headshots = 0
            p.money = START_MONEY
            # Reinicia decisiones de compra: el nuevo mapa puede tener
            # economia distinta y queremos que los bots recomiencen.
            p.ai["last_weapon"] = None
            p.ai["save_until"] = 0
            p.ai["last_pos"] = None
            p.ai["last_pos_t"] = -10.0
        self.msg = "Cambiando a mapa: %s" % MAPS[self.map_name].title

    # -- jugadores
    def count(self, team, humans_only=False):
        return sum(1 for p in self.players.values() if p.team == team and (not humans_only or not p.bot))

    def add_player(self, name, team, bot=False):
        pid = self.next_id
        self.next_id += 1
        self.players[pid] = P(pid, name, team, bot)
        return pid

    def remove_player(self, pid):
        p = self.players.pop(pid, None)
        if p and p.has_bomb and p.alive:
            self.drop_bomb(p)

    def balance_bots(self):
        names = ["Ivan", "Pablo", "Luis", "Marta", "Dani", "Rex", "Kira", "Toni", "Sofi", "Max"]
        for team in ("T", "C"):
            humans = self.count(team, True)
            want = max(0, self.team_size - humans) if self.team_size > 0 else 0
            bots = [p for p in self.players.values() if p.team == team and p.bot]
            while len(bots) > want:
                self.players.pop(bots.pop().id)
            while len(bots) < want:
                nm = "[BOT] " + random.choice(names)
                pid = self.add_player(nm, team, True)
                bots.append(self.players[pid])

    def add_event(self, typ, x, y, pid=-1):
        self.evseq += 1
        self.ev.append([self.evseq, typ, round(x, 1), round(y, 1), pid])
        self.ev = self.ev[-8:]

    # -- rondas
    def new_round(self):
        self.balance_bots()
        if not (self.count("T") and self.count("C")):
            self.phase = "wait"
            self.msg = "Esperando jugadores..."
            return
        # Asegura que el modulo refleja self.map_name (pudo haberse
        # cambiado desde el menu antes de la primera ronda).
        if MAPS[self.map_name] is not ACTIVE_MAP:
            set_active_map(self.map_name)
        fresh = self.round == 0
        self.round += 1
        for team in ("T", "C"):
            cells = SPAWNS[team][:]
            random.shuffle(cells)
            for p in [q for q in self.players.values() if q.team == team]:
                cx, cy = cells.pop()
                p.x, p.y = cx + 0.5, cy + 0.5
                p.a = 0.0 if team == "T" else math.pi
                if fresh:
                    p.money = START_MONEY
                if fresh or not p.alive:
                    p.slots, p.armor, p.kit = {1: None, 2: ("glock" if team == "T" else "usp")}, 0.0, False
                p.hp, p.alive, p.rel, p.cd = 100, True, 0.0, 0.0
                for wn in p.slots.values():
                    if wn:
                        p.mags[wn] = WEAPONS[wn]["mag"]
                p.cur = 1 if p.slots[1] else 2
                p.prog, p.has_bomb = 0.0, False
                p.ai.update(target=None, path=[], site=random.choice("AB"), think=random.random() * 0.3)
                # Elegir spot segun rol: los anchors defienden un sitio fijo,
                # los rushers van al bombsite contrario y los lurkers flanquean
                # por el sitio contrario. Esto da variedad tactica sin mejorar
                # la punteria ni el tiempo de reaccion.
                role = p.ai.get("role")
                if p.bot and role:
                    site = random.choice("AB")
                    if role == "anchor":
                        # CT ancla el sitio; T acecha en su bombsite favorito
                        site = p.team == "C" and site or p.ai["site"]
                    elif role == "rush":
                        # Empuja rapido al sitio contrario: si es T va a su sitio
                        # de ataque; si es CT va hacia el sitio amenazado.
                        pass
                    p.ai["site"] = site
                p.ai["spot"] = random.choice(SITE_CELLS[p.ai["site"]])
                # Resetea los estados de la 1.7 que duran una ronda.
                p.ai["last_pos"] = None
                p.ai["last_pos_t"] = -10.0
                p.ai["retreat"] = 0.0
                p.ai["peek_t"] = 0.0
                p.ai["want_pistol"] = False
        ts = [p for p in self.players.values() if p.team == "T"]
        carrier = random.choice(ts)
        carrier.has_bomb = True
        self.bomb = {"state": "carried", "x": carrier.x, "y": carrier.y, "t": 0.0, "carrier": carrier.id}
        self.phase = "freeze"
        self.timer = FREEZE_T
        self.msg = ""
        for p in list(self.players.values()):
            if p.bot:
                self.bot_buy(p)

    def end_round(self, team, msg):
        self.score[team] += 1
        loser = "C" if team == "T" else "T"
        self.streak[team] = 0
        self.streak[loser] = min(4, self.streak[loser] + 1)
        for q in self.players.values():
            bonus = 3250 if q.team == team else 1400 + 500 * (self.streak[q.team] - 1)
            q.money = min(MAX_MONEY, q.money + bonus)
        self.phase = "over"
        self.timer = OVER_T
        self.msg = msg
        if self.score[team] >= WIN_ROUNDS:
            self.match_over = True
            self.timer = 8.0
            self.msg = ("¡Ganan los Terroristas la partida!" if team == "T"
                        else "¡Ganan los Antiterroristas la partida!")

    def drop_bomb(self, p):
        p.has_bomb = False
        if self.bomb["state"] == "carried":
            self.bomb.update(state="dropped", x=p.x, y=p.y, carrier=-1)

    def die(self, victim, killer):
        victim.alive = False
        victim.hp = 0
        victim.deaths += 1
        victim.prog = 0.0
        if killer is not None and killer.id != victim.id:
            killer.kills += 1
            killer.money = min(MAX_MONEY, killer.money + 300)
        if victim.has_bomb:
            self.drop_bomb(victim)
        kn = killer.name if killer else "?"
        self.feed.append((self.clock + 5.0, "%s > %s" % (kn, victim.name)))
        self.feed = self.feed[-5:]

    # -- bucle
    def update(self, dt):
        self.clock += dt
        if self.paused:
            return
        self.process_cmds()
        if self.phase == "wait":
            if self.count("T") and self.count("C"):
                self.new_round()
            else:
                self.balance_bots()
                if self.count("T") and self.count("C"):
                    self.new_round()
            return
        self.timer -= dt
        if self.phase == "freeze":
            if self.timer <= 0:
                self.phase, self.timer = "live", ROUND_T
            return
        if self.phase == "live":
            self.live(dt)
        elif self.phase == "over" and self.timer <= 0:
            if self.match_over:
                self.match_over = False
                # Al terminar la partida se rota al siguiente mapa del ciclo.
                self.cycle_map()
            self.new_round()

    def live(self, dt):
        for p in list(self.players.values()):
            if not p.alive:
                continue
            if p.bot:
                self.ai(p, dt)
            self.act(p, dt)
        b = self.bomb
        if b["state"] == "dropped":
            for p in self.players.values():
                if p.alive and p.team == "T" and math.hypot(p.x - b["x"], p.y - b["y"]) < 0.7:
                    p.has_bomb = True
                    b.update(state="carried", carrier=p.id)
                    break
        elif b["state"] == "planted":
            b["t"] -= dt
            if b["t"] <= 0:
                b["state"] = "exploded"
                self.add_event("b", b["x"], b["y"])
                self.end_round("T", "¡La bomba explotó! Ganan los Terroristas")
                return
        self.check_end()

    def check_end(self):
        if self.phase != "live":
            return
        alive_t = [p for p in self.players.values() if p.team == "T" and p.alive]
        alive_c = [p for p in self.players.values() if p.team == "C" and p.alive]
        planted = self.bomb["state"] == "planted"
        if not alive_c:
            self.end_round("T", "Ganan los Terroristas")
        elif not planted and not alive_t:
            self.end_round("C", "Ganan los Antiterroristas")
        elif not planted and self.timer <= 0:
            self.end_round("C", "Se acabó el tiempo. Ganan los Antiterroristas")

    def act(self, p, dt):
        inp = p.inp
        if not p.bot:
            p.a = inp["a"]
        p.cd = max(0.0, p.cd - dt)
        b = self.bomb
        use = inp["use"]
        acting = False
        if use and p.team == "T" and p.has_bomb and b["state"] == "carried" and site_at(p.x, p.y):
            acting = True
            p.prog += dt
            if p.prog >= PLANT_T:
                p.prog = 0.0
                p.has_bomb = False
                b.update(state="planted", x=p.x, y=p.y, t=BOMB_T, carrier=-1)
                self.add_event("p", p.x, p.y)
                p.money = min(MAX_MONEY, p.money + 300)
        elif (use and p.team == "C" and b["state"] == "planted"
              and math.hypot(p.x - b["x"], p.y - b["y"]) < 1.3):
            acting = True
            p.prog += dt
            if p.prog >= DEFUSE_T * (0.5 if p.kit else 1.0):
                p.prog = 0.0
                b["state"] = "defused"
                self.add_event("d", p.x, p.y)
                p.money = min(MAX_MONEY, p.money + 300)
                self.end_round("C", "¡Bomba desactivada! Ganan los Antiterroristas")
                return
        else:
            p.prog = 0.0
        # movimiento
        p.moving = False
        if not acting:
            f, s = clamp(inp["f"], -1, 1), clamp(inp["s"], -1, 1)
            vx = math.cos(p.a) * f - math.sin(p.a) * s
            vy = math.sin(p.a) * f + math.cos(p.a) * s
            n = math.hypot(vx, vy)
            if n > 1:
                vx, vy = vx / n, vy / n
            if n > 0:
                p.moving = True
                nx = p.x + vx * SPEED * dt
                if not blocked(nx, p.y):
                    p.x = nx
                ny = p.y + vy * SPEED * dt
                if not blocked(p.x, ny):
                    p.y = ny
        # recarga y disparo
        name = p.wname()
        st = WEAPONS[name]
        if st.get("melee"):
            if inp["fire"] and p.cd <= 0 and not acting:
                self.shoot(p)
        else:
            if p.rel > 0:
                p.rel -= dt
                if p.rel <= 0:
                    p.mags[name] = st["mag"]
            elif inp["rel"] and p.mags.get(name, 0) < st["mag"]:
                p.rel = st["reload"]
                self.add_event("r", p.x, p.y, p.id)
            if inp["fire"] and p.cd <= 0 and p.rel <= 0 and not acting:
                if p.mags.get(name, 0) <= 0:
                    p.rel = st["reload"]
                    self.add_event("r", p.x, p.y, p.id)
                else:
                    self.shoot(p)

    def shoot(self, p):
        name = p.wname()
        st = WEAPONS[name]
        if st.get("melee"):
            p.cd = st["cd"]
            self.add_event("s", p.x, p.y, p.id)
            reach = st.get("range", 1.65)
            best = None
            best_d = reach + 1.0
            for q in self.players.values():
                if not q.alive or q.team == p.team:
                    continue
                dx, dy = q.x - p.x, q.y - p.y
                d = math.hypot(dx, dy)
                if d > reach or d <= 0.01:
                    continue
                if abs(angdiff(math.atan2(dy, dx), p.a)) > 0.72:
                    continue
                if cast(p.x, p.y, dx / d, dy / d, d)[0] < d - 0.08:
                    continue
                if d < best_d:
                    best, best_d = q, d
            if best is not None:
                damage = st["dmg"]
                # El golpe de frente es fuerte; desde muy cerca puede ser letal.
                if best_d < 0.85:
                    damage = int(damage * 1.35)
                best.hp -= damage
                if best.hp <= 0:
                    best.hp = 0
                    best.alive = False
                    p.kills += 1
                    best.deaths += 1
                    self.add_event("k", best.x, best.y, p.id)
            return
        p.mags[name] = p.mags.get(name, st["mag"]) - 1
        p.cd = st["cd"]
        sp = st["spread"] + (st["move"] if p.moving else 0.0) + (0.02 if p.bot else 0.0)
        self.add_event("s", p.x, p.y, p.id)
        for _ in range(st["pellets"]):
            ang = p.a + random.uniform(-sp, sp)
            dx, dy = math.cos(ang), math.sin(ang)
            wall = cast(p.x, p.y, dx, dy, 60.0)[0]
            best, bt, best_offset = None, 1e9, 999.0
            for q in self.players.values():
                if not q.alive or q.team == p.team:
                    continue
                vx, vy = q.x - p.x, q.y - p.y
                t = vx * dx + vy * dy
                if t <= 0 or t >= wall or t >= bt:
                    continue
                offset = abs(vx * dy - vy * dx)
                if offset < 0.30:
                    best, bt, best_offset = q, t, offset
            if best:
                # Hitbox simplificado, pero los headshots son poco frecuentes.
                # La cercanía al centro por sí sola ya no garantiza un tiro a la cabeza.
                head_chance = 0.10 if p.bot else 0.75
                if p.bot:
                    head_chance *= (0.55 + 0.45 * p.ai["skill"])
                is_head = (st["pellets"] == 1 and best_offset <= 0.055 and
                           random.random() < head_chance)
                extra = random.randint(-2, 2) if st["pellets"] == 1 and st["dmg"] < 60 else 0
                self.hurt(best, st["dmg"] + extra, p, is_head)

    def hurt(self, target, dmg, attacker, headshot=False):
        if headshot:
            attacker.headshots += 1
            dmg = int(round(dmg * 4.0))
            self.add_event("h", target.x, target.y, attacker.id)
        if target.armor > 0:
            target.armor = max(0.0, target.armor - dmg * 0.5)
            dmg *= 0.5
        target.hp -= int(round(dmg))
        if target.hp <= 0 and target.alive:
            self.die(target, attacker)

    # -- tienda
    def buy_allowed(self):
        return self.phase == "freeze" or (self.phase == "live" and ROUND_T - self.timer <= BUY_WINDOW)

    def process_cmds(self):
        for p in self.players.values():
            inp = p.inp
            bq = int(inp.get("bq", 0))
            if bq > p.last_bq:
                p.last_bq = bq
                self.buy(p, str(inp.get("bi", "")))
            wq = int(inp.get("wq", 0))
            if wq > p.last_wq:
                p.last_wq = wq
                w = inp.get("w")
                if p.alive and w in (1, 2, 3) and w != p.cur and p.slots.get(w) and p.rel <= 0:
                    p.cur = w

    def buy(self, p, item):
        if not p.alive or not self.buy_allowed():
            return
        if item == "armor":
            if p.money >= ARMOR_PRICE and p.armor < 100:
                p.money -= ARMOR_PRICE
                p.armor = 100.0
        elif item == "kit":
            if p.team == "C" and not p.kit and p.money >= KIT_PRICE:
                p.money -= KIT_PRICE
                p.kit = True
        elif item in WEAPONS:
            st = WEAPONS[item]
            if st["price"] <= 0 or st["team"] not in (None, p.team) or p.slots[st["slot"]] == item:
                return
            if p.money < st["price"]:
                return
            p.money -= st["price"]
            p.slots[st["slot"]] = item
            p.mags[item] = st["mag"]
            p.cur = st["slot"]
            p.rel = 0.0

    def bot_buy(self, p):
        # Economia consciente: si el bot tiene poco dinero y no esta en una
        # ronda de "compra obligada" (ronda 1 o despues de varias perdidas),
        # hace eco parcial: compra pistola/barato y guarda para la siguiente.
        # Esto no mejora la punteria del bot, solo su gestion de dinero, y por
        # tanto no lo hace unfair contra jugadores humanos.
        if p.team == "T":
            choices = ["ak47", "galil", "sg552", "mac10", "mp5", "p90", "m3", "awp", "m249", "ump45"]
        else:
            choices = ["m4a1", "famas", "aug", "tmp", "mp5", "p90", "xm1014", "awp", "sg550", "ump45"]
        random.shuffle(choices)
        last = p.ai.get("last_weapon")
        affordable = [w for w in choices if p.money >= WEAPONS[w]["price"] and WEAPONS[w]["team"] in (None, p.team)]
        if last in affordable and len(affordable) > 1:
            affordable.remove(last)

        # Eco: si el dinero es muy bajo, guarda para la siguiente ronda en
        # lugar de gastar todo. Conserva al menos ARMOR_PRICE para la proxima.
        eco = p.money < 2000 and p.ai.get("save_until", 0) > 0
        if eco:
            affordable = [w for w in affordable if WEAPONS[w]["price"] <= 1500]
        elif p.money < 1500:
            # Ronda muy pobre: compra solo pistola y deja dinero para armor.
            affordable = []

        bought = False
        if affordable:
            # Prefer rifles/SMG but occasionally choose a cheaper or heavier gun.
            weights = []
            for w in affordable:
                price = WEAPONS[w]["price"]
                if price >= 3000:
                    weights.append(1.0)
                elif price >= 1800:
                    weights.append(1.35)
                else:
                    weights.append(0.95)
            weapon = random.choices(affordable, weights=weights, k=1)[0]
            self.buy(p, weapon)
            p.ai["last_weapon"] = weapon
            bought = True
            if eco:
                p.ai["save_until"] = max(0, p.ai["save_until"] - 1)
        if not bought:
            pistols = (["glock", "deagle", "elite", "p228"] if p.team == "T"
                       else ["usp", "fiveseven", "p228", "deagle"])
            random.shuffle(pistols)
            affordable_p = [w for w in pistols if p.money >= WEAPONS[w]["price"] and
                             WEAPONS[w]["team"] in (None, p.team)]
            if affordable_p:
                self.buy(p, random.choice(affordable_p))
        if p.money >= ARMOR_PRICE and random.random() < 0.72:
            self.buy(p, "armor")
        if p.team == "C" and p.money >= KIT_PRICE and random.random() < 0.62:
            self.buy(p, "kit")

        # Pistola secundaria: variedad, pero sin gastar siempre en la misma.
        pistols = (["glock", "deagle", "elite", "p228"] if p.team == "T"
                   else ["usp", "fiveseven", "p228", "deagle"])
        random.shuffle(pistols)
        for weapon in pistols:
            if weapon in p.slots.values():
                continue
            if p.money >= WEAPONS[weapon]["price"] and random.random() < 0.30:
                self.buy(p, weapon)
                break

        # Si tras comprar sigue con muy poco dinero, marca eco para la ronda
        # siguiente: ahorrara y reaparecera con armamento aceptable.
        if p.money < 1000:
            p.ai["save_until"] = max(p.ai.get("save_until", 0), 1)

    # -- IA de bots
    def visible_enemies(self, p):
        """Lista de enemigos visibles para p, ordenada por prioridad tactica.

        Prioridad (sin omnisciencia, solo lo que p ve):
          1. Portador de bomba (T) o desactivador (CT) — son el objetivo clave
          2. Enemigo mas cercano
        Esto da a los bots una nocion de prioridad sin mejorar su punteria.
        """
        out = []
        for q in self.players.values():
            if not q.alive or q.team == p.team:
                continue
            dx, dy = q.x - p.x, q.y - p.y
            d = math.hypot(dx, dy)
            if d > 17 or d < 1e-6:
                continue
            if abs(angdiff(math.atan2(dy, dx), p.a)) > 1.02 and d > 2.5:
                continue
            if cast(p.x, p.y, dx / d, dy / d, d + 1)[0] >= d - 0.3:
                # prioridad: bomba > resto
                prio = 0
                if p.team == "C" and q.has_bomb:
                    prio = -1
                # CT que esta desactivando (cerca de la bomba plantada y "use")
                b = self.bomb
                if (p.team == "T" and b["state"] == "planted"
                        and math.hypot(q.x - b["x"], q.y - b["y"]) < 1.3
                        and q.prog > 0.0):
                    prio = -1
                out.append((prio, d, q))
        if not out:
            return None
        out.sort(key=lambda t: (t[0], t[1]))
        return out[0][2]

    def visible_enemy(self, p):
        # Mantenida por compatibilidad con codigo externo; delega en la nueva
        # version con prioridad tactica.
        return self.visible_enemies(p)

    def ai_think(self, p):
        st = p.ai
        # Los bots no tienen vision omnisciente: pueden no detectar a un enemigo
        # aunque este en linea de vision y pierden el objetivo tras un rato.
        e = self.visible_enemies(p)
        skill = st["skill"]
        if e is not None and random.random() < (0.44 + 0.38 * skill):
            if st["target"] != e.id:
                st["react"] = random.uniform(0.60, 1.25) * (1.30 - skill)
            st["target"] = e.id
            st["lost"] = 0.0
            st["last_seen"] = self.clock
            # Memoria de la ultima posicion conocida del enemigo. Los bots no
            # tienen wallhack: solo recuerdan donde vieron al objetivo y, al
            # perderlo, pre-apuntan a esa esquina durante un rato corto.
            st["last_pos"] = (e.x, e.y)
            st["last_pos_t"] = self.clock
        elif st["target"] is not None:
            st["lost"] += st["think"]
            if st["lost"] > random.uniform(0.45, 1.15):
                st["target"] = None

        b = self.bomb
        # Decision de objetivo de movimiento segun el rol y el estado de la bomba.
        if b["state"] == "planted":
            if p.team == "C":
                # CT: todos corren a desactivar. Es lo justificable tacticamente.
                goal = (int(b["x"]), int(b["y"]))
            else:
                # T: defienden la bomba. Cada T elige una celda cercana al
                # bombsite para cubrir angulos, no se amontonan encima.
                site = site_at(b["x"], b["y"]) or st["site"]
                cells = SITE_CELLS.get(site, []) or SITE_CELLS[st["site"]]
                # Celdas a 2-4 de distancia de la bomba (no pegadas)
                cover = [c for c in cells if 2.0 <= math.hypot(c[0] + 0.5 - b["x"],
                                                                c[1] + 0.5 - b["y"]) <= 4.5]
                goal = random.choice(cover) if cover else (int(b["x"]), int(b["y"]))
                st["spot"] = goal
        elif b["state"] == "dropped":
            if p.team == "T":
                # El T mas cercano recoge; otros mantienen su spot.
                # El bot no sabe quien es el mas cercano sin omnisciencia, asi
                # que usa una heuristica: si esta a menos de 8 casillas, va.
                if math.hypot(p.x - b["x"], p.y - b["y"]) < 8.0:
                    goal = (int(b["x"]), int(b["y"]))
                else:
                    goal = st["spot"]
            else:
                goal = st["spot"]
        else:
            goal = st["spot"]
            if p.has_bomb:
                goal = random.choice(SITE_CELLS[st["site"]]) if not st.get("bombgoal") else st["bombgoal"]
                st["bombgoal"] = goal
        st["path"] = bfs((int(p.x), int(p.y)), goal)

    def ai(self, p, dt):
        st = p.ai
        inp = p.inp
        st["think"] -= dt
        if st["think"] <= 0:
            st["think"] = random.uniform(0.14, 0.38)
            self.ai_think(p)
        inp.update(use=False, fire=False, rel=False, f=0, s=0)

        # Pequeños errores de control hacen que los bots parezcan jugadores humanos.
        st["pause"] = max(0.0, st["pause"] - dt)
        st["peek_t"] = max(0.0, st["peek_t"] - dt)
        st["retreat"] = max(0.0, st["retreat"] - dt)

        # --- Recarga tactica: solo cuando no hay enemigo visible o el enemigo
        # esta lejos. Recargar en medio de un duelo es suicida y los bots ahora
        # lo evitan. Esto es una mejora tactica, no de punteria.
        name = p.wname()
        st_w = WEAPONS[name]
        mag_now = p.mags.get(name, 0)
        target_visible = st["target"] is not None and self.players.get(st["target"]) and \
            self.players[st["target"]].alive
        if (not target_visible) and p.rel <= 0 and mag_now < st_w["mag"] * 0.5:
            inp["rel"] = True

        # --- Cambio a pistola: si la primaria esta vacia y el enemigo esta
        # cerca, cambia a la secundaria en lugar de quedarse esperando recarga.
        if p.slots[1] and p.slots[2] and p.cur == 1 and mag_now <= 0 and not p.rel:
            tgt = self.players.get(st["target"]) if st["target"] is not None else None
            close = tgt is not None and math.hypot(tgt.x - p.x, tgt.y - p.y) < 7.0
            if close or st.get("want_pistol"):
                if not st.get("want_pistol"):
                    st["want_pistol"] = True
                inp["wq"] = inp.get("wq", 0) + 1
                inp["w"] = 2
                # El swap cuenta como accion; el bot no dispara este frame.
                return
            else:
                # Si el enemigo esta lejos, recarga la primaria.
                if p.rel <= 0:
                    inp["rel"] = True
        elif st.get("want_pistol") and p.cur == 2:
            # Vuelve a primaria cuando se recarga o el enemigo se aleja.
            if p.slots[1] and p.mags.get(p.slots[1], 0) > 0 and not target_visible:
                st["want_pistol"] = False

        # --- Retirada cuando HP baja: si hp < 30 y hay enemigo visible, el
        # bot retrocede en direccion contraria. Esto NO mejora su combate,
        # solo le hace intentar sobrevivir. Mantiene errores: a veces se
        # queda quieto o se choca con paredes (no es perfecto).
        if p.hp < 30 and target_visible and st["retreat"] <= 0:
            st["retreat"] = random.uniform(0.6, 1.4)

        tgt = self.players.get(st["target"]) if st["target"] is not None else None
        if tgt and tgt.alive:
            dx, dy = tgt.x - p.x, tgt.y - p.y
            desired = math.atan2(dy, dx)
            d = math.hypot(dx, dy)
            # El punto de mira tiene ruido y un poco de deriva mientras dispara.
            err = st["aim_error"] * (1.55 if d > 10 else 1.0)
            desired += random.gauss(0.0, err)
            diff = angdiff(desired, p.a)
            turn = TURN_BOT * (0.22 + 0.42 * st["skill"])
            # Algunos bots tardan mas en corregir el primer giro.
            if st["react"] > 0:
                st["react"] -= dt
                turn *= 0.35
            p.a += clamp(diff, -turn * dt, turn * dt)

            st["strafe_t"] -= dt
            if st["strafe_t"] <= 0:
                st["strafe_t"] = random.uniform(0.35, 1.15)
                # En retirada, el strafe se inclina por alejarse del enemigo
                # en lugar de moverse lateralmente al azar.
                if st["retreat"] > 0:
                    st["sd"] = random.choices((-1, 0, 1), weights=(0.20, 0.40, 0.40))[0]
                else:
                    st["sd"] = random.choices((-1, 0, 1), weights=(0.28, 0.44, 0.28))[0]
            if st["pause"] <= 0:
                inp["s"] = st["sd"]
                if st["retreat"] > 0:
                    # Intenta caminar hacia atras (alejandose del enemigo).
                    inp["f"] = -1
                elif random.random() < 0.18:
                    inp["f"] = -1

            # No hacen tracking perfecto: disparan en rfagas y fallan ocasionalmente.
            aligned = abs(angdiff(math.atan2(tgt.y - p.y, tgt.x - p.x), p.a)) < (0.12 + 0.14 * (1.0 - st["skill"]))
            if aligned and st["react"] <= 0 and st["pause"] <= 0 and st["retreat"] <= 0:
                if st["burst_left"] <= 0:
                    st["burst_left"] = random.randint(1, 3 if st["skill"] > 0.55 else 2)
                if st["burst_left"] > 0 and random.random() < (0.38 + 0.30 * st["skill"]):
                    inp["fire"] = True
                    st["burst_left"] -= 1
            elif random.random() < 0.008:
                inp["fire"] = True
            return

        # Sin objetivo visible: pre-apunta a la ultima posicion conocida
        # del enemigo durante unos segundos. Es un comportamiento humano:
        # mantienes el crosshair donde viste al rival por ultima vez.
        if (st["last_pos"] is not None
                and self.clock - st["last_pos_t"] < random.uniform(2.5, 4.5)):
            lx, ly = st["last_pos"]
            desired = math.atan2(ly - p.y, lx - p.x)
            diff = angdiff(desired, p.a)
            turn = TURN_BOT * (0.30 + 0.40 * st["skill"])
            p.a += clamp(diff, -turn * dt, turn * dt)
            # Avanza con cautela: pequeñas pausas antes de asomarse.
            if st["peek_t"] <= 0 and random.random() < 0.06:
                st["peek_t"] = random.uniform(0.20, 0.55)

        b = self.bomb
        if p.team == "T" and p.has_bomb and b["state"] == "carried" and site_at(p.x, p.y):
            inp["use"] = True
            return
        if p.team == "C" and b["state"] == "planted" and math.hypot(p.x - b["x"], p.y - b["y"]) < 1.0:
            inp["use"] = True
            return
        path = st["path"]
        while path and math.hypot(path[0][0] + 0.5 - p.x, path[0][1] + 0.5 - p.y) < 0.35:
            path.pop(0)
        if path and st["pause"] <= 0 and st["peek_t"] <= 0:
            tx, ty = path[0][0] + 0.5, path[0][1] + 0.5
            diff = angdiff(math.atan2(ty - p.y, tx - p.x), p.a)
            p.a += clamp(diff, -TURN_BOT * (0.55 + 0.45 * st["skill"]) * dt, TURN_BOT * dt)
            if abs(diff) < random.uniform(0.75, 1.15):
                inp["f"] = 1
            if random.random() < 0.04:
                st["pause"] = random.uniform(0.15, 0.5)

    # -- red
    def snapshot(self):
        b = self.bomb
        pl = [[p.id, round(p.x, 2), round(p.y, 2), round(p.a, 2), max(0, p.hp), p.team, p.ammo,
               1 if p.rel > 0 else 0, p.kills, p.deaths, p.headshots, 1 if p.bot else 0, p.name,
               1 if p.has_bomb else 0, round(p.prog, 1), 1 if p.alive else 0,
               WEAPON_ORDER.index(p.wname()), int(p.armor), p.money, 1 if p.kit else 0]
              for p in self.players.values()]
        return {"ph": self.phase, "tm": round(max(0.0, self.timer), 1), "rd": self.round,
                "sc": [self.score["T"], self.score["C"]], "msg": self.msg,
                "bm": [b["state"], round(b["x"], 2), round(b["y"], 2), round(max(0.0, b["t"]), 1)],
                "pl": pl, "ev": self.ev[-6:],
                "fd": [t for (exp, t) in self.feed if exp > self.clock],
                "map": self.map_name,
                "maptitle": MAPS[self.map_name].title}


(I_ID, I_X, I_Y, I_A, I_HP, I_TEAM, I_AMMO, I_REL, I_K, I_D, I_HS, I_BOT, I_NAME, I_BOMB, I_PROG, I_ALIVE,
 I_WPN, I_ARMOR, I_MONEY, I_KIT) = range(20)


def pack(obj):
    return zlib.compress(json.dumps(obj, separators=(",", ":")).encode())


def unpack(data):
    return json.loads(zlib.decompress(data).decode())


def get_lan_interfaces():
    """Devuelve (IP, broadcast) de las interfaces IPv4 activas en Linux."""
    found = []
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        for _, ifname in socket.if_nameindex():
            if ifname == "lo":
                continue
            request = struct.pack("256s", ifname[:15].encode("utf-8"))
            try:
                raw_ip = fcntl.ioctl(probe.fileno(), 0x8915, request)  # SIOCGIFADDR
                raw_mask = fcntl.ioctl(probe.fileno(), 0x891B, request)  # SIOCGIFNETMASK
                ip = socket.inet_ntoa(raw_ip[20:24])
                mask = socket.inet_ntoa(raw_mask[20:24])
                ip_n = struct.unpack("!I", socket.inet_aton(ip))[0]
                mask_n = struct.unpack("!I", socket.inet_aton(mask))[0]
                broadcast = socket.inet_ntoa(struct.pack("!I", (ip_n & mask_n) | (~mask_n & 0xffffffff)))
                if not ip.startswith("127.") and not ip.startswith("169.254."):
                    found.append((ip, broadcast))
            except OSError:
                continue
        probe.close()
    except OSError:
        pass
    # Fallback útil en instalaciones con interfaces que ioctl no expone.
    if not found:
        try:
            ip = socket.gethostbyname(socket.gethostname())
            if ip and not ip.startswith("127."):
                found.append((ip, "255.255.255.255"))
        except OSError:
            pass
    # Quitar duplicados conservando el orden.
    return list(dict.fromkeys(found))


def get_lan_ips():
    return [ip for ip, _ in get_lan_interfaces()]


class Server:
    def __init__(self, world, port=PORT, name="Defusa"):
        self.world = world
        self.name = name
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("", port))
        self.sock.setblocking(False)
        self.clients = {}
        self.snap_t = 0.0

    def info(self):
        return json.dumps({"name": self.name, "players": len(self.clients) + 1 if False else
                           self.world.count("T", True) + self.world.count("C", True),
                           "max": MAX_HUMANS, "ver": VERSION})

    def poll(self, now):
        while True:
            try:
                data, addr = self.sock.recvfrom(4096)
            except BlockingIOError:
                break
            except ConnectionError:
                continue
            except OSError:
                break
            if data == b"DEFUSA?":
                try:
                    self.sock.sendto(b"DEFUSA!" + self.info().encode(), addr)
                except OSError:
                    pass
                continue
            try:
                m = unpack(data)
            except Exception:
                continue
            k = m.get("k")
            if k == "join":
                if addr not in self.clients:
                    if len(self.clients) >= MAX_HUMANS:
                        self.send(addr, {"k": "full"})
                        continue
                    team = m.get("team", "T")
                    team = team if team in ("T", "C") else "T"
                    self.clients[addr] = self.world.add_player(str(m.get("name", "Jugador")), team)
                self.send(addr, {"k": "welcome", "id": self.clients[addr]})
            elif k == "in" and addr in self.clients:
                p = self.world.players.get(self.clients[addr])
                if p:
                    i = m.get("i", {})
                    p.inp = {"f": clamp(float(i.get("f", 0)), -1, 1), "s": clamp(float(i.get("s", 0)), -1, 1),
                             "a": float(i.get("a", 0.0)), "fire": bool(i.get("fire")),
                             "use": bool(i.get("use")), "rel": bool(i.get("rel")),
                             "wq": int(i.get("wq", 0)), "w": int(i.get("w", 2)),
                             "bq": int(i.get("bq", 0)), "bi": str(i.get("bi", ""))[:10]}
                    p.seen = now
            elif k == "bye" and addr in self.clients:
                self.world.remove_player(self.clients.pop(addr))
        for addr, pid in list(self.clients.items()):
            p = self.world.players.get(pid)
            if p is None or now - p.seen > 6.0:
                self.world.remove_player(pid)
                del self.clients[addr]

    def send(self, addr, obj):
        try:
            self.sock.sendto(pack(obj), addr)
        except OSError:
            pass

    def broadcast(self, snap, now):
        if now - self.snap_t < 1.0 / SNAP_HZ:
            return
        self.snap_t = now
        data = pack(dict(snap, k="st"))
        for addr in self.clients:
            try:
                self.sock.sendto(data, addr)
            except OSError:
                pass

    def close(self):
        self.sock.close()


class LocalSession:
    """Partida local: solo o anfitrion LAN. El jugador humano es el id local."""

    def __init__(self, name, team, bots, host_lan, port=PORT, start_map=None):
        self.world = World(team_size=bots, start_map=start_map)
        self.my_id = self.world.add_player(name, team)
        self.world.new_round()
        self.server = Server(self.world, port, name + "'s game") if host_lan else None
        self.acc = 0.0
        self.last_snap = None
        self.last_map = None  # para que el cliente reconstruya la escena al cambiar

    def set_paused(self, value):
        self.world.paused = bool(value)

    def send_input(self, inp):
        p = self.world.players.get(self.my_id)
        if p:
            p.inp = dict(inp)

    def update(self, dt):
        now = time.time()
        if self.server:
            self.server.poll(now)
        self.acc = min(self.acc + dt, 0.25)
        while self.acc >= TICK:
            self.world.update(TICK)
            self.acc -= TICK
        self.last_snap = self.world.snapshot()
        if self.server:
            self.server.broadcast(self.last_snap, now)

    def snapshot(self):
        return self.last_snap

    def lost(self):
        return False

    def close(self):
        if self.server:
            self.server.close()


class NetSession:
    def __init__(self, host, port, name, team):
        self.addr = (host, port)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setblocking(False)
        self.my_id = None
        self.snap = None
        self.last_rx = time.time()
        self.last_join = 0.0
        self.name, self.team = name, team
        self.full = False

    def _send(self, obj):
        try:
            self.sock.sendto(pack(obj), self.addr)
        except OSError:
            pass

    def send_input(self, inp):
        if self.my_id is not None:
            self._send({"k": "in", "i": {"f": inp["f"], "s": inp["s"], "a": round(inp["a"], 3),
                                         "fire": inp["fire"], "use": inp["use"], "rel": inp["rel"],
                                         "wq": inp.get("wq", 0), "w": inp.get("w", 2),
                                         "bq": inp.get("bq", 0), "bi": inp.get("bi", "")}})

    def update(self, dt):
        now = time.time()
        if self.my_id is None and now - self.last_join > 0.5:
            self.last_join = now
            self._send({"k": "join", "name": self.name, "team": self.team})
        while True:
            try:
                data, _ = self.sock.recvfrom(8192)
            except (BlockingIOError, InterruptedError):
                break
            except ConnectionError:
                continue
            except OSError:
                break
            try:
                m = unpack(data)
            except Exception:
                continue
            self.last_rx = now
            if m.get("k") == "welcome":
                self.my_id = m["id"]
            elif m.get("k") == "full":
                self.full = True
            elif m.get("k") == "st":
                self.snap = m

    def snapshot(self):
        return self.snap if self.my_id is not None else None

    def lost(self):
        return self.full or time.time() - self.last_rx > 5.0

    def close(self):
        self._send({"k": "bye"})
        self.sock.close()


def run_dedicated(args):
    world = World(team_size=args.bots, start_map=args.map)
    srv = Server(world, args.port, args.name)
    print("Servidor Defusa FPS en UDP %d (bots por equipo: %d, mapa: %s). Ctrl+C para salir."
          % (args.port, args.bots, world.map_name))
    last = time.time()
    try:
        while True:
            now = time.time()
            srv.poll(now)
            while now - last >= TICK:
                world.update(TICK)
                last += TICK
            if now - last > 0.5:
                last = now
            srv.broadcast(world.snapshot(), now)
            time.sleep(0.004)
    except KeyboardInterrupt:
        pass
    finally:
        srv.close()


# ---------------------------------------------------------------- cliente gráfico
def run_gui(args):
    if r3d is None:
        sys.exit("Falta python3-numpy (sudo apt install python3-numpy)")
    import pygame

    pygame.init()
    try:
        pygame.mixer.init(22050, -16, 1, 512)
    except Exception:
        pass
    pygame.display.set_caption("Defusa FPS")
    scene = r3d.Scene(GRID, SITES, SPAWNS, ACTIVE_MAP.theme)
    screen = pygame.display.set_mode((1024, 640), pygame.RESIZABLE)
    fonts = {"s": pygame.font.Font(None, 22), "m": pygame.font.Font(None, 34), "l": pygame.font.Font(None, 72)}
    snd = make_sounds(pygame)
    cfg = {"name": (os.environ.get("USER") or "Jugador")[:12], "team": "C", "bots": 4,
           "map": MAP_ORDER[0]}
    clock = pygame.time.Clock()
    while True:
        choice = menu(pygame, screen, fonts, clock, cfg, args)
        if choice is None:
            break
        kind, param = choice
        # El menu puede cambiar el mapa seleccionado: hay que aplicarlo al
        # modulo antes de construir la escena inicial de la sesion.
        set_active_map(cfg["map"])
        scene = r3d.Scene(GRID, SITES, SPAWNS, ACTIVE_MAP.theme)
        try:
            if kind == "solo":
                sess = LocalSession(cfg["name"], cfg["team"], max(1, cfg["bots"]), False,
                                    start_map=cfg["map"])
            elif kind == "host":
                sess = LocalSession(cfg["name"], cfg["team"], cfg["bots"], True,
                                    start_map=cfg["map"])
                ips = get_lan_ips()
                if ips:
                    ip_lines = "   ".join("%s:%d" % (ip, PORT) for ip in ips)
                    host_msg = ("Partida LAN iniciada (mapa: %s)\nComparte esta IP con tus amigos:\n"
                                % MAPS[cfg["map"]].title) + ip_lines + "\n\nPulsa una tecla para continuar"
                else:
                    host_msg = ("Partida LAN iniciada en el puerto %d (mapa: %s)\n"
                                "No pude detectar la IP de la red.\n"
                                "Usa 'I' en Unirse a partida LAN para escribirla manualmente.\n\n"
                                "Pulsa una tecla para continuar"
                                % (PORT, MAPS[cfg["map"]].title))
                show_message(pygame, screen, fonts, clock, host_msg)
            else:
                sess = NetSession(param[0], param[1], cfg["name"], cfg["team"])
        except OSError as e:
            show_message(pygame, screen, fonts, clock, "No se pudo iniciar: %s" % e)
            continue
        res = play(pygame, screen, fonts, clock, sess, snd, scene)
        sess.close()
        release_mouse(pygame)
        if res == "quit":
            break
    pygame.quit()


def make_sounds(pygame):
    import array
    sr = 22050
    out = {}
    try:
        def noise(dur, vol, decay, lp=0.0):
            n, a, y = int(sr * dur), array.array("h"), 0.0
            for i in range(n):
                x = random.uniform(-1, 1)
                y = y * lp + x * (1 - lp)
                a.append(int(y * vol * math.exp(-decay * i / n) * 32767))
            return a

        def tone(freq, dur, vol):
            n = int(sr * dur)
            return array.array("h", [int(math.sin(2 * math.pi * freq * i / sr) * vol * 32767 *
                                         (1 - i / n)) for i in range(n)])

        data = {"shot": noise(0.14, 0.6, 7, 0.3), "boom": noise(1.4, 0.95, 3, 0.93),
                "beep": tone(1100, 0.08, 0.4), "click": noise(0.05, 0.35, 3, 0.5),
                "ok": tone(660, 0.15, 0.5) + tone(880, 0.25, 0.5)}
        for k, v in data.items():
            out[k] = pygame.mixer.Sound(buffer=v.tobytes())
    except Exception:
        return {}
    return out


def play_snd(snd, name, dist=0.0):
    s = snd.get(name)
    if s:
        s.set_volume(clamp(1.0 - dist / 22.0, 0.0, 1.0))
        s.play()


def text(pygame, screen, font, s, pos, color=(255, 255, 255), center=False, shadow=True):
    img = font.render(s, True, color)
    r = img.get_rect()
    if center:
        r.center = pos
    else:
        r.topleft = pos
    if shadow:
        sh = font.render(s, True, (0, 0, 0))
        screen.blit(sh, (r.x + 2, r.y + 2))
    screen.blit(img, r)


def show_message(pygame, screen, fonts, clock, msg):
    lines = str(msg).split("\n")
    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            if e.type == pygame.KEYDOWN or e.type == pygame.MOUSEBUTTONDOWN:
                return
        screen.fill((15, 15, 22))
        w, h = screen.get_size()
        line_h = 42
        start_y = h // 2 - (len(lines) * line_h) // 2
        for i, line in enumerate(lines):
            color = (255, 205, 100) if i == 0 else (225, 225, 230)
            font = fonts["m"] if i == 0 else fonts["s"]
            text(pygame, screen, font, line, (w // 2, start_y + i * line_h), color, True)
        pygame.display.flip()
        clock.tick(30)


def edit_text(pygame, screen, fonts, clock, title, value, maxlen):
    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return None
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_RETURN:
                    return value
                if e.key == pygame.K_ESCAPE:
                    return None
                if e.key == pygame.K_BACKSPACE:
                    value = value[:-1]
                elif e.unicode and e.unicode.isprintable() and len(value) < maxlen:
                    value += e.unicode
        screen.fill((15, 15, 22))
        w, h = screen.get_size()
        text(pygame, screen, fonts["m"], title, (w // 2, h // 2 - 50), (200, 200, 200), True)
        text(pygame, screen, fonts["m"], value + "_", (w // 2, h // 2), (255, 230, 120), True)
        text(pygame, screen, fonts["s"], "Enter: aceptar   Esc: cancelar", (w // 2, h // 2 + 60), (150, 150, 150), True)
        pygame.display.flip()
        clock.tick(30)


def scan_lan(pygame, screen, fonts, clock, cfg):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("", 0))
    sock.setblocking(False)
    found = {}
    last = 0.0
    sel = 0
    broadcasts = ["255.255.255.255"]
    broadcasts.extend(bcast for _, bcast in get_lan_interfaces())
    broadcasts = list(dict.fromkeys(broadcasts))
    try:
        while True:
            now = time.time()
            if now - last > 1.0:
                last = now
                # Consulta por broadcast global y por cada subred conectada.
                for dst in broadcasts:
                    try:
                        sock.sendto(b"DEFUSA?", (dst, PORT))
                    except OSError:
                        pass
                # También permite detectar una partida alojada en este equipo.
                try:
                    sock.sendto(b"DEFUSA?", ("127.0.0.1", PORT))
                except OSError:
                    pass
            while True:
                try:
                    data, addr = sock.recvfrom(2048)
                except (BlockingIOError, ConnectionError, InterruptedError):
                    break
                except OSError:
                    break
                if data.startswith(b"DEFUSA!"):
                    try:
                        info = json.loads(data[7:].decode())
                        found[addr[0]] = info
                    except Exception:
                        pass
            hosts = sorted(found)
            sel = clamp(sel, 0, max(0, len(hosts) - 1))
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return "quit"
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        return None
                    if e.key == pygame.K_UP:
                        sel -= 1
                    if e.key == pygame.K_DOWN:
                        sel += 1
                    if e.key == pygame.K_r:
                        found.clear()
                        last = 0.0
                    if e.key == pygame.K_RETURN and hosts:
                        return (hosts[sel], PORT)
                    if e.key == pygame.K_i:
                        ip = edit_text(pygame, screen, fonts, clock, "IP del servidor:", cfg.get("ip", ""), 40)
                        if ip:
                            cfg["ip"] = ip
                            return (ip, PORT)
            screen.fill((15, 15, 22))
            w, h = screen.get_size()
            text(pygame, screen, fonts["l"], "Partidas LAN", (w // 2, 75), (255, 200, 80), True)
            if not hosts:
                text(pygame, screen, fonts["m"], "Buscando servidores en la red local...", (w // 2, h // 2 - 12), (180, 180, 180), True)
                text(pygame, screen, fonts["s"], "Comprueba que ambos equipos estén en la misma Wi-Fi/LAN", (w // 2, h // 2 + 28), (140, 150, 165), True)
            for i, ip in enumerate(hosts):
                inf = found[ip]
                col = (255, 255, 120) if i == sel else (210, 210, 210)
                text(pygame, screen, fonts["m"], "%s   %s:%d   jugadores %s/%s" % (
                    inf.get("name", "?"), ip, PORT, inf.get("players", "?"), inf.get("max", "?")),
                    (w // 2, 155 + i * 44), col, True)
            text(pygame, screen, fonts["s"], "Enter: unirse   R: buscar otra vez   I: escribir IP   Esc: volver",
                 (w // 2, h - 50), (150, 150, 150), True)
            pygame.display.flip()
            clock.tick(30)
    finally:
        sock.close()


def release_mouse(pygame):
    """Ensure the pointer is visible, absolute and not grabbed by the game."""
    try:
        pygame.event.set_grab(False)
    except Exception:
        pass
    # Pygame 2 supports relative mode; older builds may not expose this API.
    try:
        pygame.mouse.set_relative_mode(False)
    except Exception:
        pass
    try:
        pygame.mouse.set_visible(True)
    except Exception:
        pass
    try:
        pygame.mouse.get_rel()
    except Exception:
        pass


def menu(pygame, screen, fonts, clock, cfg, args):
    release_mouse(pygame)
    sel = 0
    update_msg = ""
    items = ["solo", "host", "join", "team", "bots", "map", "name", "update", "quit"]
    while True:
        # Re-apply every frame so the cursor is released even after returning
        # from gameplay or when a platform/window manager restores mouse grab.
        release_mouse(pygame)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return None
            if e.type == pygame.KEYDOWN:
                it = items[sel]
                if e.key == pygame.K_UP:
                    sel = (sel - 1) % len(items)
                elif e.key == pygame.K_DOWN:
                    sel = (sel + 1) % len(items)
                elif e.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_RETURN):
                    d = -1 if e.key == pygame.K_LEFT else 1
                    if it == "team":
                        cfg["team"] = "T" if cfg["team"] == "C" else "C"
                    elif it == "bots":
                        cfg["bots"] = (cfg["bots"] + d) % 6
                    elif it == "map":
                        # Cicla por los mapas disponibles con flechas izq/der.
                        idx = MAP_ORDER.index(cfg["map"]) if cfg["map"] in MAP_ORDER else 0
                        idx = (idx + d) % len(MAP_ORDER)
                        cfg["map"] = MAP_ORDER[idx]
                    elif e.key == pygame.K_RETURN:
                        if it in ("solo", "host"):
                            return (it, None)
                        if it == "join":
                            r = scan_lan(pygame, screen, fonts, clock, cfg)
                            if r == "quit":
                                return None
                            if r:
                                return ("join", r)
                        elif it == "name":
                            n = edit_text(pygame, screen, fonts, clock, "Tu apodo:", cfg["name"], 12)
                            if n:
                                cfg["name"] = n
                        elif it == "update":
                            update_msg = "Buscando actualizaciones..."
                            pygame.display.flip()
                            try:
                                latest = _github_latest_deb()
                                if not latest or _version_key(latest[0]) <= _version_key(VERSION):
                                    update_msg = "Ya tienes la última versión: %s" % VERSION
                                else:
                                    remote_version, _, url = latest
                                    update_msg = "Actualizando a %s..." % remote_version
                                    fd, path = tempfile.mkstemp(prefix="defusa-update-", suffix=".deb")
                                    os.close(fd)
                                    try:
                                        req = urllib.request.Request(url, headers={"User-Agent": "Defusa-FPS/%s" % VERSION})
                                        with urllib.request.urlopen(req, timeout=30) as rr, open(path, "wb") as ff:
                                            shutil.copyfileobj(rr, ff)
                                        if _install_deb(path):
                                            os.execv(sys.executable, [sys.executable, os.path.abspath(__file__)] + [a for a in sys.argv if a not in ("--no-update",)])
                                        else:
                                            update_msg = "No se pudo instalar la versión %s" % remote_version
                                    finally:
                                        try: os.unlink(path)
                                        except OSError: pass
                            except Exception:
                                update_msg = "No se pudo comprobar GitHub"
                        elif it == "quit":
                            return None
        screen.fill((12, 14, 20))
        w, h = screen.get_size()
        text(pygame, screen, fonts["l"], "DEFUSA FPS", (w // 2, 90), (255, 200, 80), True)
        text(pygame, screen, fonts["s"], "Terroristas plantan la bomba - Antiterroristas la desactivan",
             (w // 2, 140), (160, 160, 170), True)
        map_title = MAPS[cfg["map"]].title if cfg["map"] in MAPS else cfg["map"]
        labels = {"solo": "Jugar solo (contra bots)", "host": "Crear partida LAN",
                  "join": "Unirse a partida LAN",
                  "team": "Equipo: " + ("Terroristas (T)" if cfg["team"] == "T" else "Antiterroristas (CT)"),
                  "bots": "Bots por equipo: %d%s" % (cfg["bots"], "  (sin bots)" if cfg["bots"] == 0 else ""),
                  "map": "Mapa inicial: %s  (rotacion auto)" % map_title,
                  "name": "Apodo: " + cfg["name"],
                  "update": "Buscar actualizaciones", "quit": "Salir"}
        for i, k in enumerate(items):
            col = (255, 255, 120) if i == sel else (215, 215, 215)
            text(pygame, screen, fonts["m"], labels[k], (w // 2, 205 + i * 40), col, True)
        footer_y = h - 78
        text(pygame, screen, fonts["s"], "Versión %s" % VERSION, (w // 2, footer_y), (130, 190, 230), True)
        if update_msg:
            text(pygame, screen, fonts["s"], update_msg, (w // 2, footer_y - 24), (150, 230, 160), True)
        text(pygame, screen,
             fonts["s"], "WASD mover  Ratón apuntar  Clic disparar  R recargar  E plantar/desactivar  B tienda  1/2/3/Q armas  Tab marcador  F2 calidad  Esc menú",
             (w // 2, h - 40), (140, 140, 150), True)
        pygame.display.flip()
        clock.tick(30)


TEAM_COL = {"T": (214, 150, 60), "C": (70, 110, 220)}


def shop_items(team):
    # Hasta 9 opciones visibles; la lista cambia por equipo para mantener la tienda manejable.
    primary = [
        ("ak47" if team == "T" else "m4a1"),
        ("galil" if team == "T" else "famas"),
        ("sg552" if team == "T" else "aug"),
        "mp5", "p90", "m3", "xm1014", "scout", "awp",
    ]
    secondary = ["deagle", "p228", "elite" if team == "T" else "fiveseven"]
    out = []
    for i in secondary + primary:
        st = WEAPONS[i]
        if st["team"] in (None, team) and i not in [x[0] for x in out]:
            out.append((i, st["name"], st["price"]))
        if len(out) >= 9:
            break
    out.append(("armor", "Chaleco kevlar", ARMOR_PRICE))
    if team == "C":
        out.append(("kit", "Kit de desactivación", KIT_PRICE))
    return out


def can_buy_now(snap):
    return snap["ph"] == "freeze" or (snap["ph"] == "live" and snap["tm"] >= ROUND_T - BUY_WINDOW)


def render(pygame, screen, fonts, snap, me, cam, state, show_score):
    w, h = screen.get_size()
    px, py, pa, pp = cam
    scene = state["scene"]
    np_ = r3d.np
    div = state["div"]
    rw, rh = max(200, w // div), max(120, h // div)
    rh -= rh % 2
    zoom = state["zoom"]
    fov = math.radians(24 if zoom else 70)

    # ---- escena 3D
    img, depth = scene.render_world(px, py, pa, rw, rh, fov, pp)
    cam3 = scene.make_cam(px, py, r3d.EYE, pa, rw, fov, pp)
    if getattr(scene, "props", None):
        scene.draw_boxes(img, depth, cam3, scene.props, rw, rh, fogd=20.0)
    labels = []
    for r in snap["pl"]:
        if r[I_ID] == me[I_ID] or not r[I_ALIVE]:
            continue
        if not scene.visible(cam3, (r[I_X], r[I_Y], 0.55), 0.5, 0.62, depth, rw, rh):
            continue
        an = state["anim"].get(r[I_ID])
        moving = an is not None and state["now"] - an["mv"] < 0.25
        head_yaw = 0.0
        if r[I_TEAM] == me[I_TEAM]:
            # Mirada amistosa puramente visual: no modifica yaw ni paquetes LAN.
            # Los compañeros cercanos giran la cabeza hacia el jugador local.
            dxm, dym = me[I_X] - r[I_X], me[I_Y] - r[I_Y]
            ally_dist = math.hypot(dxm, dym)
            if 0.65 < ally_dist < 9.0:
                toward = math.atan2(dym, dxm)
                head_yaw = clamp(angdiff(toward, r[I_A]), -0.78, 0.78)
        boxes = r3d.character_boxes(r[I_X], r[I_Y], r[I_A], r[I_TEAM], WEAPON_ORDER[r[I_WPN]],
                                    an["ph"] if an else 0.0, moving,
                                    bool(r[I_BOMB]) and r[I_TEAM] == "T", head_yaw=head_yaw)
        scene.draw_boxes(img, depth, cam3, boxes, rw, rh)
        if r[I_TEAM] == me[I_TEAM]:
            pr = scene.project(cam3, (r[I_X], r[I_Y], 1.28), rw, rh)
            if pr:
                labels.append((r[I_NAME], pr[0] * w / rw, pr[1] * h / rh))
    bm = snap["bm"]
    if bm[0] in ("dropped", "planted"):
        blink = int(state["now"] * 4) % 2 == 0
        if scene.visible(cam3, (bm[1], bm[2], 0.1), 0.2, 0.15, depth, rw, rh):
            scene.draw_boxes(img, depth, cam3, r3d.bomb_boxes(bm[1], bm[2], bm[0] == "planted", blink), rw, rh)
    rec = state["recoil"]
    wid = WEAPON_ORDER[me[I_WPN]]
    if me[I_ALIVE] and not zoom:
        t9 = state["now"] * 9
        bob = (math.sin(t9) * 0.008, abs(math.cos(t9)) * 0.010) if state["moving"] else (0.0, 0.0)
        scene.draw_fp(img, rw, rh, math.radians(70), wid, me[I_TEAM], rec, bob,
                      math.sin(math.pi * state["rl"]), rec > 0.6)
    arr = np_.clip(img, 0, 255).astype(np_.uint8)
    surf = pygame.image.frombuffer(arr.tobytes(), (rw, rh), "RGB")
    screen.blit(pygame.transform.smoothscale(surf, (w, h)), (0, 0))

    # ---- 2D: etiquetas, mira, efectos
    for (nm, lx, ly) in labels:
        text(pygame, screen, fonts["s"], nm, (int(lx), int(ly)), (150, 255, 150), True)
    if zoom:
        key = ("scope", w, h)
        if state.get("scope_key") != key:
            ov = pygame.Surface((w, h), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 255))
            pygame.draw.circle(ov, (0, 0, 0, 0), (w // 2, h // 2), min(w, h) // 2 - 16)
            state["scope_key"], state["scope"] = key, ov
        screen.blit(state["scope"], (0, 0))
        pygame.draw.line(screen, (0, 0, 0), (w // 2 - min(w, h) // 2, h // 2), (w // 2 + min(w, h) // 2, h // 2), 1)
        pygame.draw.line(screen, (0, 0, 0), (w // 2, h // 2 - min(w, h) // 2), (w // 2, h // 2 + min(w, h) // 2), 1)
    elif me[I_ALIVE]:
        cx, cy = w // 2, h // 2
        for (a, b, c, d) in ((-14, 0, -5, 0), (5, 0, 14, 0), (0, -14, 0, -5), (0, 5, 0, 14)):
            pygame.draw.line(screen, (80, 255, 80), (cx + a, cy + b), (cx + c, cy + d), 2)
    if state["flash"] > 0:
        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        ov.fill((255, 0, 0, int(110 * min(1.0, state["flash"]))))
        screen.blit(ov, (0, 0))


    # minimapa
    cs = 5
    mmx, mmy = 10, 10
    pygame.draw.rect(screen, (0, 0, 0), (mmx - 2, mmy - 2, W * cs + 4, H * cs + 4))
    for y in range(H):
        for x in range(W):
            v = GRID[y][x]
            if v:
                screen.fill((120, 120, 120) if v == 1 else (130, 90, 50), (mmx + x * cs, mmy + y * cs, cs, cs))
    for k, (x0, y0, x1, y1) in SITES.items():
        pygame.draw.rect(screen, (200, 60, 60), (mmx + x0 * cs, mmy + y0 * cs, (x1 - x0 + 1) * cs, (y1 - y0 + 1) * cs), 1)
        text(pygame, screen, fonts["s"], k, (mmx + (x0 + 2) * cs, mmy + (y0 + 1) * cs), (255, 120, 120), shadow=False)
    for r in snap["pl"]:
        if r[I_ALIVE] and r[I_TEAM] == me[I_TEAM]:
            c = (255, 255, 255) if r[I_ID] == me[I_ID] else TEAM_COL[r[I_TEAM]]
            pygame.draw.circle(screen, c, (int(mmx + r[I_X] * cs), int(mmy + r[I_Y] * cs)), 3)
    pygame.draw.line(screen, (255, 255, 255), (mmx + px * cs, mmy + py * cs),
                     (mmx + (px + math.cos(pa) * 2) * cs, mmy + (py + math.sin(pa) * 2) * cs), 1)
    if bm[0] in ("planted", "dropped"):
        pygame.draw.circle(screen, (255, 40, 40), (int(mmx + bm[1] * cs), int(mmy + bm[2] * cs)), 3)

    # HUD superior
    ttxt = "%d:%02d" % (int(snap["tm"]) // 60, int(snap["tm"]) % 60)
    if snap["ph"] == "freeze":
        ttxt = "Prepárate %d" % math.ceil(snap["tm"])
    text(pygame, screen, fonts["m"], ttxt, (w // 2, 24), (255, 255, 255), True)
    text(pygame, screen, fonts["m"], "T %d" % snap["sc"][0], (w // 2 - 120, 24), TEAM_COL["T"], True)
    text(pygame, screen, fonts["m"], "CT %d" % snap["sc"][1], (w // 2 + 120, 24), TEAM_COL["C"], True)
    # Nombre del mapa actual: se muestra justo debajo del marcador para que
    # el jugador sepa en que arena esta jugando y pueda planear su compra.
    map_title = snap.get("maptitle") or (MAPS.get(snap.get("map", ""), ACTIVE_MAP).title
                                          if isinstance(snap.get("map"), str) else ACTIVE_MAP.title)
    text(pygame, screen, fonts["s"], "Mapa: %s" % map_title, (w // 2, 48), (180, 200, 240), True)
    if bm[0] == "planted":
        text(pygame, screen, fonts["m"], "¡BOMBA! %d" % math.ceil(bm[3]), (w // 2, 72), (255, 70, 70), True)
    for i, line in enumerate(snap["fd"]):
        text(pygame, screen, fonts["s"], line, (w - 14 - fonts["s"].size(line)[0], 12 + i * 20), (240, 240, 240))
    # HUD inferior
    hpcol = (255, 80, 80) if me[I_HP] < 30 else (255, 255, 255)
    text(pygame, screen, fonts["l"], "%d" % me[I_HP], (24, h - 76), hpcol)
    wst = WEAPONS[WEAPON_ORDER[me[I_WPN]]]
    am = "Recargando..." if me[I_REL] else "%d / %d" % (me[I_AMMO], wst["mag"])
    text(pygame, screen, fonts["m"], am, (w - 230, h - 50), (255, 255, 255))
    text(pygame, screen, fonts["s"], wst["name"], (w - 230, h - 76), (200, 200, 200))
    text(pygame, screen, fonts["m"], "$ %d" % me[I_MONEY], (24, h - 118), (120, 230, 120))
    if me[I_ARMOR] > 0:
        text(pygame, screen, fonts["m"], "Chaleco %d" % me[I_ARMOR], (170, h - 52), (170, 200, 255))
    if me[I_KIT]:
        text(pygame, screen, fonts["s"], "Kit de desactivación", (170, h - 76), (150, 220, 255))
    buy_ok = can_buy_now(snap) and me[I_ALIVE]
    if buy_ok and not state["shop"]:
        text(pygame, screen, fonts["s"], "B: abrir tienda", (w // 2, 92), (140, 230, 140), True)
    # mensajes de acción
    here = site_at(px, py)
    if me[I_ALIVE]:
        if me[I_TEAM] == "T" and me[I_BOMB] and bm[0] == "carried":
            text(pygame, screen, fonts["m"],
                 ("Mantén E para plantar la bomba (sitio %s)" % here) if here else "Llevas la bomba: ve al sitio A o B",
                 (w // 2, h - 120), (255, 220, 120), True)
        elif me[I_TEAM] == "C" and bm[0] == "planted" and math.hypot(px - bm[1], py - bm[2]) < 1.3:
            text(pygame, screen, fonts["m"], "Mantén E para desactivar la bomba", (w // 2, h - 120), (120, 220, 255), True)
        if me[I_PROG] > 0:
            total = PLANT_T if me[I_TEAM] == "T" else DEFUSE_T * (0.5 if me[I_KIT] else 1.0)
            bw = 240
            pygame.draw.rect(screen, (0, 0, 0), (w // 2 - bw // 2 - 2, h - 90, bw + 4, 18))
            pygame.draw.rect(screen, (90, 230, 90), (w // 2 - bw // 2, h - 88, int(bw * min(1.0, me[I_PROG] / total)), 14))
    else:
        text(pygame, screen, fonts["m"], "Estás muerto: observando a tu equipo", (w // 2, h - 120), (255, 120, 120), True)
    if snap["msg"] and snap["ph"] in ("over", "wait"):
        text(pygame, screen, fonts["m"], snap["msg"], (w // 2, h // 3), (255, 240, 140), True)

    if state["shop"] and buy_ok:
        items = shop_items(me[I_TEAM])
        pw, ph_ = 460, 70 + 40 * len(items) + 40
        x0, y0 = w // 2 - pw // 2, h // 2 - ph_ // 2
        ov = pygame.Surface((pw, ph_), pygame.SRCALPHA)
        ov.fill((10, 12, 20, 225))
        screen.blit(ov, (x0, y0))
        pygame.draw.rect(screen, (255, 200, 80), (x0, y0, pw, ph_), 2)
        text(pygame, screen, fonts["m"], "TIENDA     $ %d" % me[I_MONEY], (w // 2, y0 + 30), (255, 220, 120), True)
        for i, (iid, nm, price) in enumerate(items):
            ok = me[I_MONEY] >= price
            col = (130, 235, 130) if ok else (150, 100, 100)
            text(pygame, screen, fonts["m"], "%d   %s" % (i + 1, nm), (x0 + 30, y0 + 70 + i * 40), col)
            text(pygame, screen, fonts["m"], "$%d" % price, (x0 + pw - 120, y0 + 70 + i * 40), col)
        text(pygame, screen, fonts["s"], "Pulsa el número para comprar   B / Esc: cerrar",
             (w // 2, y0 + ph_ - 22), (170, 170, 180), True)
    if show_score:
        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 170))
        screen.blit(ov, (0, 0))
        text(pygame, screen, fonts["m"], "Marcador   T %d - %d CT" % (snap["sc"][0], snap["sc"][1]),
             (w // 2, 80), (255, 255, 255), True)
        for col, team, label in ((w // 4, "T", "Terroristas"), (3 * w // 4, "C", "Antiterroristas")):
            text(pygame, screen, fonts["m"], label, (col, 130), TEAM_COL[team], True)
            rows = sorted([r for r in snap["pl"] if r[I_TEAM] == team], key=lambda r: -r[I_K])
            for i, r in enumerate(rows):
                c = (255, 255, 120) if r[I_ID] == me[I_ID] else (230, 230, 230)
                if not r[I_ALIVE]:
                    c = (150, 150, 150)
                text(pygame, screen, fonts["s"], "%-14s  K %d  M %d  HS %d" % (r[I_NAME], r[I_K], r[I_D], r[I_HS]),
                     (col - 120, 170 + i * 26), c)


def play(pygame, screen, fonts, clock, sess, snd, scene):
    pygame.mouse.set_visible(False)
    pygame.event.set_grab(True)
    pygame.mouse.get_rel()
    state = {"now": 0.0, "recoil": 0.0, "flash": 0.0, "moving": False, "anim": {}, "scene": scene,
             "div": 3, "zoom": False, "shop": False, "rl": 0.0, "auto": True, "pause_menu": False, "pause_sel": 0, "graphics_menu": False, "quality": "medio"}
    cmd = {"wq": 0, "w": 2, "bq": 0, "bi": ""}
    ft, nframes = 0.03, 0
    view_a = 0.0
    view_p = 0.0
    last_rd = -1
    last_map = None        # detección de cambio de mapa para reconstruir la escena
    hp_prev = 100
    last_ev = None
    bomb_sec = None
    snap = me = None
    while True:
        dt = min(clock.tick(60) / 1000.0, 0.05)
        state["now"] += dt
        ft = ft * 0.93 + (clock.get_time() / 1000.0) * 0.07
        nframes += 1
        # Ajuste dinamico de resolucion: reduce el coste del raycasting antes de que
        # la caida de FPS sea demasiado visible. Nunca cambia la logica del juego.
        if state["auto"] and nframes % 20 == 0 and ft > 0.024 and state["div"] < 4:
            state["div"] += 1
        elif state["auto"] and nframes % 120 == 0 and ft < 0.017 and state["div"] > 2:
            state["div"] -= 1
        # Reconstruccion de la escena 3D cuando se rota de mapa (al terminar
        # una partida o al unirse a un servidor con un mapa distinto). El
        # objeto Scene cachea grid/sites/spawns en numpy, asi que hay que
        # crearlo de nuevo para que el raycasting refleje la nueva arena.
        cur_map = None
        if snap is not None:
            cur_map = snap.get("map")
        if cur_map is not None and cur_map != last_map:
            if cur_map in MAPS:
                set_active_map(cur_map)
                state["scene"] = r3d.Scene(GRID, SITES, SPAWNS, ACTIVE_MAP.theme)
                scene = state["scene"]
            last_map = cur_map
        slot_now = WEAPONS[WEAPON_ORDER[me[I_WPN]]]["slot"] if me else 2
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return "quit"
            if e.type == pygame.MOUSEWHEEL and me and not state["shop"]:
                cmd["wq"] += 1
                cmd["w"] = 3 - slot_now
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    if state["graphics_menu"]:
                        state["graphics_menu"] = False
                    elif state["shop"]:
                        state["shop"] = False
                    else:
                        state["pause_menu"] = not state["pause_menu"]
                        state["pause_sel"] = 0
                        if isinstance(sess, LocalSession) and sess.server is None:
                            sess.set_paused(state["pause_menu"])
                elif state["graphics_menu"]:
                    if e.key in (pygame.K_UP, pygame.K_DOWN):
                        order = ["bajo", "medio", "alto"]
                        idx = order.index(state["quality"])
                        idx = (idx + (1 if e.key == pygame.K_DOWN else -1)) % 3
                        state["quality"] = order[idx]
                    elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        state["div"] = {"alto": 2, "medio": 3, "bajo": 4}[state["quality"]]
                        state["auto"] = False
                        state["graphics_menu"] = False
                elif state["pause_menu"]:
                    pause_items = ["continuar", "config", "salir"]
                    if e.key == pygame.K_UP:
                        state["pause_sel"] = (state["pause_sel"] - 1) % len(pause_items)
                    elif e.key == pygame.K_DOWN:
                        state["pause_sel"] = (state["pause_sel"] + 1) % len(pause_items)
                    elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        it = pause_items[state["pause_sel"]]
                        if it == "continuar":
                            state["pause_menu"] = False
                            if isinstance(sess, LocalSession) and sess.server is None:
                                sess.set_paused(False)
                        elif it == "config":
                            state["graphics_menu"] = True
                        elif it == "salir":
                            if isinstance(sess, LocalSession) and sess.server is None:
                                sess.set_paused(False)
                            return "menu"

                elif e.key == pygame.K_F11:
                    pygame.display.toggle_fullscreen()
                elif e.key == pygame.K_F2:
                    state["auto"] = False
                    state["div"] = {2: 3, 3: 4, 4: 2}.get(state["div"], 2)
                elif e.key == pygame.K_b:
                    if snap and me and me[I_ALIVE] and can_buy_now(snap):
                        state["shop"] = not state["shop"]
                elif state["shop"] and me and pygame.K_1 <= e.key <= pygame.K_9:
                    items = shop_items(me[I_TEAM])
                    if e.key - pygame.K_1 < len(items):
                        cmd["bq"] += 1
                        cmd["bi"] = items[e.key - pygame.K_1][0]
                elif e.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                    cmd["wq"] += 1
                    cmd["w"] = {pygame.K_1: 1, pygame.K_2: 2, pygame.K_3: 3}[e.key]
                elif e.key == pygame.K_q:
                    cmd["wq"] += 1
                    cmd["w"] = {1: 2, 2: 3, 3: 1}.get(slot_now, 2)
        mx, my = pygame.mouse.get_rel()
        if not state["pause_menu"] and not state["graphics_menu"]:
            view_a += mx * 0.0028 * (0.35 if state["zoom"] else 1.0)
            view_p = clamp(view_p - my * 0.0022 * (0.65 if state["zoom"] else 1.0), -1.15, 1.15)
        k = pygame.key.get_pressed()
        buttons = pygame.mouse.get_pressed()
        paused_local = state["pause_menu"]
        inp = {"f": 0 if paused_local else int(k[pygame.K_w]) - int(k[pygame.K_s]),
               "s": 0 if paused_local else int(k[pygame.K_d]) - int(k[pygame.K_a]),
               "a": view_a, "fire": bool(buttons[0]) and not state["shop"] and not paused_local,
               "use": bool(k[pygame.K_e]) and not paused_local,
               "rel": bool(k[pygame.K_r]) and not paused_local}
        inp.update(cmd)
        sess.send_input(inp)
        sess.update(dt)
        if sess.lost():
            show_message(pygame, screen, fonts, clock, "Conexión perdida o servidor lleno")
            return "menu"
        snap = sess.snapshot()
        w, h = screen.get_size()
        if snap is None:
            screen.fill((10, 10, 16))
            text(pygame, screen, fonts["m"], "Conectando...", (w // 2, h // 2), (200, 200, 200), True)
            pygame.display.flip()
            continue
        me = next((r for r in snap["pl"] if r[I_ID] == sess.my_id), None)
        if me is None:
            screen.fill((10, 10, 16))
            text(pygame, screen, fonts["m"], "Sincronizando...", (w // 2, h // 2), (200, 200, 200), True)
            pygame.display.flip()
            continue
        if snap["rd"] != last_rd:
            last_rd = snap["rd"]
            view_a = 0.0 if me[I_TEAM] == "T" else math.pi
            view_p = 0.0
        if state["shop"] and not (me[I_ALIVE] and can_buy_now(snap)):
            state["shop"] = False
        cam = (me[I_X], me[I_Y], view_a, view_p)
        if not me[I_ALIVE]:
            mates = [r for r in snap["pl"] if r[I_ALIVE] and r[I_TEAM] == me[I_TEAM]] or \
                    [r for r in snap["pl"] if r[I_ALIVE]]
            if mates:
                cam = (mates[0][I_X], mates[0][I_Y], mates[0][I_A], 0.0)
        # eventos de sonido
        evs = snap["ev"]
        if last_ev is None:
            last_ev = max([e[0] for e in evs], default=0)
        for e in evs:
            if e[0] > last_ev:
                d = math.hypot(e[2] - cam[0], e[3] - cam[1])
                name = {"s": "shot", "b": "boom", "p": "ok", "d": "ok", "r": "click", "h": "ok"}.get(e[1])
                if name:
                    play_snd(snd, name, d)
                if e[1] == "s" and e[4] == sess.my_id:
                    state["recoil"] = 1.0
        if evs:
            last_ev = max(last_ev, evs[-1][0])
        if me[I_HP] < hp_prev and me[I_ALIVE]:
            state["flash"] = 1.0
        hp_prev = me[I_HP]
        bm = snap["bm"]
        if bm[0] == "planted":
            sec = int(bm[3])
            if sec != bomb_sec:
                bomb_sec = sec
                play_snd(snd, "beep")
        else:
            bomb_sec = None
        for r in snap["pl"]:
            an = state["anim"].setdefault(r[I_ID], {"x": r[I_X], "y": r[I_Y], "mv": -9.0, "ph": 0.0})
            if abs(r[I_X] - an["x"]) + abs(r[I_Y] - an["y"]) > 0.005:
                an["mv"] = state["now"]
                an["x"], an["y"] = r[I_X], r[I_Y]
            if state["now"] - an["mv"] < 0.25:
                an["ph"] += dt * 9.0
        wst = WEAPONS[WEAPON_ORDER[me[I_WPN]]]
        state["rl"] = min(1.0, state["rl"] + dt / wst["reload"]) if me[I_REL] else 0.0
        state["zoom"] = bool(buttons[2]) and WEAPON_ORDER[me[I_WPN]] == "awp" and bool(me[I_ALIVE]) and not state["shop"]
        state["recoil"] = max(0.0, state["recoil"] - dt * 8)
        state["flash"] = max(0.0, state["flash"] - dt * 2.5)
        state["moving"] = bool(inp["f"] or inp["s"]) and bool(me[I_ALIVE])
        render(pygame, screen, fonts, snap, me, cam, state, bool(k[pygame.K_TAB]))
        if state["pause_menu"]:
            ov = pygame.Surface((w, h), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 185))
            screen.blit(ov, (0, 0))
            text(pygame, screen, fonts["l"], "PAUSA", (w // 2, h // 2 - 70), (255, 220, 100), True)
            if isinstance(sess, LocalSession) and sess.server is None:
                text(pygame, screen, fonts["m"], "La partida está pausada para todos", (w // 2, h // 2), (235, 235, 235), True)
            else:
                text(pygame, screen, fonts["m"], "Pausa solo local — la partida LAN continúa", (w // 2, h // 2), (235, 235, 235), True)
            pause_items = [("CONTINUAR", False), ("CONFIGURACION DE GRAFICOS", False), ("SALIR DE LA PARTIDA", False)]
            for i, (label, _) in enumerate(pause_items):
                col = (255, 220, 100) if i == state["pause_sel"] else (220, 220, 220)
                text(pygame, screen, fonts["m"], label, (w // 2, h // 2 + 65 + i * 48), col, True)
            text(pygame, screen, fonts["s"], "↑/↓ seleccionar   Enter aceptar   Esc volver", (w // 2, h - 35), (180, 180, 180), True)
        if state["graphics_menu"]:
            ov = pygame.Surface((w, h), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 220))
            screen.blit(ov, (0, 0))
            text(pygame, screen, fonts["l"], "CONFIGURACION", (w // 2, h // 2 - 120), (255, 220, 100), True)
            text(pygame, screen, fonts["m"], "Calidad de graficos", (w // 2, h // 2 - 50), (235, 235, 235), True)
            vals = ["bajo", "medio", "alto"]
            for i, q in enumerate(vals):
                col = (255, 220, 100) if q == state["quality"] else (180, 180, 180)
                text(pygame, screen, fonts["m"], q.upper(), (w // 2, h // 2 + i * 42), col, True)
            text(pygame, screen, fonts["s"], "↑/↓ cambiar   Enter aplicar   Esc volver", (w // 2, h - 35), (180, 180, 180), True)
        pygame.display.flip()


def main():
    ap = argparse.ArgumentParser(description="Defusa FPS - shooter estilo CS 1.6 con LAN y modo bomba")
    ap.add_argument("--server", action="store_true", help="ejecutar solo el servidor (sin gráficos)")
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--bots", type=int, default=4, help="bots por equipo en modo servidor (0-5)")
    ap.add_argument("--name", default="Servidor Defusa")
    ap.add_argument("--map", default=MAP_ORDER[0],
                    help="mapa inicial (%s); tras cada partida se rota al siguiente" % " ".join(MAP_ORDER))
    ap.add_argument("--version", action="version", version=VERSION)
    ap.add_argument("--no-update", action="store_true", help="no comprobar actualizaciones de GitHub")
    ap.add_argument("--legacy", action="store_true", help="abrir el motor anterior Pygame (incluye LAN completa)")
    args = ap.parse_args()
    args.bots = clamp(args.bots, 0, 5)
    if args.map not in MAPS:
        args.map = MAP_ORDER[0]
    if not args.no_update:
        if check_for_updates():
            os.execv(sys.executable, [sys.executable, os.path.abspath(__file__)] + [a for a in sys.argv[1:] if a != "--no-update"])
    if args.server:
        run_dedicated(args)
    elif args.legacy:
        run_gui(args)
    else:
        try:
            import panda_game
            panda_game.run(args.map)
        except ImportError as exc:
            sys.exit("No se pudo iniciar Panda3D. Instala python3-panda3d o ejecuta defusa-fps --legacy. Detalle: %s" % exc)


if __name__ == "__main__":
    main()
