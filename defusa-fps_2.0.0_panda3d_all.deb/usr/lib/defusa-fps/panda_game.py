#!/usr/bin/env python3
# Defusa FPS 2.0 - Panda3D GPU renderer
import math, random, sys
from direct.showbase.ShowBase import ShowBase
from direct.gui.OnscreenText import OnscreenText
from panda3d.core import (WindowProperties, AmbientLight, DirectionalLight, Vec4,
                          Vec3, TextNode, ClockObject)
import defusa as game

class DefusaPanda(ShowBase):
    def __init__(self, map_name=None):
        super().__init__()
        self.disableMouse()
        self.setBackgroundColor(0.30, 0.43, 0.56, 1)
        self.setFrameRateMeter(True)
        props = WindowProperties(); props.setTitle('Defusa FPS 2.0.0 - Panda3D'); props.setCursorHidden(True)
        self.win.requestProperties(props)
        self.map_name = map_name if map_name in game.MAPS else game.MAP_ORDER[0]
        self.map_data = game.MAPS[self.map_name]
        self.keys = {k: False for k in ('w','a','s','d','shift')}
        for k in ('w','a','s','d','shift'):
            self.accept(k, self.set_key, [k, True]); self.accept(k+'-up', self.set_key, [k, False])
        self.accept('escape', sys.exit); self.accept('m', self.next_map); self.accept('mouse1', self.shoot)
        self.accept('r', self.respawn)
        self.heading = 0.0; self.pitch = 0.0; self.health = 100; self.kills = 0
        self.player = Vec3(2.5, 11.5, 1.65)
        self.world = self.render.attachNewNode('world')
        self.enemies = []
        self.build_map()
        self.camera.setPos(self.player); self.camera.setHpr(0,0,0)
        amb = AmbientLight('ambient'); amb.setColor(Vec4(.52,.52,.52,1)); self.render.setLight(self.render.attachNewNode(amb))
        sun = DirectionalLight('sun'); sun.setColor(Vec4(.9,.86,.76,1)); sn=self.render.attachNewNode(sun); sn.setHpr(-35,-55,0); self.render.setLight(sn)
        self.weapon = self.make_box('rifle-viewmodel', Vec3(.34,.62,-.30), Vec3(.12,.48,.12), Vec4(.12,.14,.13,1), self.camera)
        self.weapon.setHpr(0,0,0)
        self.hud = OnscreenText(text='', pos=(-1.30,.92), scale=.045, fg=(1,1,1,1), align=TextNode.ALeft, mayChange=True)
        self.help = OnscreenText(text='WASD mover | Mouse mirar | Click disparar | M cambiar mapa | R reaparecer | ESC salir',
            pos=(0,-.94), scale=.038, fg=(1,1,1,1), mayChange=False)
        self.center = OnscreenText(text='+', pos=(0,0), scale=.06, fg=(1,1,1,1))
        self.last_mouse = None; self.mouse_sensitivity = .14
        self.taskMgr.add(self.update, 'defusa-update')
        self.taskMgr.add(self.mouse_look, 'defusa-mouse')

    def set_key(self, key, value): self.keys[key] = value

    def make_box(self, name, pos, scale, color, parent=None):
        node = self.loader.loadModel('models/box')
        node.reparentTo(parent or self.world); node.setName(name); node.setPos(pos); node.setScale(scale)
        node.setColor(color); node.setTwoSided(True); return node

    def build_map(self):
        self.world.removeNode(); self.world=self.render.attachNewNode('world')
        self.enemies=[]
        palette = {
          'desert':(0.66,.53,.34,1), 'temple':(.48,.48,.39,1), 'reactor':(.38,.43,.46,1),
          'town':(.58,.43,.32,1), 'palace':(.66,.57,.43,1), 'warehouse':(.38,.43,.40,1),
          'highway':(.42,.45,.46,1), 'rail':(.40,.39,.36,1)}
        wall=Vec4(*palette.get(self.map_data.theme,(.5,.5,.5,1)))
        self.make_box('floor',Vec3(16,12,-.18),Vec3(32,24,.35),Vec4(.25,.28,.25,1))
        self.make_box('ceiling',Vec3(16,12,4.2),Vec3(32,24,.25),Vec4(.22,.24,.27,1))
        for y,row in enumerate(self.map_data.grid):
            for x,v in enumerate(row):
                if v:
                    col=wall if v==1 else Vec4(.38,.29,.19,1)
                    self.make_box('wall' if v==1 else 'crate',Vec3(x+.5,y+.5,1.0),Vec3(.5,.5,1.0 if v==1 else .55),col)
        # Sites A/B marked with colored low platforms
        for label,(x0,y0,x1,y1) in self.map_data.sites.items():
            self.make_box('site-'+label,Vec3((x0+x1+1)/2,(y0+y1+1)/2,.015),Vec3((x1-x0+1)/2,(y1-y0+1)/2,.025),
                          Vec4(.72,.20,.12,.85) if label=='A' else Vec4(.15,.32,.75,.85))
        spawn=self.map_data.spawns.get('T' if self.map_name.endswith('dust2') else 'C') or [(2,2)]
        sx,sy=random.choice(spawn); self.player=Vec3(sx+.5,sy+.5,1.65); self.camera.setPos(self.player)
        # Lightweight bot placeholders placed at valid enemy-team spawn cells
        enemy=self.map_data.spawns.get('T' if self.playerTeamCT() else 'C') or self.map_data.spawns.get('T') or [(27,12)]
        for i in range(5):
            ex,ey=enemy[i%len(enemy)]
            bot=self.make_box('bot-%d'%i,Vec3(ex+.5,ey+.5,.82),Vec3(.28,.24,.82),Vec4(.62,.18,.13,1))
            head=self.make_box('bot-head-%d'%i,Vec3(ex+.5,ey+.5,1.72),Vec3(.18,.18,.18),Vec4(.72,.55,.40,1))
            self.enemies.append({'node':bot,'head':head,'hp':100,'cool':random.random()+.5})
        self.camera.setHpr(0,0,0)

    def playerTeamCT(self): return True

    def next_map(self):
        idx=game.MAP_ORDER.index(self.map_name); self.map_name=game.MAP_ORDER[(idx+1)%len(game.MAP_ORDER)]
        self.map_data=game.MAPS[self.map_name]; self.build_map()

    def respawn(self): self.health=100; self.kills=0; self.next_map()

    def mouse_look(self, task):
        if self.win and self.win.getPointer(0):
            p=self.win.getPointer(0); cx=self.win.getXSize()//2; cy=self.win.getYSize()//2
            if self.last_mouse is None: self.last_mouse=(cx,cy)
            dx=p.getX()-cx; dy=p.getY()-cy
            self.heading-=dx*self.mouse_sensitivity; self.pitch=max(-80,min(80,self.pitch+dy*self.mouse_sensitivity))
            self.camera.setHpr(self.heading,self.pitch,0); self.win.movePointer(0,cx,cy)
        return task.cont

    def shoot(self):
        origin=self.camera.getPos(); forward=self.camera.getQuat(self.render).getForward()
        best=None; bestd=999
        for e in self.enemies:
            if e['hp']<=0: continue
            target=e['node'].getPos()+Vec3(0,0,.35); delta=target-origin; dist=delta.length()
            if dist<32 and dist<bestd and forward.dot(delta.normalized())>.985:
                best=e; bestd=dist
        if best:
            best['hp']-=45
            if best['hp']<=0:
                best['node'].hide(); best['head'].hide(); self.kills+=1

    def update(self, task):
        dt=min(ClockObject.getGlobalClock().getDt(),.05)
        speed=6.5 if self.keys['shift'] else 4.4
        quat=self.camera.getQuat(self.render); forward=quat.getForward(); right=quat.getRight()
        move=Vec3(0,0,0)
        if self.keys['w']: move+=Vec3(forward.x,forward.y,0)
        if self.keys['s']: move-=Vec3(forward.x,forward.y,0)
        if self.keys['d']: move+=Vec3(right.x,right.y,0)
        if self.keys['a']: move-=Vec3(right.x,right.y,0)
        if move.lengthSquared():
            move.normalize(); nx=self.player.x+move.x*speed*dt; ny=self.player.y+move.y*speed*dt
            gx=int(max(0,min(game.W-1,nx))); gy=int(max(0,min(game.H-1,ny)))
            if self.map_data.grid[gy][gx]==0: self.player.x=nx; self.player.y=ny
        self.player.z=1.65; self.camera.setPos(self.player)
        for e in self.enemies:
            if e['hp']<=0: continue
            pos=e['node'].getPos(); delta=self.player-pos; dist=math.hypot(delta.x,delta.y)
            if dist>1.5:
                step=min(dt*1.1,dist-1.4); pos.x+=delta.x/dist*step; pos.y+=delta.y/dist*step
                gx=int(max(0,min(game.W-1,pos.x))); gy=int(max(0,min(game.H-1,pos.y)))
                if self.map_data.grid[gy][gx]==0: e['node'].setPos(pos); e['head'].setPos(pos+Vec3(0,0,.9))
            e['cool']-=dt
            if dist<12 and e['cool']<=0: self.health=max(0,self.health-4); e['cool']=1.0
        self.hud.setText('DEFUSA FPS 2.0.0 | Panda3D\nMapa: %s | Vida: %d | Bajas: %d | Bots: %d' %
                         (self.map_data.title,self.health,self.kills,sum(1 for e in self.enemies if e['hp']>0)))
        return task.cont

def run(map_name=None):
    app=DefusaPanda(map_name); app.run()
