# -*- coding: utf-8 -*-
"""Capa de adaptacion para Android: controles tactiles + aim assist.

Este modulo NO reemplaza defusa.py. Se importa desde defusa.py cuando
se detecta Android y proporciona:
- Deteccion de plataforma Android
- Controles tactiles: joystick virtual + drag-aim + tap-shoot + botones HUD
- Aim assist sutil (magnetismo de mira, no auto-aim)
- Resolucion adaptada a pantalla movil (mas baja para rendimiento)

Uso desde defusa.py:
    from android_compat import is_android, TOUCH_CONTROLS, AIM_ASSIST
    if is_android():
        # usar controles tactiles en vez de mouse/teclado
        ...

Compatibilidad crossplay: el protocolo de red es IDENTICO al de PC.
Un servidor PC acepta clientes Android sin saberlo. El aim assist es
solo cliente (modifica view_a antes de enviarlo), el servidor no cambia.
"""
import math
import sys
import os


def is_android():
    """Detecta si estamos corriendo en Android."""
    # Metodo 1: ANDROID_ROOT existe en Android.
    if os.environ.get("ANDROID_ROOT"):
        return True
    # Metodo 2: sys.platform en p4a/Pydroid3 puede ser "linux" pero el
    # modulo android existe.
    try:
        import android
        return True
    except ImportError:
        pass
    # Metodo 3: /system/bin/am existe solo en Android.
    if os.path.exists("/system/bin/am"):
        return True
    # Metodo 4: P4A_BOOTSTRAP o ANDROID_APP_PATH
    if os.environ.get("P4A_BOOTSTRAP") or os.environ.get("ANDROID_APP_PATH"):
        return True
    return False


# ============================================================
# Controles tactiles
# ============================================================
class TouchControls:
    """Gestiona los controles tactiles para Android.

    Layout en pantalla (vertical o horizontal):
    - Mitad izquierda: joystick virtual de movimiento
    - Mitad derecha: drag para apuntar + tap para disparar
    - Botones HUD en la esquina inferior derecha:
      - Recargar (R)
      - Plantar/desactivar (E)
      - Tienda (B)
      - Cambiar arma (Q)
      - Granada (G) + lanzar (F)

    El joystick virtual es un circulo grande en la esquina inferior
    izquierda. El jugador toca dentro del circulo y arrastra para moverse.
    La distancia desde el centro determina la velocidad (0..1).

    El drag-aim funciona en toda la mitad derecha: el jugador arrastra
    el dedo y la camara rota proporcionalmente al movimiento.

    El tap-shoot: si el jugador toca la mitad derecha sin arrastrar
    (movimiento < 5 pixeles), se interpreta como disparo.
    """

    def __init__(self, screen_w, screen_h):
        self.screen_w = screen_w
        self.screen_h = screen_h
        # Mitad de pantalla: izquierda = movimiento, derecha = apuntar.
        self.half_w = screen_w // 2
        # Joystick virtual: centro y radio.
        self.joy_cx = screen_w // 5
        self.joy_cy = int(screen_h * 0.78)
        self.joy_radius = min(screen_w, screen_h) // 6
        self.joy_active = False
        self.joy_finger = None
        self.joy_dx = 0.0  # -1..1
        self.joy_dy = 0.0  # -1..1
        # Drag-aim: finger que arrastra en la mitad derecha.
        self.aim_finger = None
        self.aim_last_x = 0
        self.aim_last_y = 0
        self.aim_dragged = False
        # Tap-shoot: contador de taps recientes en la mitad derecha.
        self.tap_shoot = False
        # Botones HUD: rectangulos (x, y, w, h, label, action).
        self.buttons = self._make_buttons()
        self.pressed_buttons = set()  # finger_ids -> button indices

    def _make_buttons(self):
        """Crea los botones HUD en la esquina inferior derecha."""
        bw = int(self.screen_w * 0.10)
        bh = int(self.screen_w * 0.10)
        gap = int(self.screen_w * 0.015)
        x0 = self.screen_w - bw - gap
        y0 = self.screen_h - bh - gap
        buttons = []
        # Fila 1: Recargar, Tienda
        buttons.append((x0 - bw - gap, y0, bw, bh, "R", "reload"))
        buttons.append((x0, y0, bw, bh, "B", "shop"))
        # Fila 2: Arma, Granada
        buttons.append((x0 - bw - gap, y0 - bh - gap, bw, bh, "Q", "weapon"))
        buttons.append((x0, y0 - bh - gap, bw, bh, "G", "grenade"))
        # Fila 3: Plantar/Usar, Lanzar
        buttons.append((x0 - bw - gap, y0 - 2 * (bh + gap), bw, bh, "E", "use"))
        buttons.append((x0, y0 - 2 * (bh + gap), bw, bh, "F", "throw"))
        return buttons

    def handle_event(self, event, pygame):
        """Procesa un evento SDL2 de toque. Devuelve acciones a ejecutar."""
        actions = {}
        if event.type == pygame.FINGERDOWN:
            x = int(event.x * self.screen_w)
            y = int(event.y * self.screen_h)
            fid = event.finger_id if hasattr(event, "finger_id") else event.touch_id
            # ¿Es un boton HUD?
            for i, (bx, by, bw, bh, label, action) in enumerate(self.buttons):
                if bx <= x <= bx + bw and by <= y <= by + bh:
                    self.pressed_buttons.add((fid, i))
                    actions["button_" + action] = True
                    return actions
            # ¿Es el joystick (mitad izquierda)?
            if x < self.half_w:
                # ¿Cerca del centro del joystick o en la zona inferior izquierda?
                dist = math.hypot(x - self.joy_cx, y - self.joy_cy)
                if dist < self.joy_radius * 2.0 or y > self.screen_h * 0.55:
                    self.joy_active = True
                    self.joy_finger = fid
                    self.joy_dx = 0.0
                    self.joy_dy = 0.0
                    return actions
            # Mitad derecha: drag-aim.
            if x >= self.half_w and self.aim_finger is None:
                self.aim_finger = fid
                self.aim_last_x = x
                self.aim_last_y = y
                self.aim_dragged = False
                return actions

        elif event.type == pygame.FINGERMOTION:
            x = int(event.x * self.screen_w)
            y = int(event.y * self.screen_h)
            fid = event.finger_id if hasattr(event, "finger_id") else event.touch_id
            # Joystick activo.
            if self.joy_active and fid == self.joy_finger:
                dx = x - self.joy_cx
                dy = y - self.joy_cy
                d = math.hypot(dx, dy)
                if d > 0:
                    self.joy_dx = max(-1.0, min(1.0, dx / self.joy_radius))
                    self.joy_dy = max(-1.0, min(1.0, dy / self.joy_radius))
                return actions
            # Drag-aim activo.
            if fid == self.aim_finger:
                dx = x - self.aim_last_x
                dy = y - self.aim_last_y
                self.aim_last_x = x
                self.aim_last_y = y
                if abs(dx) > 3 or abs(dy) > 3:
                    self.aim_dragged = True
                actions["aim_dx"] = dx
                actions["aim_dy"] = dy
                return actions

        elif event.type == pygame.FINGERUP:
            fid = event.finger_id if hasattr(event, "finger_id") else event.touch_id
            # Joystick liberado.
            if fid == self.joy_finger:
                self.joy_active = False
                self.joy_finger = None
                self.joy_dx = 0.0
                self.joy_dy = 0.0
            # Drag-aim liberado: si no arrastro, es un tap-shoot.
            if fid == self.aim_finger:
                if not self.aim_dragged:
                    actions["tap_shoot"] = True
                self.aim_finger = None
            # Boton liberado.
            to_remove = [(f, i) for (f, i) in self.pressed_buttons if f == fid]
            for item in to_remove:
                self.pressed_buttons.discard(item)
            return actions
        return actions

    def get_movement(self):
        """Devuelve (forward, strafe) en rango -1..1 para el input del juego."""
        return self.joy_dx, self.joy_dy

    def draw(self, screen, pygame):
        """Dibuja los controles tactiles sobre la pantalla."""
        # Joystick virtual: circulo exterior + circulo interior (thumb).
        if self.joy_active:
            pygame.draw.circle(screen, (60, 60, 70, 100),
                               (self.joy_cx, self.joy_cy), self.joy_radius, 2)
            thumb_x = int(self.joy_cx + self.joy_dx * self.joy_radius)
            thumb_y = int(self.joy_cy + self.joy_dy * self.joy_radius)
            pygame.draw.circle(screen, (120, 120, 140), (thumb_x, thumb_y),
                               self.joy_radius // 3)
        else:
            # Dibuja el circulo del joystick semi-transparente.
            s = pygame.Surface((self.joy_radius * 2, self.joy_radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(s, (60, 60, 70, 50),
                              (self.joy_radius, self.joy_radius), self.joy_radius, 2)
            screen.blit(s, (self.joy_cx - self.joy_radius, self.joy_cy - self.joy_radius))
        # Botones HUD.
        for i, (bx, by, bw, bh, label, action) in enumerate(self.buttons):
            pressed = any(f == fid for f, bi in self.pressed_buttons if bi == i)
            col = (100, 100, 120) if pressed else (50, 50, 60)
            pygame.draw.rect(screen, col, (bx, by, bw, bh), border_radius=6)
            pygame.draw.rect(screen, (120, 120, 140), (bx, by, bw, bh), 2, border_radius=6)
            # Etiqueta del boton (centrada).
            font = pygame.font.Font(None, max(16, bw // 2))
            txt = font.render(label, True, (220, 220, 220))
            screen.blit(txt, (bx + (bw - txt.get_width()) // 2,
                              by + (bh - txt.get_height()) // 2))


# ============================================================
# Aim assist (solo cliente, no afecta al servidor)
# ============================================================
class AimAssist:
    """Aim assist sutil para movil.

    Funciona asi:
    - Cada frame, si el jugador esta disparando (fire=True), busca el
      enemigo vivo mas cercano al centro de la pantalla (dentro de un
      cono de ~8 grados).
    - Si lo encuentra, ajusta view_a hacia el enemigo con un factor
      de lerp de 0.10 por frame (suave, no snap).
    - Esto da un "magnetismo" de mira que ayuda a apuntar en movil
      sin ser auto-aim. El jugador sigue teniendo que apuntar cerca
      del enemigo para que el assist actue.

    El ajuste se aplica solo a view_a antes de enviar el input al
    servidor. El servidor no sabe que hay aim assist; solo ve un
    yaw ligeramente corregido. PC players no tienen esto.
    """

    def __init__(self):
        # Cono de deteccion en radianes (8 grados = 0.14 rad).
        self.cone = 0.14
        # Factor de lerp (que tan rapido se corrige la mira).
        # 0.10 = 10% de correccion por frame = suave pero util.
        self.strength = 0.10
        # Maxima correccion por frame en radianes (3 grados = 0.052 rad).
        # Evita que la mira "salte" demasiado de golpe.
        self.max_correction = 0.052
        # Solo activo cuando el jugador esta disparando.
        self.active = False

    def update(self, view_a, snap, my_id, my_team, firing, angdiff_fn):
        """Calcula la correccion de mira para este frame.

        Args:
            view_a: angulo de mira actual del jugador local.
            snap: snapshot del servidor con la lista de jugadores.
            my_id: ID del jugador local.
            my_team: equipo del jugador local.
            firing: True si el jugador esta disparando este frame.
            angdiff_fn: funcion para calcular diferencia de angulos.

        Returns:
            view_a corregido (puede ser igual al original si no hay
            correccion).
        """
        if not firing:
            self.active = False
            return view_a
        self.active = True
        best_target = None
        best_diff = self.cone
        for r in snap.get("pl", []):
            # Saltarse jugadores del mismo equipo y muertos.
            if r[1] == my_id:  # I_ID
                continue
            if r[5] != my_team and r[15]:  # I_TEAM, I_ALIVE
                pass
            elif r[5] == my_team:
                continue
            if not r[15]:  # I_ALIVE
                continue
            # Calcular angulo hacia el enemigo.
            dx = r[1] - snap.get("my_x", 0)  # I_X - my_x
            dy = r[2] - snap.get("my_y", 0)  # I_Y - my_y
            target_a = math.atan2(dy, dx)
            diff = abs(angdiff_fn(target_a, view_a))
            if diff < best_diff:
                best_diff = diff
                best_target = target_a
        if best_target is not None:
            # Lerp suave hacia el target.
            diff = angdiff_fn(best_target, view_a)
            correction = diff * self.strength
            # Limitar la correccion por frame.
            correction = max(-self.max_correction, min(self.max_correction, correction))
            view_a += correction
        return view_a


# ============================================================
# Configuracion de Android
# ============================================================
def android_config():
    """Devuelve configuracion optimizada para Android.

    - Resolucion mas baja para rendimiento en movil.
    - div=4 (calidad baja) por defecto para FPS jugable.
    - Auto-ajuste de resolucion desactivado (fijo en div=4).
    """
    return {
        "width": 720,     # resolucion base (se escala a pantalla)
        "height": 480,
        "div": 4,         # calidad baja para FPS jugable en movil
        "auto_quality": False,  # no cambiar div automaticamente
        "gl": False,      # no usar OpenGL en Android (GLES != GL)
        "sensitivity": 0.0035,  # sensibilidad del drag-aim (mas alta que PC)
    }
