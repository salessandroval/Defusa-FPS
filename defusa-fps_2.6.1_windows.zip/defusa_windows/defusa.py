#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Defusa FPS - shooter estilo Counter-Strike 1.6 (modo desactivar bomba) con LAN y bots.

Terroristas (T) plantan la bomba en el sitio A o B; Antiterroristas (CT) la desactivan.
Servidor autoritativo por UDP (puerto 27015). Descubrimiento LAN por broadcast.
"""
import argparse
import json
import math
import struct
# 2.5: fcntl solo existe en Unix. En Windows lo importamos como None
# para que el codigo que lo usa pueda detectarlo con try/except.
try:
    import fcntl
except ImportError:
    fcntl = None
import os
import random
import socket
import sys
import time
import zlib
import re
import shutil
import subprocess
import tempfile
import urllib.request
import urllib.error
from collections import deque

try:
    import r3d
except Exception:      # el servidor sin gráficos no necesita numpy
    r3d = None

VERSION = "2.6.1"

# 2.4.2: estado del servidor dedicado arrancado desde el menu.
# Es None cuando no hay servidor corriendo, o un dict con {server, thread,
# state, running, ips, port, name, map, bots} cuando si lo hay.
_DEDICATED_SERVER = None

# 2.5: detecta Android para evitar codigo que crashea en movil.
_IS_ANDROID = False
try:
    if os.environ.get("ANDROID_ROOT") or os.path.exists("/system/bin/am"):
        _IS_ANDROID = True
    import android
    _IS_ANDROID = True
except ImportError:
    pass
except Exception:
    pass


# Actualizador automático desde GitHub.
UPDATE_OWNER = "salessandroval"
UPDATE_REPO = "Defusa-FPS"
UPDATE_BRANCH = "main"
# 2.2: el actualizador ahora consulta primero GitHub Releases (que es la via
# oficial para binarios grandes en GitHub) y despues el contents API como
# fallback. Admite un directorio local de actualizaciones para quien quiera
# distribuir el .deb por USB o red local sin pasar por Internet.
UPDATE_RELEASES_API = "https://api.github.com/repos/%s/%s/releases" % (UPDATE_OWNER, UPDATE_REPO)
UPDATE_CONTENTS_API = "https://api.github.com/repos/%s/%s/contents/?ref=%s" % (UPDATE_OWNER, UPDATE_REPO, UPDATE_BRANCH)
UPDATE_TIMEOUT = 10
# Directorios locales de actualizaciones: el sistema mira aqui SIEMPRE antes
# de tocar la red. Cualquiera puede dejar un .deb ahi y se instalara en el
# siguiente arranque. util para maquinas sin Internet o para distribucion
# por pendrive USB / NAS casero.
# 2.5: en Android, ~ puede no ser escribible. Anadimos /tmp como fallback.
LOCAL_UPDATE_DIRS = (
    "/var/lib/defusa-fps/updates",
    os.path.expanduser("~/.config/defusa-fps/updates"),
    os.path.expanduser("~/.defusa-fps/updates"),
    "/tmp/defusa-fps/updates",
)
# Cache de la respuesta de la API para no agotar el limite de 60 peticiones
# por hora de GitHub anonimo. TTL de 1 hora.
UPDATE_CACHE_TTL = 3600
# 2.5: UPDATE_CACHE_PATH se define despues de _config_dir() para que
# funcione correctamente en Android.
UPDATE_CACHE_PATH = None  # se inicializa despues de _config_dir()


def _config_dir():
    """Devuelve (y crea si hace falta) el directorio de configuracion del usuario."""
    # 2.5: en Android, ~ puede apuntar a un directorio no escribible.
    # Intentamos varias rutas hasta encontrar una que funcione.
    candidates = [
        os.path.expanduser("~/.config/defusa-fps"),
        os.path.expanduser("~/.defusa-fps"),
        "/tmp/defusa-fps",
    ]
    if _IS_ANDROID:
        candidates.insert(0, os.path.join(os.path.expanduser("~"), "defusa-fps"))
    for path in candidates:
        try:
            os.makedirs(path, exist_ok=True)
            test_file = os.path.join(path, ".write_test")
            with open(test_file, "w") as f:
                f.write("ok")
            os.unlink(test_file)
            return path
        except (OSError, IOError):
            continue
    path = "/tmp/defusa-fps"
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        pass
    return path


# 2.5: ahora que _config_dir() existe, inicializamos UPDATE_CACHE_PATH.
if _IS_ANDROID:
    UPDATE_CACHE_PATH = os.path.join(_config_dir(), "github-api.json")
else:
    UPDATE_CACHE_PATH = os.path.expanduser("~/.cache/defusa-fps/github-api.json")


# --- Estadisticas vitales persistentes (2.2) --------------------------------
# Se guardan en ~/.config/defusa-fps/stats.json y acumulan K/D, headshots,
# rondas ganadas/perdidas y partidas jugadas a lo largo de todas las sesiones.
# Es informacion puramente local: nunca se envia a ningun servidor.
STATS_PATH = os.path.join(_config_dir(), "stats.json")


def load_stats():
    """Carga las estadisticas acumuladas del jugador. Devuelve un dict con
    valores por defecto si no existe o esta corrupto."""
    defaults = {
        "kills": 0, "deaths": 0, "headshots": 0,
        "rounds_won": 0, "rounds_lost": 0, "matches_played": 0,
        "matches_won": 0, "bombs_planted": 0, "bombs_defused": 0,
        "best_streak": 0, "current_streak": 0,
    }
    try:
        with open(STATS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            for k, v in defaults.items():
                data.setdefault(k, v)
            return data
    except (OSError, ValueError, json.JSONDecodeError):
        pass
    return defaults


def save_stats(stats):
    """Persiste las estadisticas en disco. Silencioso si falla."""
    try:
        with open(STATS_PATH, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2)
    except (OSError, ValueError):
        pass


def add_kill_to_stats():
    """Incrementa las bajas y la racha actual del jugador local."""
    s = load_stats()
    s["kills"] += 1
    s["current_streak"] += 1
    if s["current_streak"] > s["best_streak"]:
        s["best_streak"] = s["current_streak"]
    save_stats(s)


def add_death_to_stats():
    s = load_stats()
    s["deaths"] += 1
    s["current_streak"] = 0
    save_stats(s)


def add_headshot_to_stats():
    s = load_stats()
    s["headshots"] += 1
    save_stats(s)


def add_round_to_stats(won):
    s = load_stats()
    if won:
        s["rounds_won"] += 1
    else:
        s["rounds_lost"] += 1
    save_stats(s)


def add_match_to_stats(won):
    s = load_stats()
    s["matches_played"] += 1
    if won:
        s["matches_won"] += 1
    save_stats(s)


def add_bomb_event_to_stats(kind):
    """kind: 'planted' o 'defused'."""
    s = load_stats()
    if kind == "planted":
        s["bombs_planted"] += 1
    elif kind == "defused":
        s["bombs_defused"] += 1
    save_stats(s)


def _version_key(v):
    """Convierte una versión x.y.z en una tupla comparable."""
    nums = re.findall(r"\d+", str(v))
    return tuple(int(x) for x in nums[:4]) or (0,)


def _github_fetch(url, cache_key=None):
    """Hace una peticion GET a la API de GitHub con cache de 1h para evitar
    rate limits. Devuelve el JSON decodificado o None si falla."""
    cache_dir = os.path.dirname(UPDATE_CACHE_PATH)
    try:
        os.makedirs(cache_dir, exist_ok=True)
    except OSError:
        pass
    # Si la cache es fresca, devolverla.
    if cache_key and os.path.exists(UPDATE_CACHE_PATH):
        try:
            if time.time() - os.path.getmtime(UPDATE_CACHE_PATH) < UPDATE_CACHE_TTL:
                with open(UPDATE_CACHE_PATH, "r", encoding="utf-8") as f:
                    cache = json.load(f)
                if cache.get("key") == cache_key:
                    return cache.get("data")
        except (OSError, ValueError, json.JSONDecodeError):
            pass
    # Peticion real con User-Agent (GitHub rechaza peticiones sin UA).
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Defusa-FPS/%s" % VERSION,
                     "Accept": "application/vnd.github+json"},
        )
        with urllib.request.urlopen(req, timeout=UPDATE_TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError,
            OSError, ValueError, json.JSONDecodeError):
        return None
    if cache_key:
        try:
            with open(UPDATE_CACHE_PATH, "w", encoding="utf-8") as f:
                json.dump({"key": cache_key, "ts": time.time(), "data": data}, f)
        except (OSError, ValueError):
            pass
    return data


def _scan_local_updates():
    """Busca paquetes de actualizacion en los directorios locales.

    2.6.1: cross-platform. En Linux busca .deb, en Windows/Android busca .zip.
    Devuelve (version, path) de la version mas alta encontrada, o None.
    """
    suffix, ext = _detect_platform_suffix()
    # Patron flexible: acepta tanto el sufijo de la plataforma como .deb/.zip
    # genericos por si alguien pone un archivo con otro nombre.
    pattern_suffix = suffix.replace(".", r"\.")
    candidates = []
    created_hint = False
    for d in LOCAL_UPDATE_DIRS:
        try:
            os.makedirs(d, exist_ok=True)
            if not created_hint and os.access(d, os.W_OK):
                # Crea un README.txt solo la primera vez para guiar al usuario.
                readme = os.path.join(d, "README.txt")
                if not os.path.exists(readme):
                    with open(readme, "w", encoding="utf-8") as f:
                        f.write("Deja aqui un archivo de defusa-fps (%s) y se\n"
                                "instalara automaticamente en el siguiente arranque.\n" % ext)
                created_hint = True
        except OSError:
            continue
        try:
            for name in os.listdir(d):
                # 2.6.1: busca el sufijo de la plataforma actual.
                m = re.match(r"^defusa-fps_([0-9][0-9A-Za-z._~-]*)%s$" % pattern_suffix, name)
                if not m:
                    continue
                full = os.path.join(d, name)
                if os.path.isfile(full) and os.access(full, os.R_OK):
                    candidates.append((m.group(1), full))
        except OSError:
            continue
    if not candidates:
        return None
    return max(candidates, key=lambda x: _version_key(x[0]))


def _detect_platform_suffix():
    """Devuelve el sufijo de archivo correcto para la plataforma actual.
    - Linux: _all.deb
    - Windows: _windows.zip
    - Android: _android.zip
    """
    if _IS_ANDROID:
        return ("_android.zip", ".zip")
    if sys.platform == "win32":
        return ("_windows.zip", ".zip")
    return ("_all.deb", ".deb")


def _github_latest():
    """Busca el paquete mas reciente en GitHub para la plataforma actual.

    2.6.1: cross-platform. Antes solo buscaba .deb (Linux).
    Ahora busca .deb, _windows.zip o _android.zip segun la plataforma.

    Devuelve (version, filename, url) o None si no hay nada nuevo.
    """
    suffix, ext = _detect_platform_suffix()
    # Patron de nombre: defusa-fps_VERSION_SUFFIX
    # Ej: defusa-fps_2.6.1_all.deb, defusa-fps_2.6.1_windows.zip
    pattern = r"^defusa-fps_([0-9][0-9A-Za-z._~-]*)%s$" % suffix.replace(".", r"\.")

    # 1) Releases API.
    data = _github_fetch(UPDATE_RELEASES_API, cache_key="releases")
    if isinstance(data, list):
        candidates = []
        for release in data:
            for asset in release.get("assets", []) or []:
                name = asset.get("name", "")
                m = re.match(pattern, name)
                if not m:
                    continue
                url = asset.get("browser_download_url")
                size = asset.get("size", 0)
                if url and size > 10240:
                    candidates.append((m.group(1), name, url))
        if candidates:
            return max(candidates, key=lambda x: _version_key(x[0]))
    # 2) Fallback: contents API.
    data = _github_fetch(UPDATE_CONTENTS_API, cache_key="contents")
    candidates = []
    if isinstance(data, list):
        for item in data:
            name = item.get("name", "")
            m = re.match(pattern, name)
            if not m:
                continue
            url = item.get("download_url")
            if url:
                candidates.append((m.group(1), name, url))
    if not candidates:
        return None
    return max(candidates, key=lambda x: _version_key(x[0]))


def _install_deb(path):
    """Instala el .deb (Linux) o .zip (Windows) pidiendo permisos.

    2.5: cross-platform. En Linux usa apt-get con pkexec/sudo.
    En Windows no hay .deb ni apt-get, asi que devuelve False y el
    instalador manual (el .zip para Windows) se encarga.
    """
    # Windows: no hay .deb ni apt-get. El auto-update no aplica.
    if sys.platform == "win32" or fcntl is None:
        return False
    env = os.environ.copy()
    env["DEBIAN_FRONTEND"] = "noninteractive"
    commands = []
    # ¿Somos root? Entonces no hace falta pedir nada.
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        commands.append(["apt-get", "install", "-y", path])
    if shutil.which("pkexec"):
        commands.append(["pkexec", "apt-get", "install", "-y", path])
    if shutil.which("sudo"):
        # -n = no pedir contrasena (falla rapido si sudo requiere password).
        commands.append(["sudo", "-n", "apt-get", "install", "-y", path])
    for cmd in commands:
        try:
            p = subprocess.run(cmd, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True, timeout=240)
            if p.returncode == 0:
                return True
        except (OSError, subprocess.SubprocessError):
            continue
    return False


def check_for_updates(silent=True):
    """Comprueba e instala la version superior disponible.

    Orden de prioridad:
      1) Directorio local de actualizaciones (~/.config/defusa-fps/updates o
         /var/lib/defusa-fps/updates). util para instalaciones aisladas.
      2) GitHub Releases API (via oficial para binarios).
      3) GitHub contents API (fallback para repos sin Releases).

    Devuelve True si se instalo algo nuevo (el llamador debera reiniciar).
    Devuelve False si no habia actualizaciones o si fallo la instalacion.
    """
    # 1) Local: sin red, sin contrasena si los permisos lo permiten.
    local = _scan_local_updates()
    if local:
        local_version, local_path = local
        if _version_key(local_version) > _version_key(VERSION):
            if not silent:
                sys.stderr.write("Defusa: instalando actualizacion local %s...\n" % local_version)
            if _install_deb(local_path):
                # Tras instalar, borra el .deb local para no reinstalarlo.
                try:
                    os.unlink(local_path)
                except OSError:
                    pass
                return True
            elif not silent:
                sys.stderr.write("Defusa: no se pudo instalar %s. Ejecuta manualmente:\n"
                                 "  sudo apt-get install -y %s\n" % (local_version, local_path))
            return False
    # 2) y 3) GitHub: busca el paquete para la plataforma actual.
    try:
        latest = _github_latest()
        if not latest:
            return False
        remote_version, filename, url = latest
        if _version_key(remote_version) <= _version_key(VERSION):
            return False
        if not silent:
            sys.stderr.write("Defusa: descargando %s desde GitHub...\n" % remote_version)
        # 2.6.1: usa la extension correcta segun la plataforma.
        suffix, ext = _detect_platform_suffix()
        fd, path = tempfile.mkstemp(prefix="defusa-update-", suffix=ext)
        os.close(fd)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Defusa-FPS/%s" % VERSION})
            with urllib.request.urlopen(req, timeout=60) as r, open(path, "wb") as f:
                shutil.copyfileobj(r, f)
            size = os.path.getsize(path)
            if size < 10240:
                # Descarta archivos obviamente corruptos.
                if not silent:
                    sys.stderr.write("Defusa: descarga incompleta (%d bytes).\n" % size)
                return False
            if not silent:
                sys.stderr.write("Defusa: instalando %s (%d KB)...\n" % (remote_version, size // 1024))
            if not _install_deb(path):
                if not silent:
                    sys.stderr.write("Defusa: no se pudo instalar. Ejecuta manualmente:\n"
                                     "  sudo apt-get install -y %s\n" % path)
                return False
            return True
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError,
            OSError, ValueError, json.JSONDecodeError) as e:
        if not silent:
            sys.stderr.write("Defusa: error al buscar actualizaciones: %s\n" % e)
        return False


def update_available_info():
    """Devuelve (version, source) de la actualizacion disponible, o None.
    NO instala nada: solo informa. Util para el menu cuando el usuario
    pulsa 'Buscar actualizaciones'."""
    # Local primero.
    local = _scan_local_updates()
    if local and _version_key(local[0]) > _version_key(VERSION):
        return (local[0], "local: %s" % local[1])
    # GitHub: busca el paquete para la plataforma actual.
    latest = _github_latest()
    if latest and _version_key(latest[0]) > _version_key(VERSION):
        suffix, _ = _detect_platform_suffix()
        return (latest[0], "github: %s (%s)" % (latest[1], suffix))
    return None

PORT = 27015
TICK = 1.0 / 60.0
SNAP_HZ = 20
MAX_HUMANS = 8

# ---------------------------------------------------------------- reglas
FREEZE_T = 3.0
ROUND_T = 100.0
OVER_T = 5.0
PLANT_T = 3.0
DEFUSE_T = 5.0
BOMB_T = 35.0
WIN_ROUNDS = 7
SPEED = 3.4
TURN_BOT = 2.8
START_MONEY = 800
MAX_MONEY = 16000
ARMOR_PRICE = 650
KIT_PRICE = 200
BUY_WINDOW = 15.0
# --- 2.4: granadas ---------------------------------------------------------
# Tipos de granada con sus parametros. No son entradas en WEAPONS porque
# no se disparan: se lanzan con trayectoria parabolica y detonan solas.
# La tienda las vende por separado (slot 4). Los precios son como CS 1.6.
GRENADES = {
    "he":     dict(name="Granada HE",   price=300, dmg=85, radius=3.5, fuse=1.6),
    "flash":  dict(name="Flashbang",    price=200, dmg=0,   radius=6.0, fuse=1.4, flash_time=3.0),
    "smoke":  dict(name="Humo",         price=300, dmg=0,   radius=4.0, fuse=1.5, smoke_time=15.0),
}
GRENADE_ORDER = ["he", "flash", "smoke"]
MAX_HE = 1
MAX_FLASH = 2
MAX_SMOKE = 1
GRENADE_THROW_SPEED = 9.5       # velocidad inicial del lanzamiento
GRENADE_GRAVITY = 12.0            # gravedad en unidades del mundo
GRENADE_BOUNCE = 0.4              # factor de rebote en el suelo
GRENADE_FRICTION = 0.7            # friccion horizontal tras rebote
WEAPONS = {
    # Pistolas
    "usp": dict(name="USP", price=0, team="C", slot=2, dmg=20, cd=0.15, mag=12, reload=1.6, spread=0.010, move=0.035, pellets=1),
    "glock": dict(name="Glock-18", price=400, team="T", slot=2, dmg=18, cd=0.15, mag=20, reload=2.2, spread=0.018, move=0.040, pellets=1),
    "p228": dict(name="P228", price=600, team=None, slot=2, dmg=32, cd=0.20, mag=13, reload=2.0, spread=0.014, move=0.038, pellets=1),
    "deagle": dict(name="Desert Eagle", price=650, team=None, slot=2, dmg=46, cd=0.33, mag=7, reload=2.0, spread=0.008, move=0.04, pellets=1),
    "fiveseven": dict(name="Five-SeveN", price=750, team="C", slot=2, dmg=22, cd=0.15, mag=20, reload=2.2, spread=0.018, move=0.038, pellets=1),
    "elite": dict(name="Dual Berettas", price=800, team="T", slot=2, dmg=23, cd=0.14, mag=30, reload=2.6, spread=0.025, move=0.045, pellets=1),
    # Escopetas y SMG
    "m3": dict(name="Escopeta M3", price=1700, team=None, slot=1, dmg=11, cd=0.85, mag=8, reload=2.6, spread=0.07, move=0.02, pellets=8),
    "xm1014": dict(name="XM1014", price=3000, team=None, slot=1, dmg=9, cd=0.35, mag=7, reload=2.5, spread=0.075, move=0.025, pellets=8),
    "tmp": dict(name="TMP", price=1250, team="C", slot=1, dmg=14, cd=0.065, mag=30, reload=2.1, spread=0.032, move=0.035, pellets=1),
    "mac10": dict(name="MAC-10", price=1400, team="T", slot=1, dmg=17, cd=0.075, mag=30, reload=2.4, spread=0.035, move=0.04, pellets=1),
    "mp5": dict(name="MP5", price=1500, team=None, slot=1, dmg=17, cd=0.075, mag=30, reload=2.2, spread=0.028, move=0.03, pellets=1),
    "ump45": dict(name="UMP-45", price=1700, team=None, slot=1, dmg=20, cd=0.105, mag=25, reload=2.3, spread=0.032, move=0.035, pellets=1),
    "p90": dict(name="P90", price=2350, team=None, slot=1, dmg=17, cd=0.055, mag=50, reload=3.0, spread=0.035, move=0.035, pellets=1),
    # Rifles
    "galil": dict(name="Galil", price=2000, team="T", slot=1, dmg=27, cd=0.105, mag=35, reload=2.5, spread=0.025, move=0.042, pellets=1),
    "famas": dict(name="FAMAS", price=2250, team="C", slot=1, dmg=25, cd=0.105, mag=25, reload=2.4, spread=0.024, move=0.040, pellets=1),
    "ak47": dict(name="AK-47", price=2500, team="T", slot=1, dmg=28, cd=0.10, mag=30, reload=2.4, spread=0.020, move=0.04, pellets=1),
    "m4a1": dict(name="M4A1", price=3100, team="C", slot=1, dmg=24, cd=0.09, mag=30, reload=2.3, spread=0.014, move=0.035, pellets=1),
    "sg552": dict(name="SG 552", price=3500, team="T", slot=1, dmg=27, cd=0.09, mag=30, reload=2.4, spread=0.018, move=0.038, pellets=1),
    "aug": dict(name="AUG", price=3500, team="C", slot=1, dmg=28, cd=0.09, mag=30, reload=2.4, spread=0.016, move=0.035, pellets=1),
    # Francotiradores / pesada
    "scout": dict(name="Scout", price=2750, team=None, slot=1, dmg=75, cd=1.1, mag=10, reload=2.8, spread=0.006, move=0.10, pellets=1),
    "awp": dict(name="AWP", price=4750, team=None, slot=1, dmg=115, cd=1.4, mag=10, reload=3.0, spread=0.002, move=0.12, pellets=1),
    "g3sg1": dict(name="G3SG1", price=5000, team="T", slot=1, dmg=80, cd=0.25, mag=20, reload=3.2, spread=0.020, move=0.10, pellets=1),
    "sg550": dict(name="SG 550", price=4200, team="C", slot=1, dmg=80, cd=0.25, mag=30, reload=3.2, spread=0.020, move=0.10, pellets=1),
    "m249": dict(name="M249", price=5750, team=None, slot=1, dmg=32, cd=0.08, mag=100, reload=4.0, spread=0.035, move=0.07, pellets=1),
    # Cuchillo: siempre disponible, sin munición y con ataque cuerpo a cuerpo.
    "knife": dict(name="Cuchillo", price=0, team=None, slot=3, dmg=55, cd=0.45, mag=0, reload=0.0, spread=0.0, move=0.0, pellets=1, melee=True, range=1.65),
    # --- 2.5: cuchillos coleccionables con modelos 3D propios ---
    # Cada cuchillo tiene el mismo dano que el basico pero con modelo 3D distinto.
    # Se compran en la tienda y se equipan en slot 3 (reemplazan el cuchillo basico).
    "karambit": dict(name="Karambit", price=500, team=None, slot=3, dmg=60, cd=0.40, mag=0, reload=0.0, spread=0.0, move=0.0, pellets=1, melee=True, range=1.75),
    "butterfly": dict(name="Butterfly", price=600, team=None, slot=3, dmg=55, cd=0.38, mag=0, reload=0.0, spread=0.0, move=0.0, pellets=1, melee=True, range=1.70),
    "bayonet": dict(name="Bayonet", price=700, team=None, slot=3, dmg=60, cd=0.42, mag=0, reload=0.0, spread=0.0, move=0.0, pellets=1, melee=True, range=1.80),
    "talon": dict(name="Talon", price=800, team=None, slot=3, dmg=65, cd=0.45, mag=0, reload=0.0, spread=0.0, move=0.0, pellets=1, melee=True, range=1.75),
    "flip": dict(name="Flip", price=550, team=None, slot=3, dmg=55, cd=0.40, mag=0, reload=0.0, spread=0.0, move=0.0, pellets=1, melee=True, range=1.70),
    # --- Armas nuevas 2.1: 4 modelos propios en r3d.WEAPON_MODELS.
    # R8 Revolver: pistolón de alto dano por tiro, lento y caro. Comparable
    # al deagle pero con un perfil distinto: dano mayor por bala, menos
    # precision a distancia y recarga mas larga.
    "r8": dict(name="R8 Revolver", price=850, team=None, slot=2, dmg=55, cd=0.45, mag=8, reload=2.4, spread=0.014, move=0.045, pellets=1),
    # MP9: subfusil rapido y barato para CT, equivalente al MAC-10 del T.
    # Cadencia muy alta, dano modesto y buen control en movimiento.
    "mp9": dict(name="MP9", price=1250, team="C", slot=1, dmg=15, cd=0.060, mag=30, reload=2.2, spread=0.030, move=0.038, pellets=1),
    # Sawed-Off: escopeta recortada de muy corto alcance. Letal a quemarropa
    # pero inutil a media distancia, alternativa callejera al M3.
    "sawedoff": dict(name="Sawed-Off", price=1100, team="T", slot=1, dmg=10, cd=0.95, mag=7, reload=2.4, spread=0.10, move=0.025, pellets=8),
    # CZ75-Auto: pistola automática de cargador grande. Sustituta de la
    # Five-SeveN/Elite para quien prefiere cadencia sobre dano por tiro.
    "cz75": dict(name="CZ75-Auto", price=500, team=None, slot=2, dmg=20, cd=0.10, mag=12, reload=2.3, spread=0.020, move=0.040, pellets=1),
}

WEAPON_ORDER = list(WEAPONS)

# ---------------------------------------------------------------- mapas
# Cada mapa conserva las mismas dimensiones (32x24) para que el motor 3D,
# el raycasting y el minimapa sigan funcionando sin cambios estructurales.
# Lo que cambia entre mapas es la disposicion de paredes, cajas, sitios y
# spawns, lo que se traduce en tacticas distintas para cada arena.
W, H = 32, 24


def _rect(g, x0, y0, x1, y1, v=1):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            g[y][x] = v


class MapDef:
    """Definicion de un mapa de bomba.

    Atributos publicos:
      name  - identificador corto (de_dust2, de_aztec, ...)
      title - nombre legible para menus y HUD
      theme - clave de paleta/textura usada por el motor 3D
      grid  - matriz [H][W] con 0=vacio, 1=pared, 2=caja
      sites - {"A": (x0,y0,x1,y1), "B": (x0,y0,x1,y1)}
      spawns- {"T": [(x,y)...], "C": [(x,y)...]}
      site_cells - celdas libres dentro de cada sitio (precalculado)
    """

    def __init__(self, name, title, theme, grid, sites, spawns):
        self.name = name
        self.title = title
        self.theme = theme
        self.W, self.H = W, H
        self.grid = grid
        self.sites = dict(sites)
        # Filtra celdas bloqueadas de los spawns por seguridad: si un mapa
        # define un spawn que cae sobre una pared/caja, se ignora en lugar
        # de atrapar al jugador dentro del muro al reaparecer.
        self.spawns = {
            k: [(x, y) for (x, y) in v if 0 <= x < W and 0 <= y < H and grid[y][x] == 0]
            for k, v in spawns.items()
        }
        self.site_cells = {
            k: [(x, y) for x in range(r[0], r[2] + 1) for y in range(r[1], r[3] + 1)
                if self.grid[y][x] == 0]
            for k, r in self.sites.items()
        }

    def site_at(self, x, y):
        for k, (x0, y0, x1, y1) in self.sites.items():
            if x0 <= x < x1 + 1 and y0 <= y < y1 + 1:
                return k
        return None


# ---- Constructores de cada mapa --------------------------------------------

def _border(g):
    _rect(g, 0, 0, W - 1, 0); _rect(g, 0, H - 1, W - 1, H - 1)
    _rect(g, 0, 0, 0, H - 1); _rect(g, W - 1, 0, W - 1, H - 1)


def _build_dust2():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Calles en T, balcones laterales y patio central
    for y in range(3,21):
        if y not in (8,9,14,15): g[y][9]=1
        if y not in (5,6,17,18): g[y][22]=1
    for x in range(3,29):
        if x not in (12,13,18,19): g[11][x]=1
    for x,y in ((5,5),(6,5),(25,18),(26,18),(14,7),(17,16),(12,19),(19,4)):
        g[y][x]=2
    return g


def _build_aztec():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Templo con patio interior, columnas y agua
    _rect(g,11,7,20,16,1); _rect(g,13,9,18,14,0)
    g[8][15]=g[8][16]=0; g[15][15]=g[15][16]=0
    for x,y in ((7,5),(7,18),(24,5),(24,18),(10,11),(21,12)): g[y][x]=1
    for x,y in ((4,9),(5,9),(26,14),(27,14),(8,20),(23,3)): g[y][x]=2
    # puentes estrechos
    for x in range(2,11):
        if x not in (5,6): g[11][x]=1
    for x in range(21,30):
        if x not in (25,26): g[12][x]=1
    return g


def _build_nuke():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Dos plantas simuladas: corredores, salas y reactor central
    _rect(g,5,3,11,7,1); _rect(g,20,3,26,7,1)
    _rect(g,5,16,11,20,1); _rect(g,20,16,26,20,1)
    for y in range(8,16):
        if y not in (10,11,14): g[y][12]=1
        if y not in (9,10,13): g[y][19]=1
    _rect(g,14,9,17,14,1); _rect(g,15,10,16,13,0)
    for x,y in ((13,8),(18,8),(13,15),(18,15),(8,10),(23,13)): g[y][x]=2
    return g


def _build_inferno():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Barrio: calle central, casas irregulares y dos plazas
    for x in range(3,29):
        if x not in (8,9,15,16,22,23): g[12][x]=1
    _rect(g,4,3,9,8,1); _rect(g,22,15,27,20,1)
    _rect(g,12,3,14,7,1); _rect(g,17,16,19,20,1)
    for x,y in ((5,10),(7,10),(24,10),(26,10),(11,15),(20,8),(14,18),(17,5)): g[y][x]=2
    return g


def _build_mirage():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Palacio en L y plaza abierta con rampas de cobertura
    _rect(g,4,3,10,9,1); _rect(g,21,14,27,20,1)
    _rect(g,5,15,8,20,1); _rect(g,23,3,27,8,1)
    for y in range(5,19):
        if y not in (8,9,15,16): g[y][15]=1
        if y not in (11,12): g[y][18]=1
    for x,y in ((12,6),(13,6),(20,17),(21,17),(10,13),(23,11),(15,20),(18,3)): g[y][x]=2
    return g


def _build_cache():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Complejo industrial: almacenes, contenedores y patio de carga
    _rect(g,4,3,11,8,1); _rect(g,20,15,27,20,1)
    for y in range(4,8):
        if y not in (5,7): g[y][12]=1
    for y in range(16,20):
        if y not in (17,19): g[y][19]=1
    for x,y in ((13,8),(14,8),(17,15),(18,15),(13,12),(14,12),(17,11),(18,11),(6,12),(25,11)): g[y][x]=2
    return g


def _build_overpass():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Dos niveles visuales: pilares, carretera y refugios bajo puente
    for x in (6,7,24,25):
        _rect(g,x,4,x+1,8,1); _rect(g,x,15,x+1,19,1)
    for x in range(9,24):
        if x not in (13,14,19,20): g[10][x]=1
    for x in range(9,24):
        if x not in (11,12,17,18): g[13][x]=1
    for x,y in ((4,11),(8,14),(23,9),(27,12),(15,7),(16,16)): g[y][x]=2
    return g


def _build_train():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Tres filas de vagones y cruces transversales
    for x0,x1 in ((5,9),(14,18),(23,27)):
        _rect(g,x0,3,x1,8,1); _rect(g,x0,15,x1,20,1)
        for y in (4,7,16,19):
            g[y][x0]=g[y][x1]=0
    for x,y in ((11,10),(12,10),(20,13),(21,13),(4,12),(27,11),(14,5),(18,18)): g[y][x]=2
    for y in (9,14):
        for x in range(10,23):
            if x not in (13,14,18,19): g[y][x]=1
    return g


# --- Mapas nuevos 2.1 ---------------------------------------------------------
# Ambos respetan el grid 32x24 original para que el raycasting, el minimapa y
# los spawns sigan funcionando sin cambios estructurales.

def _build_mill():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Molino industrial nevado: dos naves laterales + patio central con
    # chimney stacks. Pensado para combates de media distancia con
    # angulos amplios en el centro y pasillos estrechos a los lados.
    _rect(g,3,3,9,9,1); _rect(g,22,14,28,20,1)
    _rect(g,4,4,8,8,0); _rect(g,23,15,27,19,0)
    # Puertas de las naves
    g[6][3]=0; g[17][28]=0
    # Chimeneas centrales: torres estrechas que dan cobertura sin cerrar paso.
    for y in range(4,20):
        if y not in (8,9,14,15): g[y][15]=1
        if y not in (10,11,16,17): g[y][16]=1
    # Andamios en forma de L en el centro-sur
    for x in range(12,20):
        if x not in (15,16): g[18][x]=1
    for y in range(13,19):
        if y not in (15,16): g[y][19]=1
    # Cajas estrategicas para cubrir rushes y crear angulos de peek.
    for x,y in ((10,5),(10,18),(21,5),(21,18),(13,12),(18,11),(6,12),(25,11)): g[y][x]=2
    return g


def _build_cbble():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Castillo de piedra: patio amurallado con torres en esquinas y dos
    # salas cubiertas. Diseñado para disparos largos y peeks por columnas.
    # Torres en las cuatro esquinas interiores
    for x0,y0,x1,y1 in ((4,4,6,6),(25,4,27,6),(4,17,6,19),(25,17,27,19)):
        _rect(g,x0,y0,x1,y1,1); g[(y0+y1)//2][(x0+x1)//2]=0
    # Muralla interior que divide el mapa en dos patios comunicados por
    # dos puertas centrales. Las puertas estan en x=15,16 a tres alturas.
    for x in (15,16):
        for y in range(2,22):
            if y not in (7,8,15,16): g[y][x]=1
    # Arcos decorativos: pilares aislados que dan cover sin bloquear paso.
    for x,y in ((10,8),(10,15),(21,8),(21,15),(12,12),(19,11)): g[y][x]=1
    # Cajas distribuidas para crear posiciones de defensa y ataque.
    for x,y in ((8,5),(8,18),(23,5),(23,18),(13,4),(18,19),(13,19),(18,4)): g[y][x]=2
    return g


# --- 2.6: mapas exteriores al aire libre -------------------------------------
# Estos mapas tienen cielo abierto (sin techo) y terrenos naturales.
# Diseñados para combates a larga distancia con cobertura natural.

def _build_jungle():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Jungla: claros en el bosque con arboles como cobertura y un rio central.
    # Rio horizontal en el medio (no bloquea, es visual).
    # Roca central grande que divide el mapa.
    for x in range(10,22):
        if x not in (14,15,18,19): g[11][x]=1
    # Arboles dispersos (paredes finas que dan cobertura sin cerrar pasos).
    for x,y in ((5,4),(8,8),(12,5),(20,7),(25,4),(5,18),(9,20),(14,19),(19,18),(24,20),(16,14),(18,15)): g[y][x]=1
    # Cajas de suministros abandonados.
    for x,y in ((7,12),(25,12),(13,8),(18,16),(6,15),(26,9)): g[y][x]=2
    # Ruinas de templo en el centro.
    _rect(g,14,9,17,13,1); g[11][15]=0; g[11][16]=0
    return g


def _build_riverside():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Riverside: mapa al aire libre junto a un rio. El rio es visual
    # (no bloquea). Tiene puentes estrechos y rocas como cobertura.
    # Puente central: 2 pasillos estrechos sobre el "rio".
    for y in range(9,15):
        if y not in (11,12): g[y][15]=1; g[y][16]=1
    # Rocas grandes en los lados del puente.
    for x,y in ((12,8),(12,15),(19,8),(19,15),(14,6),(17,17)): g[y][x]=1
    # Muros de contencion del rio.
    for x in range(2,14):
        if x not in (6,7): g[8][x]=1
    for x in range(18,30):
        if x not in (24,25): g[15][x]=1
    # Cajas y barriles junto al puente.
    for x,y in ((8,6),(8,17),(24,6),(24,17),(10,11),(21,12)): g[y][x]=2
    return g


def _build_canyon():
    g=[[0]*W for _ in range(H)]; _border(g)
    # Canyon: dos lados altos conectados por un paso estrecho central.
    # Las "paredes" del canyon son acantilados (paredes gruesas).
    _rect(g,2,2,10,5,1); _rect(g,21,18,29,21,1)
    _rect(g,2,18,10,21,1); _rect(g,21,2,29,5,1)
    # Paso estrecho en el centro.
    for y in range(6,18):
        if y not in (10,11,14,15): g[y][15]=1; g[y][16]=1
    # Rocas dispersas en el cauce del canyon.
    for x,y in ((8,8),(8,15),(24,8),(24,15),(12,10),(19,11),(12,14),(19,14)): g[y][x]=1
    # Cajas de suministros.
    for x,y in ((5,7),(5,16),(26,7),(26,16),(15,9),(16,14)): g[y][x]=2
    return g


# ---- Registro y mapa activo -----------------------------------------------

def _make_maps():
    out=[]
    specs=[
      ("de_dust2","Dust II","desert",_build_dust2,{"A":(2,2,8,6),"B":(23,17,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_aztec","Aztec","temple",_build_aztec,{"A":(2,2,7,6),"B":(24,17,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(15,21)],"C":[(x,y) for x in range(27,31) for y in range(2,8)]}),
      ("de_nuke","Nuke","reactor",_build_nuke,{"A":(13,2,18,7),"B":(13,16,18,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_inferno","Inferno","town",_build_inferno,{"A":(1,2,9,9),"B":(22,14,30,21)}, {"T":[(x,y) for x in range(1,5) for y in range(14,21)],"C":[(x,y) for x in range(27,31) for y in range(2,9)]}),
      ("de_mirage","Mirage","palace",_build_mirage,{"A":(8,2,16,7),"B":(15,16,23,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_cache","Cache","warehouse",_build_cache,{"A":(2,2,8,7),"B":(23,16,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_overpass","Overpass","highway",_build_overpass,{"A":(2,3,8,7),"B":(23,16,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(14,21)],"C":[(x,y) for x in range(27,31) for y in range(2,9)]}),
      ("de_train","Train","rail",_build_train,{"A":(2,2,6,7),"B":(25,16,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      # --- Mapas nuevos 2.1: themes snow y castle exclusivos.
      # de_mill: molino industrial nevado. Spawns T a la izquierda y CT a la
      # derecha, simetrico con dust2 para no romper habitos de jugadores.
      ("de_mill","Mill","snow",_build_mill,{"A":(2,2,8,7),"B":(23,16,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      # de_cbble: castillo de piedra. Spawns T arriba (patio norte) y CT
      # abajo (patio sur) para romper la simetria y dar variedad tactica.
      ("de_cbble","Cbble","castle",_build_cbble,{"A":(2,2,7,6),"B":(24,17,29,21)}, {"T":[(x,y) for x in range(1,8) for y in range(2,8)],"C":[(x,y) for x in range(24,31) for y in range(16,22)]}),
      # --- 2.6: mapas exteriores al aire libre ---
      ("de_jungle","Jungle","jungle",_build_jungle,{"A":(2,2,7,6),"B":(24,17,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_riverside","Riverside","riverside",_build_riverside,{"A":(2,2,7,6),"B":(24,17,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
      ("de_canyon","Canyon","canyon",_build_canyon,{"A":(2,2,7,6),"B":(24,17,29,21)}, {"T":[(x,y) for x in range(1,5) for y in range(9,15)],"C":[(x,y) for x in range(27,31) for y in range(9,15)]}),
    ]
    for name,title,theme,builder,sites,spawns in specs: out.append((name,MapDef(name,title,theme,builder(),sites,spawns)))
    return dict(out)


MAPS = _make_maps()
MAP_ORDER = ["de_dust2", "de_aztec", "de_nuke", "de_inferno", "de_mirage", "de_cache", "de_overpass", "de_train",
            "de_mill", "de_cbble",
            "de_jungle", "de_riverside", "de_canyon"]
ACTIVE_MAP = MAPS["de_dust2"]

# Espejos module-level: el resto del codigo sigue usando W, H, GRID, SITES,
# SPAWNS y SITE_CELLS como antes. Cuando se cambia de mapa, estos se
# reasignan y todas las funciones (cast, bfs, solid, minimapa, etc.)
# reflejan el mapa actual sin mas cambios.
GRID = ACTIVE_MAP.grid
SITES = ACTIVE_MAP.sites
SPAWNS = ACTIVE_MAP.spawns
SITE_CELLS = ACTIVE_MAP.site_cells


def set_active_map(name):
    """Cambia el mapa activo y actualiza los espejos module-level."""
    global ACTIVE_MAP, GRID, SITES, SPAWNS, SITE_CELLS
    m = MAPS.get(name) or MAPS[MAP_ORDER[0]]
    ACTIVE_MAP = m
    GRID = m.grid
    SITES = m.sites
    SPAWNS = m.spawns
    SITE_CELLS = m.site_cells
    return m


def site_at(x, y):
    return ACTIVE_MAP.site_at(x, y)


def solid(x, y):
    ix, iy = int(math.floor(x)), int(math.floor(y))
    return not (0 <= ix < W and 0 <= iy < H) or GRID[iy][ix] != 0


def blocked(x, y, r=0.25):
    return solid(x - r, y - r) or solid(x + r, y - r) or solid(x - r, y + r) or solid(x + r, y + r)


def cast(x, y, dx, dy, maxd=40.0):
    """DDA. (dx,dy) unitario. Devuelve (distancia, lado, valor_celda, fraccion_en_pared)."""
    mx, my = int(math.floor(x)), int(math.floor(y))
    ddx = abs(1.0 / dx) if dx else 1e30
    ddy = abs(1.0 / dy) if dy else 1e30
    if dx < 0:
        sx, sdx = -1, (x - mx) * ddx
    else:
        sx, sdx = 1, (mx + 1 - x) * ddx
    if dy < 0:
        sy, sdy = -1, (y - my) * ddy
    else:
        sy, sdy = 1, (my + 1 - y) * ddy
    side = 0
    while True:
        if sdx < sdy:
            d = sdx
            sdx += ddx
            mx += sx
            side = 0
        else:
            d = sdy
            sdy += ddy
            my += sy
            side = 1
        if d > maxd:
            return maxd, side, 0, 0.0
        if not (0 <= mx < W and 0 <= my < H):
            return d, side, 1, 0.0
        v = GRID[my][mx]
        if v:
            wx = (y + d * dy) if side == 0 else (x + d * dx)
            return d, side, v, wx - math.floor(wx)


def bfs(start, goal):
    if start == goal:
        return []
    prev = {start: None}
    dq = deque([start])
    while dq:
        c = dq.popleft()
        if c == goal:
            break
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (c[0] + dx, c[1] + dy)
            if n not in prev and 0 <= n[0] < W and 0 <= n[1] < H and GRID[n[1]][n[0]] == 0:
                prev[n] = c
                dq.append(n)
    if goal not in prev:
        return []
    path, c = [], goal
    while c != start:
        path.append(c)
        c = prev[c]
    path.reverse()
    return path


def angdiff(a, b):
    d = (a - b + math.pi) % (2 * math.pi) - math.pi
    return d


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


# ---------------------------------------------------------------- simulación
class P:
    def __init__(self, pid, name, team, bot):
        self.id = pid
        self.name = name[:12]
        self.team = team
        self.bot = bot
        self.x = self.y = 1.5
        self.a = 0.0
        self.hp = 100
        self.alive = False
        self.money = START_MONEY
        self.armor = 0.0
        self.kit = False
        self.slots = {1: None, 2: ("glock" if team == "T" else "usp"), 3: "knife"}
        self.cur = 2
        self.mags = {"usp": WEAPONS["usp"]["mag"], "glock": WEAPONS["glock"]["mag"], "knife": 0}
        self.last_bq = 0
        self.last_wq = 0
        # 2.2: loadout guardado de la ronda anterior para auto-compra con P.
        # None = sin loadout previo. Cada compra exitosa lo actualiza.
        self.last_loadout = None  # {"primary": str|None, "secondary": str|None, "armor": bool, "kit": bool}
        # 2.4: inventario de granadas. Cada jugador lleva hasta 1 HE, 2 flash,
        # 1 smoke. Se reinician al empezar la ronda y se compran en tienda.
        self.grenades = {"he": 0, "flash": 0, "smoke": 0}
        # Tipo de granada seleccionada para lanzar (se cicla con G).
        self.cur_grenade = "he"
        # Cooldown de lanzamiento (0.5s entre granadas) y flash recibido.
        self.grenade_cd = 0.0
        self.flash_until = 0.0  # timestamp del clock hasta el que el jugador esta cegado
        self.skin = "classic"   # 2.4: skin visual, no afecta al gameplay
        self.rel = 0.0
        self.cd = 0.0
        self.kills = 0
        self.deaths = 0
        self.headshots = 0
        # 2.4: añade 'gq' (grenade throw counter) y 'gt' (granada a lanzar)
        # al input del jugador. El cliente los incrementa al pulsar G+clic.
        self.inp = {"f": 0, "s": 0, "a": 0.0, "fire": False, "use": False, "rel": False,
                    "wq": 0, "w": 2, "bq": 0, "bi": "",
                    "gq": 0, "gt": "he", "gc": 0}  # gc = grenade cycle counter
        self.prog = 0.0
        self.has_bomb = False
        self.moving = False
        self.seen = time.time()
        # La habilidad del bot se mantiene en el rango historicamente suave
        # (0.24-0.62) para que la mejora de la IA sea tactica y no unfair:
        # los bots siguen fallando tiros, reaccionando con retardo y
        # disparando en rfagas cortas. Lo que cambia en 1.7 es la calidad
        # de las decisiones (defensa de sitio, recarga segura, cambio a
        # pistola, memoria de posicion, etc.).
        skill = random.uniform(0.24, 0.62)
        role = random.choice(("rush", "lurk", "anchor")) if bot else "human"
        self.ai = {"think": random.random() * 0.35, "target": None, "react": 0.0, "path": [],
                   "site": random.choice("AB"), "spot": (16, 4), "strafe_t": 0.0, "sd": 0,
                   "skill": skill, "aim_error": random.uniform(0.11, 0.24), "lost": 0.0,
                   "burst": random.randint(1, 4), "burst_left": 0, "pause": random.uniform(0.0, 0.5),
                   "last_seen": 0.0, "last_weapon": None,
                   # Nuevos campos 1.7: memoria, economia, rol y retreat.
                   "last_pos": None,            # (x, y, t) ultima posicion conocida del enemigo
                   "last_pos_t": -10.0,         # instante en que se registro
                   "role": role,                # rush / lurk / anchor (solo bots)
                   "save_until": 0,             # rondas de "eco" pendientes
                   "retreat": 0.0,              # temporizador de retirada cuando hp baja
                   "peek_t": 0.0,               # pequenas pausas antes de asomar a un angulo
                   "want_pistol": False}        # forzar cambio a pistola si primaria vacia

    def wname(self):
        return self.slots.get(self.cur) or self.slots[2]

    @property
    def ammo(self):
        return self.mags.get(self.wname(), 0)


class World:
    def __init__(self, team_size=4, start_map=None):
        self.players = {}
        self.next_id = 0
        self.team_size = team_size
        self.score = {"T": 0, "C": 0}
        self.round = 0
        self.phase = "wait"
        self.timer = 0.0
        self.msg = "Esperando jugadores..."
        self.match_over = False
        self.bomb = {"state": "none", "x": 0.0, "y": 0.0, "t": 0.0, "carrier": -1}
        # 2.4: granadas en vuelo y zonas de humo activas. Cada granada es un
        # dict con id, tipo, posicion, velocidad, fuse y dueno. Las zonas de
        # humo son circles {x, y, born_at, life} que el render usa para
        # dibujar niebla volumetrica.
        self.grenades = []
        self.smoke_zones = []
        self.next_grenade_id = 0
        self.ev = []
        self.evseq = 0
        self.feed = []
        self.clock = 0.0
        self.streak = {"T": 0, "C": 0}
        self.paused = False
        # Ciclo de mapas: el World guarda el indice actual dentro de MAP_ORDER
        # y avanza solo cuando termina una partida (WIN_ROUNDS alcanzados).
        # El modulo se sincroniza con set_active_map() para que el motor 3D
        # y el minimapa muestren el mapa correcto.
        self.map_index = 0
        if start_map in MAPS:
            self.map_index = MAP_ORDER.index(start_map)
        set_active_map(MAP_ORDER[self.map_index])
        self.map_name = MAP_ORDER[self.map_index]

    def current_map(self):
        return MAPS[self.map_name]

    def cycle_map(self):
        """Avanza al siguiente mapa del ciclo y reinicia el marcador."""
        self.map_index = (self.map_index + 1) % len(MAP_ORDER)
        self.map_name = MAP_ORDER[self.map_index]
        set_active_map(self.map_name)
        self.score = {"T": 0, "C": 0}
        self.streak = {"T": 0, "C": 0}
        self.round = 0
        for p in self.players.values():
            p.kills = p.deaths = p.headshots = 0
            p.money = START_MONEY
            # Reinicia decisiones de compra: el nuevo mapa puede tener
            # economia distinta y queremos que los bots recomiencen.
            p.ai["last_weapon"] = None
            p.ai["save_until"] = 0
            p.ai["last_pos"] = None
            p.ai["last_pos_t"] = -10.0
        self.msg = "Cambiando a mapa: %s" % MAPS[self.map_name].title

    # -- jugadores
    def count(self, team, humans_only=False):
        return sum(1 for p in self.players.values() if p.team == team and (not humans_only or not p.bot))

    def add_player(self, name, team, bot=False):
        pid = self.next_id
        self.next_id += 1
        self.players[pid] = P(pid, name, team, bot)
        return pid

    def remove_player(self, pid):
        p = self.players.pop(pid, None)
        if p and p.has_bomb and p.alive:
            self.drop_bomb(p)

    def balance_bots(self):
        names = ["Ivan", "Pablo", "Luis", "Marta", "Dani", "Rex", "Kira", "Toni", "Sofi", "Max"]
        for team in ("T", "C"):
            humans = self.count(team, True)
            want = max(0, self.team_size - humans) if self.team_size > 0 else 0
            bots = [p for p in self.players.values() if p.team == team and p.bot]
            while len(bots) > want:
                self.players.pop(bots.pop().id)
            while len(bots) < want:
                nm = "[BOT] " + random.choice(names)
                pid = self.add_player(nm, team, True)
                bots.append(self.players[pid])

    def add_event(self, typ, x, y, pid=-1):
        self.evseq += 1
        self.ev.append([self.evseq, typ, round(x, 1), round(y, 1), pid])
        self.ev = self.ev[-8:]

    # -- rondas
    def new_round(self):
        self.balance_bots()
        if not (self.count("T") and self.count("C")):
            self.phase = "wait"
            self.msg = "Esperando jugadores..."
            return
        # Asegura que el modulo refleja self.map_name (pudo haberse
        # cambiado desde el menu antes de la primera ronda).
        if MAPS[self.map_name] is not ACTIVE_MAP:
            set_active_map(self.map_name)
        fresh = self.round == 0
        self.round += 1
        for team in ("T", "C"):
            cells = SPAWNS[team][:]
            random.shuffle(cells)
            for p in [q for q in self.players.values() if q.team == team]:
                cx, cy = cells.pop()
                p.x, p.y = cx + 0.5, cy + 0.5
                p.a = 0.0 if team == "T" else math.pi
                if fresh:
                    p.money = START_MONEY
                if fresh or not p.alive:
                    p.slots, p.armor, p.kit = {1: None, 2: ("glock" if team == "T" else "usp")}, 0.0, False
                p.hp, p.alive, p.rel, p.cd = 100, True, 0.0, 0.0
                # 2.4: reinicia el inventario de granadas y el cooldown.
                p.grenades = {"he": 0, "flash": 0, "smoke": 0}
                p.grenade_cd = 0.0
                p.flash_until = 0.0
                # 2.4.1: asigna skin aleatoria a los bots al inicio de cada
                # ronda. Los jugadores humanos conservan su skin (la que
                # enviaron por red). Esto hace que cada bot tenga una skin
                # distinta y los equipos no se vean todos iguales.
                if p.bot:
                    bot_skins = ["classic", "arctic", "jungle", "desert", "urban"]
                    p.skin = random.choice(bot_skins)
                for wn in p.slots.values():
                    if wn:
                        p.mags[wn] = WEAPONS[wn]["mag"]
                p.cur = 1 if p.slots[1] else 2
                p.prog, p.has_bomb = 0.0, False
                p.ai.update(target=None, path=[], site=random.choice("AB"), think=random.random() * 0.3)
                # Elegir spot segun rol: los anchors defienden un sitio fijo,
                # los rushers van al bombsite contrario y los lurkers flanquean
                # por el sitio contrario. Esto da variedad tactica sin mejorar
                # la punteria ni el tiempo de reaccion.
                role = p.ai.get("role")
                if p.bot and role:
                    site = random.choice("AB")
                    if role == "anchor":
                        # CT ancla el sitio; T acecha en su bombsite favorito
                        site = p.team == "C" and site or p.ai["site"]
                    elif role == "rush":
                        # Empuja rapido al sitio contrario: si es T va a su sitio
                        # de ataque; si es CT va hacia el sitio amenazado.
                        pass
                    p.ai["site"] = site
                p.ai["spot"] = random.choice(SITE_CELLS[p.ai["site"]])
                # Resetea los estados de la 1.7 que duran una ronda.
                p.ai["last_pos"] = None
                p.ai["last_pos_t"] = -10.0
                p.ai["retreat"] = 0.0
                p.ai["peek_t"] = 0.0
                p.ai["want_pistol"] = False
        ts = [p for p in self.players.values() if p.team == "T"]
        carrier = random.choice(ts)
        carrier.has_bomb = True
        self.bomb = {"state": "carried", "x": carrier.x, "y": carrier.y, "t": 0.0, "carrier": carrier.id}
        self.phase = "freeze"
        self.timer = FREEZE_T
        self.msg = ""
        for p in list(self.players.values()):
            if p.bot:
                self.bot_buy(p)

    def end_round(self, team, msg):
        self.score[team] += 1
        loser = "C" if team == "T" else "T"
        self.streak[team] = 0
        self.streak[loser] = min(4, self.streak[loser] + 1)
        for q in self.players.values():
            bonus = 3250 if q.team == team else 1400 + 500 * (self.streak[q.team] - 1)
            q.money = min(MAX_MONEY, q.money + bonus)
        self.phase = "over"
        self.timer = OVER_T
        self.msg = msg
        if self.score[team] >= WIN_ROUNDS:
            self.match_over = True
            self.timer = 8.0
            self.msg = ("¡Ganan los Terroristas la partida!" if team == "T"
                        else "¡Ganan los Antiterroristas la partida!")

    def drop_bomb(self, p):
        p.has_bomb = False
        if self.bomb["state"] == "carried":
            self.bomb.update(state="dropped", x=p.x, y=p.y, carrier=-1)

    def die(self, victim, killer):
        victim.alive = False
        victim.hp = 0
        victim.deaths += 1
        victim.prog = 0.0
        weapon = killer.wname() if killer is not None else "world"
        headshot = getattr(victim, "_last_hs", False)
        victim._last_hs = False
        if killer is not None and killer.id != victim.id:
            killer.kills += 1
            killer.money = min(MAX_MONEY, killer.money + 300)
        if victim.has_bomb:
            self.drop_bomb(victim)
        kn = killer.name if killer else "?"
        # Si el asesino es un bot, anade una linea corta de sabor al feed.
        # Es puramente decorativo: no afecta a la IA ni a la jugabilidad.
        suffix = ""
        if killer is not None and killer.bot and random.random() < 0.55:
            line = random.choice(_BOT_KILL_LINES)
            suffix = "  (%s)" % line
        # Feed estructurado: el snapshot sigue exponiendo 'fd' como texto
        # plano para clientes antiguos, y agrega 'kf' con la info completa
        # para el HUD enriquecido del 2.0 (icono de arma, skull por HS).
        self.feed.append((self.clock + 5.0, "%s > %s%s" % (kn, victim.name, suffix),
                          killer.id if killer else -1, victim.id, weapon, headshot,
                          killer.team if killer else "?", victim.team))
        self.feed = self.feed[-8:]

    # -- bucle
    def update(self, dt):
        self.clock += dt
        if self.paused:
            return
        self.process_cmds()
        if self.phase == "wait":
            if self.count("T") and self.count("C"):
                self.new_round()
            else:
                self.balance_bots()
                if self.count("T") and self.count("C"):
                    self.new_round()
            return
        self.timer -= dt
        if self.phase == "freeze":
            if self.timer <= 0:
                self.phase, self.timer = "live", ROUND_T
            return
        if self.phase == "live":
            self.live(dt)
        elif self.phase == "over" and self.timer <= 0:
            if self.match_over:
                self.match_over = False
                # Al terminar la partida se rota al siguiente mapa del ciclo.
                self.cycle_map()
            self.new_round()

    def live(self, dt):
        for p in list(self.players.values()):
            if not p.alive:
                continue
            if p.bot:
                self.ai(p, dt)
            self.act(p, dt)
        # 2.4: actualiza las granadas en vuelo y zonas de humo activas.
        self.update_grenades(dt)
        b = self.bomb
        if b["state"] == "dropped":
            for p in self.players.values():
                if p.alive and p.team == "T" and math.hypot(p.x - b["x"], p.y - b["y"]) < 0.7:
                    p.has_bomb = True
                    b.update(state="carried", carrier=p.id)
                    break
        elif b["state"] == "planted":
            b["t"] -= dt
            if b["t"] <= 0:
                b["state"] = "exploded"
                self.add_event("b", b["x"], b["y"])
                self.end_round("T", "¡La bomba explotó! Ganan los Terroristas")
                return
        self.check_end()

    def check_end(self):
        if self.phase != "live":
            return
        alive_t = [p for p in self.players.values() if p.team == "T" and p.alive]
        alive_c = [p for p in self.players.values() if p.team == "C" and p.alive]
        planted = self.bomb["state"] == "planted"
        if not alive_c:
            self.end_round("T", "Ganan los Terroristas")
        elif not planted and not alive_t:
            self.end_round("C", "Ganan los Antiterroristas")
        elif not planted and self.timer <= 0:
            self.end_round("C", "Se acabó el tiempo. Ganan los Antiterroristas")

    def act(self, p, dt):
        inp = p.inp
        if not p.bot:
            p.a = inp["a"]
        p.cd = max(0.0, p.cd - dt)
        b = self.bomb
        use = inp["use"]
        acting = False
        if use and p.team == "T" and p.has_bomb and b["state"] == "carried" and site_at(p.x, p.y):
            acting = True
            p.prog += dt
            if p.prog >= PLANT_T:
                p.prog = 0.0
                p.has_bomb = False
                b.update(state="planted", x=p.x, y=p.y, t=BOMB_T, carrier=-1)
                self.add_event("p", p.x, p.y)
                p.money = min(MAX_MONEY, p.money + 300)
        elif (use and p.team == "C" and b["state"] == "planted"
              and math.hypot(p.x - b["x"], p.y - b["y"]) < 1.3):
            acting = True
            p.prog += dt
            if p.prog >= DEFUSE_T * (0.5 if p.kit else 1.0):
                p.prog = 0.0
                b["state"] = "defused"
                self.add_event("d", p.x, p.y)
                p.money = min(MAX_MONEY, p.money + 300)
                self.end_round("C", "¡Bomba desactivada! Ganan los Antiterroristas")
                return
        else:
            p.prog = 0.0
        # movimiento
        p.moving = False
        if not acting:
            f, s = clamp(inp["f"], -1, 1), clamp(inp["s"], -1, 1)
            vx = math.cos(p.a) * f - math.sin(p.a) * s
            vy = math.sin(p.a) * f + math.cos(p.a) * s
            n = math.hypot(vx, vy)
            if n > 1:
                vx, vy = vx / n, vy / n
            if n > 0:
                p.moving = True
                nx = p.x + vx * SPEED * dt
                if not blocked(nx, p.y):
                    p.x = nx
                ny = p.y + vy * SPEED * dt
                if not blocked(p.x, ny):
                    p.y = ny
        # recarga y disparo
        name = p.wname()
        st = WEAPONS[name]
        if st.get("melee"):
            if inp["fire"] and p.cd <= 0 and not acting:
                self.shoot(p)
        else:
            if p.rel > 0:
                p.rel -= dt
                if p.rel <= 0:
                    p.mags[name] = st["mag"]
            elif inp["rel"] and p.mags.get(name, 0) < st["mag"]:
                p.rel = st["reload"]
                self.add_event("r", p.x, p.y, p.id)
            if inp["fire"] and p.cd <= 0 and p.rel <= 0 and not acting:
                if p.mags.get(name, 0) <= 0:
                    p.rel = st["reload"]
                    self.add_event("r", p.x, p.y, p.id)
                else:
                    self.shoot(p)

    def shoot(self, p):
        name = p.wname()
        st = WEAPONS[name]
        if st.get("melee"):
            p.cd = st["cd"]
            self.add_event("s", p.x, p.y, p.id)
            reach = st.get("range", 1.65)
            best = None
            best_d = reach + 1.0
            for q in self.players.values():
                if not q.alive or q.team == p.team:
                    continue
                dx, dy = q.x - p.x, q.y - p.y
                d = math.hypot(dx, dy)
                if d > reach or d <= 0.01:
                    continue
                if abs(angdiff(math.atan2(dy, dx), p.a)) > 0.72:
                    continue
                if cast(p.x, p.y, dx / d, dy / d, d)[0] < d - 0.08:
                    continue
                if d < best_d:
                    best, best_d = q, d
            if best is not None:
                damage = st["dmg"]
                # El golpe de frente es fuerte; desde muy cerca puede ser letal.
                if best_d < 0.85:
                    damage = int(damage * 1.35)
                best._last_hs = False
                # Evento de impacto de cuchillo: el cliente usa el mismo
                # mecanismo que para las balas (chispas + hitmarker).
                self.add_event("i", best.x, best.y, p.id)
                best.hp -= damage
                if best.hp <= 0:
                    best.hp = 0
                    best.alive = False
                    p.kills += 1
                    best.deaths += 1
                    self.add_event("k", best.x, best.y, p.id)
            return
        p.mags[name] = p.mags.get(name, st["mag"]) - 1
        p.cd = st["cd"]
        sp = st["spread"] + (st["move"] if p.moving else 0.0) + (0.02 if p.bot else 0.0)
        self.add_event("s", p.x, p.y, p.id)
        for _ in range(st["pellets"]):
            ang = p.a + random.uniform(-sp, sp)
            dx, dy = math.cos(ang), math.sin(ang)
            wall = cast(p.x, p.y, dx, dy, 60.0)[0]
            best, bt, best_offset = None, 1e9, 999.0
            for q in self.players.values():
                if not q.alive or q.team == p.team:
                    continue
                vx, vy = q.x - p.x, q.y - p.y
                t = vx * dx + vy * dy
                if t <= 0 or t >= wall or t >= bt:
                    continue
                offset = abs(vx * dy - vy * dx)
                if offset < 0.30:
                    best, bt, best_offset = q, t, offset
            if best:
                # Hitbox simplificado, pero los headshots son poco frecuentes.
                # La cercanía al centro por sí sola ya no garantiza un tiro a la cabeza.
                head_chance = 0.10 if p.bot else 0.75
                if p.bot:
                    head_chance *= (0.55 + 0.45 * p.ai["skill"])
                is_head = (st["pellets"] == 1 and best_offset <= 0.055 and
                           random.random() < head_chance)
                extra = random.randint(-2, 2) if st["pellets"] == 1 and st["dmg"] < 60 else 0
                self.hurt(best, st["dmg"] + extra, p, is_head)
            else:
                # La bala no golpeo a nadie: marca el impacto en la pared.
                # El cliente usa este evento 'w' para generar chispas y un
                # agujero de bala decorativo. Es puramente cosmético.
                ix = p.x + dx * wall
                iy = p.y + dy * wall
                self.add_event("w", ix, iy, p.id)

    def hurt(self, target, dmg, attacker, headshot=False):
        if headshot:
            attacker.headshots += 1
            dmg = int(round(dmg * 4.0))
            self.add_event("h", target.x, target.y, attacker.id)
        target._last_hs = bool(headshot)
        # Evento de impacto: el cliente lo usa para el hitmarker del tirador
        # y para chispas de sangre en la victima. No afecta a la logica.
        self.add_event("i", target.x, target.y, attacker.id if attacker else -1)
        if target.armor > 0:
            target.armor = max(0.0, target.armor - dmg * 0.5)
            dmg *= 0.5
        target.hp -= int(round(dmg))
        if target.hp <= 0 and target.alive:
            self.die(target, attacker)

    # -- tienda
    def buy_allowed(self):
        return self.phase == "freeze" or (self.phase == "live" and ROUND_T - self.timer <= BUY_WINDOW)

    def process_cmds(self):
        for p in self.players.values():
            inp = p.inp
            bq = int(inp.get("bq", 0))
            if bq > p.last_bq:
                p.last_bq = bq
                bi = str(inp.get("bi", ""))
                # 2.2: comando especial "auto" repite el loadout de la ronda
                # anterior. Es equivalente a pulsar varias teclas de tienda.
                if bi == "auto":
                    self.auto_buy_loadout(p)
                else:
                    self.buy(p, bi)
            wq = int(inp.get("wq", 0))
            if wq > p.last_wq:
                p.last_wq = wq
                w = inp.get("w")
                if p.alive and w in (1, 2, 3) and w != p.cur and p.slots.get(w) and p.rel <= 0:
                    p.cur = w
            # 2.4: ciclo de granada con G (gc counter).
            gc = int(inp.get("gc", 0))
            if gc > getattr(p, "_last_gc", 0):
                p._last_gc = gc
                self.cycle_grenade(p)
            # 2.4: lanzamiento de granada (gq counter + gt tipo).
            gq = int(inp.get("gq", 0))
            if gq > getattr(p, "_last_gq", 0):
                p._last_gq = gq
                gtype = str(inp.get("gt", "he"))
                self.throw_grenade(p, gtype)

    def buy(self, p, item):
        if not p.alive or not self.buy_allowed():
            return
        if item == "armor":
            if p.money >= ARMOR_PRICE and p.armor < 100:
                p.money -= ARMOR_PRICE
                p.armor = 100.0
        elif item == "kit":
            if p.team == "C" and not p.kit and p.money >= KIT_PRICE:
                p.money -= KIT_PRICE
                p.kit = True
        elif item in GRENADES:
            # 2.4: compra de granadas. Respeta el limite por tipo.
            spec = GRENADES[item]
            max_count = {"he": MAX_HE, "flash": MAX_FLASH, "smoke": MAX_SMOKE}.get(item, 1)
            if p.grenades.get(item, 0) >= max_count:
                return
            if p.money < spec["price"]:
                return
            p.money -= spec["price"]
            p.grenades[item] = p.grenades.get(item, 0) + 1
            # Selecciona automaticamente la granada recien comprada.
            p.cur_grenade = item
        elif item in WEAPONS:
            st = WEAPONS[item]
            if st["price"] <= 0 or st["team"] not in (None, p.team) or p.slots[st["slot"]] == item:
                return
            if p.money < st["price"]:
                return
            p.money -= st["price"]
            p.slots[st["slot"]] = item
            p.mags[item] = st["mag"]
            p.cur = st["slot"]
            p.rel = 0.0
        # 2.2: registra el loadout actual para auto-compra con P.
        # Solo se guarda tras una compra valida (la verificacion de precio
        # ya se hizo arriba). No altera la economia ni la mecanica.
        self._snapshot_loadout(p)

    def _snapshot_loadout(self, p):
        """Guarda el loadout actual del jugador para auto-compra futura."""
        p.last_loadout = {
            "primary": p.slots.get(1),
            "secondary": p.slots.get(2),
            "armor": p.armor > 0,
            "kit": bool(p.kit),
        }

    def auto_buy_loadout(self, p):
        """Repite la compra de la ronda anterior si el jugador tiene dinero.
        No compra nada si no hay loadout guardado o si el jugador esta muerto.
        Si el dinero no alcanza para todo, prioriza primaria > armor > kit > pistola."""
        if not p.alive or not self.buy_allowed():
            return False
        if not p.last_loadout:
            return False
        lo = p.last_loadout
        # Orden de prioridad: primaria > armor > kit > pistola.
        # Si una compra falla por dinero, sigue intentando con las demas.
        bought_any = False
        if lo["primary"] and lo["primary"] in WEAPONS:
            st = WEAPONS[lo["primary"]]
            if (st["team"] in (None, p.team) and p.slots.get(1) != lo["primary"]
                    and p.money >= st["price"]):
                # Solo compra si no la tiene ya equipada.
                self.buy(p, lo["primary"])
                bought_any = True
        if lo["armor"] and p.armor < 100 and p.money >= ARMOR_PRICE:
            self.buy(p, "armor")
            bought_any = True
        if lo["kit"] and p.team == "C" and not p.kit and p.money >= KIT_PRICE:
            self.buy(p, "kit")
            bought_any = True
        if lo["secondary"] and lo["secondary"] in WEAPONS:
            st = WEAPONS[lo["secondary"]]
            if (st["team"] in (None, p.team) and p.slots.get(2) != lo["secondary"]
                    and p.money >= st["price"]):
                self.buy(p, lo["secondary"])
                bought_any = True
        return bought_any

    def bot_buy(self, p):
        # Economia consciente: si el bot tiene poco dinero y no esta en una
        # ronda de "compra obligada" (ronda 1 o despues de varias perdidas),
        # hace eco parcial: compra pistola/barato y guarda para la siguiente.
        # Esto no mejora la punteria del bot, solo su gestion de dinero, y por
        # tanto no lo hace unfair contra jugadores humanos.
        if p.team == "T":
            # 2.1: anade sawedoff (escopeta barata) y galil ya estaba como rifle economico.
            choices = ["ak47", "galil", "sg552", "mac10", "mp5", "p90", "m3", "sawedoff", "awp", "m249", "ump45"]
        else:
            # 2.1: anade mp9 (subfusil veloz) como alternativa CT al mp5.
            choices = ["m4a1", "famas", "aug", "tmp", "mp5", "mp9", "p90", "xm1014", "awp", "sg550", "ump45"]
        random.shuffle(choices)
        last = p.ai.get("last_weapon")
        affordable = [w for w in choices if p.money >= WEAPONS[w]["price"] and WEAPONS[w]["team"] in (None, p.team)]
        if last in affordable and len(affordable) > 1:
            affordable.remove(last)

        # Eco: si el dinero es muy bajo, guarda para la siguiente ronda en
        # lugar de gastar todo. Conserva al menos ARMOR_PRICE para la proxima.
        eco = p.money < 2000 and p.ai.get("save_until", 0) > 0
        if eco:
            affordable = [w for w in affordable if WEAPONS[w]["price"] <= 1500]
        elif p.money < 1500:
            # Ronda muy pobre: compra solo pistola y deja dinero para armor.
            affordable = []

        bought = False
        if affordable:
            # Prefer rifles/SMG but occasionally choose a cheaper or heavier gun.
            weights = []
            for w in affordable:
                price = WEAPONS[w]["price"]
                if price >= 3000:
                    weights.append(1.0)
                elif price >= 1800:
                    weights.append(1.35)
                else:
                    weights.append(0.95)
            weapon = random.choices(affordable, weights=weights, k=1)[0]
            self.buy(p, weapon)
            p.ai["last_weapon"] = weapon
            bought = True
            if eco:
                p.ai["save_until"] = max(0, p.ai["save_until"] - 1)
        if not bought:
            # 2.1: anade cz75 (auto-pistola) y r8 (revolver pesado) como
            # opciones economicas cuando no hay dinero para primaria.
            pistols = (["glock", "deagle", "elite", "p228", "cz75", "r8"] if p.team == "T"
                       else ["usp", "fiveseven", "p228", "deagle", "cz75", "r8"])
            random.shuffle(pistols)
            affordable_p = [w for w in pistols if p.money >= WEAPONS[w]["price"] and
                             WEAPONS[w]["team"] in (None, p.team)]
            if affordable_p:
                self.buy(p, random.choice(affordable_p))
        if p.money >= ARMOR_PRICE and random.random() < 0.72:
            self.buy(p, "armor")
        if p.team == "C" and p.money >= KIT_PRICE and random.random() < 0.62:
            self.buy(p, "kit")

        # Pistola secundaria: variedad, pero sin gastar siempre en la misma.
        pistols = (["glock", "deagle", "elite", "p228", "cz75", "r8"] if p.team == "T"
                   else ["usp", "fiveseven", "p228", "deagle", "cz75", "r8"])
        random.shuffle(pistols)
        for weapon in pistols:
            if weapon in p.slots.values():
                continue
            if p.money >= WEAPONS[weapon]["price"] and random.random() < 0.30:
                self.buy(p, weapon)
                break

        # Si tras comprar sigue con muy poco dinero, marca eco para la ronda
        # siguiente: ahorrara y reaparecera con armamento aceptable.
        if p.money < 1000:
            p.ai["save_until"] = max(p.ai.get("save_until", 0), 1)

    # --- 2.4: granadas -----------------------------------------------------
    def cycle_grenade(self, p):
        """Cambia el tipo de granada activa entre los que el jugador tiene.
        Si no tiene ninguna, no hace nada. Esto permite pulsar G para
        ciclar entre HE/flash/smoke."""
        if not p.alive:
            return
        # Tipos disponibles: solo los que tienen al menos 1.
        available = [g for g in GRENADE_ORDER if p.grenades.get(g, 0) > 0]
        if not available:
            return
        # Si la granada actual ya no esta disponible, pasa a la primera.
        if p.cur_grenade not in available:
            p.cur_grenade = available[0]
            return
        # Avanza al siguiente en la lista.
        idx = available.index(p.cur_grenade)
        p.cur_grenade = available[(idx + 1) % len(available)]

    def throw_grenade(self, p, gtype):
        """Lanza una granada del tipo indicado si el jugador la tiene y el
        cooldown se ha cumplido. La granada aparece en el mundo con una
        velocidad inicial derivada del yaw del jugador (mas un poco arriba
        para que haga parabola). El cliente luego la vera en vuelo."""
        if not p.alive or gtype not in GRENADES:
            return
        if p.grenade_cd > 0:
            return
        if p.grenades.get(gtype, 0) <= 0:
            return
        if p.rel > 0 or p.prog > 0:
            # No se puede lanzar mientras se recarga o se planta/desactiva.
            return
        p.grenades[gtype] -= 1
        p.grenade_cd = 0.6
        # Velocidad inicial: hacia adelante (yaw) + un componente vertical.
        speed = GRENADE_THROW_SPEED
        vx = math.cos(p.a) * speed
        vy = math.sin(p.a) * speed
        vz = 4.5  # impulso vertical para que tenga arco
        # Posicion inicial: 0.4 unidades delante del jugador, a la altura del pecho.
        x0 = p.x + math.cos(p.a) * 0.4
        y0 = p.y + math.sin(p.a) * 0.4
        z0 = 1.0  # pecho
        gid = self.next_grenade_id
        self.next_grenade_id += 1
        g = {"id": gid, "type": gtype, "x": x0, "y": y0, "z": z0,
             "vx": vx, "vy": vy, "vz": vz,
             "fuse": GRENADES[gtype]["fuse"], "owner": p.id}
        self.grenades.append(g)
        # Evento de lanzamiento para que el cliente haga sonido + trail.
        self.add_event("gt", x0, y0, p.id)
        # Si la granada actual se agoto, cicla al siguiente disponible.
        if p.grenades.get(gtype, 0) <= 0:
            self.cycle_grenade(p)

    def update_grenades(self, dt):
        """Avanza la fisica de las granadas en vuelo y detona las que llegan
        a su fuse o impactan el suelo tras un par de rebotes."""
        # Decrementa cooldowns de jugadores.
        for p in self.players.values():
            if p.grenade_cd > 0:
                p.grenade_cd = max(0.0, p.grenade_cd - dt)
        # Fisica de granadas.
        still_alive = []
        for g in self.grenades:
            g["fuse"] -= dt
            # Movimiento parabolico.
            g["x"] += g["vx"] * dt
            g["y"] += g["vy"] * dt
            g["z"] += g["vz"] * dt
            g["vz"] -= GRENADE_GRAVITY * dt
            # Colision con paredes (DDA simple en la direccion horizontal).
            if blocked(g["x"], g["y"]):
                # Rebota: invierte componente horizontal que mas contribuye.
                # Aproximacion: prueba los 4 cardinales y reduce el que choca.
                if blocked(g["x"] - g["vx"] * dt, g["y"]):
                    g["vx"] = -g["vx"] * GRENADE_BOUNCE
                if blocked(g["x"], g["y"] - g["vy"] * dt):
                    g["vy"] = -g["vy"] * GRENADE_BOUNCE
                g["x"] += g["vx"] * dt
                g["y"] += g["vy"] * dt
            # Suelo.
            if g["z"] <= 0.05:
                g["z"] = 0.05
                if g["vz"] < 0:
                    g["vz"] = -g["vz"] * GRENADE_BOUNCE
                    # Friccion horizontal al tocar suelo.
                    g["vx"] *= GRENADE_FRICTION
                    g["vy"] *= GRENADE_FRICTION
                # Si casi no se mueve, para en el suelo.
                if abs(g["vz"]) < 0.5:
                    g["vz"] = 0.0
            # Detona al acabar el fuse.
            if g["fuse"] <= 0:
                self.detonate_grenade(g)
            else:
                still_alive.append(g)
        self.grenades = still_alive
        # Limpieza de zonas de humo expiradas.
        self.smoke_zones = [s for s in self.smoke_zones if self.clock - s["born_at"] < s["life"]]

    def detonate_grenade(self, g):
        """Aplica el efecto de la granada segun su tipo y registra eventos."""
        gtype = g["type"]
        x, y = g["x"], g["y"]
        spec = GRENADES[gtype]
        if gtype == "he":
            # Dano en radio, decreciente con la distancia. El dueno recibe
            # la mitad (auto-dano) para que no se abuse con cerrar ojos.
            radius = spec["radius"]
            for q in self.players.values():
                if not q.alive:
                    continue
                d = math.hypot(q.x - x, q.y - y)
                if d > radius:
                    continue
                # Dano lineal con la distancia: 100% a 0, 0% a radius.
                dmg = spec["dmg"] * (1.0 - d / radius)
                if q.id == g["owner"]:
                    dmg *= 0.5  # auto-dano reducido
                if dmg > 0:
                    # Usa hurt para que cuente como kill del dueno de la granada.
                    attacker = self.players.get(g["owner"])
                    self.hurt(q, int(dmg), attacker, headshot=False)
            # Evento visual: explosion.
            self.add_event("ge", x, y, g["owner"])
        elif gtype == "flash":
            # Cegar a todos los jugadores en radio que esten mirando hacia la
            # explosion. El dueno puede cegarse a si mismo si la mira.
            radius = spec["radius"]
            for q in self.players.values():
                if not q.alive:
                    continue
                d = math.hypot(q.x - x, q.y - y)
                if d > radius:
                    continue
                # Angulo entre la direccion del jugador y la direccion hacia
                # la explosion. Si es < ~60 grados, esta mirando.
                dx = x - q.x
                dy = y - q.y
                ang = math.atan2(dy, dx)
                diff = abs(angdiff(ang, q.a))
                # Detras del jugador: solo cegado parcial.
                flash_strength = 1.0 if diff < 1.05 else 0.4
                # A mas cerca, mas ceguera.
                flash_strength *= (1.0 - d / radius)
                if flash_strength > 0.05:
                    duration = spec["flash_time"] * flash_strength
                    q.flash_until = max(q.flash_until, self.clock + duration)
            self.add_event("gf", x, y, g["owner"])
        elif gtype == "smoke":
            # Crear zona de humo persistente. La zona tapa la vision de
            # jugadores que estan dentro o detras de ella.
            self.smoke_zones.append({
                "x": x, "y": y, "born_at": self.clock,
                "life": spec["smoke_time"], "radius": spec["radius"],
            })
            self.add_event("gs", x, y, g["owner"])

    # -- IA de bots
    def visible_enemies(self, p):
        """Lista de enemigos visibles para p, ordenada por prioridad tactica.

        Prioridad (sin omnisciencia, solo lo que p ve):
          1. Portador de bomba (T) o desactivador (CT) — son el objetivo clave
          2. Enemigo mas cercano
        Esto da a los bots una nocion de prioridad sin mejorar su punteria.
        """
        out = []
        for q in self.players.values():
            if not q.alive or q.team == p.team:
                continue
            dx, dy = q.x - p.x, q.y - p.y
            d = math.hypot(dx, dy)
            if d > 17 or d < 1e-6:
                continue
            if abs(angdiff(math.atan2(dy, dx), p.a)) > 1.02 and d > 2.5:
                continue
            if cast(p.x, p.y, dx / d, dy / d, d + 1)[0] >= d - 0.3:
                # prioridad: bomba > resto
                prio = 0
                if p.team == "C" and q.has_bomb:
                    prio = -1
                # CT que esta desactivando (cerca de la bomba plantada y "use")
                b = self.bomb
                if (p.team == "T" and b["state"] == "planted"
                        and math.hypot(q.x - b["x"], q.y - b["y"]) < 1.3
                        and q.prog > 0.0):
                    prio = -1
                out.append((prio, d, q))
        if not out:
            return None
        out.sort(key=lambda t: (t[0], t[1]))
        return out[0][2]

    def visible_enemy(self, p):
        # Mantenida por compatibilidad con codigo externo; delega en la nueva
        # version con prioridad tactica.
        return self.visible_enemies(p)

    def ai_think(self, p):
        st = p.ai
        # Los bots no tienen vision omnisciente: pueden no detectar a un enemigo
        # aunque este en linea de vision y pierden el objetivo tras un rato.
        e = self.visible_enemies(p)
        skill = st["skill"]
        if e is not None and random.random() < (0.44 + 0.38 * skill):
            if st["target"] != e.id:
                st["react"] = random.uniform(0.60, 1.25) * (1.30 - skill)
            st["target"] = e.id
            st["lost"] = 0.0
            st["last_seen"] = self.clock
            # Memoria de la ultima posicion conocida del enemigo. Los bots no
            # tienen wallhack: solo recuerdan donde vieron al objetivo y, al
            # perderlo, pre-apuntan a esa esquina durante un rato corto.
            st["last_pos"] = (e.x, e.y)
            st["last_pos_t"] = self.clock
        elif st["target"] is not None:
            st["lost"] += st["think"]
            if st["lost"] > random.uniform(0.45, 1.15):
                st["target"] = None

        b = self.bomb
        # Decision de objetivo de movimiento segun el rol y el estado de la bomba.
        if b["state"] == "planted":
            if p.team == "C":
                # CT: todos corren a desactivar. Es lo justificable tacticamente.
                goal = (int(b["x"]), int(b["y"]))
            else:
                # T: defienden la bomba. Cada T elige una celda cercana al
                # bombsite para cubrir angulos, no se amontonan encima.
                site = site_at(b["x"], b["y"]) or st["site"]
                cells = SITE_CELLS.get(site, []) or SITE_CELLS[st["site"]]
                # Celdas a 2-4 de distancia de la bomba (no pegadas)
                cover = [c for c in cells if 2.0 <= math.hypot(c[0] + 0.5 - b["x"],
                                                                c[1] + 0.5 - b["y"]) <= 4.5]
                goal = random.choice(cover) if cover else (int(b["x"]), int(b["y"]))
                st["spot"] = goal
        elif b["state"] == "dropped":
            if p.team == "T":
                # El T mas cercano recoge; otros mantienen su spot.
                # El bot no sabe quien es el mas cercano sin omnisciencia, asi
                # que usa una heuristica: si esta a menos de 8 casillas, va.
                if math.hypot(p.x - b["x"], p.y - b["y"]) < 8.0:
                    goal = (int(b["x"]), int(b["y"]))
                else:
                    goal = st["spot"]
            else:
                goal = st["spot"]
        else:
            goal = st["spot"]
            if p.has_bomb:
                goal = random.choice(SITE_CELLS[st["site"]]) if not st.get("bombgoal") else st["bombgoal"]
                st["bombgoal"] = goal
        st["path"] = bfs((int(p.x), int(p.y)), goal)

    def ai(self, p, dt):
        st = p.ai
        inp = p.inp
        st["think"] -= dt
        if st["think"] <= 0:
            st["think"] = random.uniform(0.14, 0.38)
            self.ai_think(p)
        inp.update(use=False, fire=False, rel=False, f=0, s=0)

        # Pequeños errores de control hacen que los bots parezcan jugadores humanos.
        st["pause"] = max(0.0, st["pause"] - dt)
        st["peek_t"] = max(0.0, st["peek_t"] - dt)
        st["retreat"] = max(0.0, st["retreat"] - dt)

        # --- Recarga tactica: solo cuando no hay enemigo visible o el enemigo
        # esta lejos. Recargar en medio de un duelo es suicida y los bots ahora
        # lo evitan. Esto es una mejora tactica, no de punteria.
        name = p.wname()
        st_w = WEAPONS[name]
        mag_now = p.mags.get(name, 0)
        target_visible = st["target"] is not None and self.players.get(st["target"]) and \
            self.players[st["target"]].alive
        if (not target_visible) and p.rel <= 0 and mag_now < st_w["mag"] * 0.5:
            inp["rel"] = True

        # --- Cambio a pistola: si la primaria esta vacia y el enemigo esta
        # cerca, cambia a la secundaria en lugar de quedarse esperando recarga.
        if p.slots[1] and p.slots[2] and p.cur == 1 and mag_now <= 0 and not p.rel:
            tgt = self.players.get(st["target"]) if st["target"] is not None else None
            close = tgt is not None and math.hypot(tgt.x - p.x, tgt.y - p.y) < 7.0
            if close or st.get("want_pistol"):
                if not st.get("want_pistol"):
                    st["want_pistol"] = True
                inp["wq"] = inp.get("wq", 0) + 1
                inp["w"] = 2
                # El swap cuenta como accion; el bot no dispara este frame.
                return
            else:
                # Si el enemigo esta lejos, recarga la primaria.
                if p.rel <= 0:
                    inp["rel"] = True
        elif st.get("want_pistol") and p.cur == 2:
            # Vuelve a primaria cuando se recarga o el enemigo se aleja.
            if p.slots[1] and p.mags.get(p.slots[1], 0) > 0 and not target_visible:
                st["want_pistol"] = False

        # --- Retirada cuando HP baja: si hp < 30 y hay enemigo visible, el
        # bot retrocede en direccion contraria. Esto NO mejora su combate,
        # solo le hace intentar sobrevivir. Mantiene errores: a veces se
        # queda quieto o se choca con paredes (no es perfecto).
        if p.hp < 30 and target_visible and st["retreat"] <= 0:
            st["retreat"] = random.uniform(0.6, 1.4)

        tgt = self.players.get(st["target"]) if st["target"] is not None else None
        if tgt and tgt.alive:
            dx, dy = tgt.x - p.x, tgt.y - p.y
            desired = math.atan2(dy, dx)
            d = math.hypot(dx, dy)
            # El punto de mira tiene ruido y un poco de deriva mientras dispara.
            err = st["aim_error"] * (1.55 if d > 10 else 1.0)
            desired += random.gauss(0.0, err)
            diff = angdiff(desired, p.a)
            turn = TURN_BOT * (0.22 + 0.42 * st["skill"])
            # Algunos bots tardan mas en corregir el primer giro.
            if st["react"] > 0:
                st["react"] -= dt
                turn *= 0.35
            p.a += clamp(diff, -turn * dt, turn * dt)

            st["strafe_t"] -= dt
            if st["strafe_t"] <= 0:
                st["strafe_t"] = random.uniform(0.35, 1.15)
                # En retirada, el strafe se inclina por alejarse del enemigo
                # en lugar de moverse lateralmente al azar.
                if st["retreat"] > 0:
                    st["sd"] = random.choices((-1, 0, 1), weights=(0.20, 0.40, 0.40))[0]
                else:
                    st["sd"] = random.choices((-1, 0, 1), weights=(0.28, 0.44, 0.28))[0]
            if st["pause"] <= 0:
                inp["s"] = st["sd"]
                if st["retreat"] > 0:
                    # Intenta caminar hacia atras (alejandose del enemigo).
                    inp["f"] = -1
                elif random.random() < 0.18:
                    inp["f"] = -1

            # No hacen tracking perfecto: disparan en rfagas y fallan ocasionalmente.
            aligned = abs(angdiff(math.atan2(tgt.y - p.y, tgt.x - p.x), p.a)) < (0.12 + 0.14 * (1.0 - st["skill"]))
            if aligned and st["react"] <= 0 and st["pause"] <= 0 and st["retreat"] <= 0:
                if st["burst_left"] <= 0:
                    st["burst_left"] = random.randint(1, 3 if st["skill"] > 0.55 else 2)
                if st["burst_left"] > 0 and random.random() < (0.38 + 0.30 * st["skill"]):
                    inp["fire"] = True
                    st["burst_left"] -= 1
            elif random.random() < 0.008:
                inp["fire"] = True
            return

        # Sin objetivo visible: pre-apunta a la ultima posicion conocida
        # del enemigo durante unos segundos. Es un comportamiento humano:
        # mantienes el crosshair donde viste al rival por ultima vez.
        if (st["last_pos"] is not None
                and self.clock - st["last_pos_t"] < random.uniform(2.5, 4.5)):
            lx, ly = st["last_pos"]
            desired = math.atan2(ly - p.y, lx - p.x)
            diff = angdiff(desired, p.a)
            turn = TURN_BOT * (0.30 + 0.40 * st["skill"])
            p.a += clamp(diff, -turn * dt, turn * dt)
            # Avanza con cautela: pequeñas pausas antes de asomarse.
            if st["peek_t"] <= 0 and random.random() < 0.06:
                st["peek_t"] = random.uniform(0.20, 0.55)

        b = self.bomb
        if p.team == "T" and p.has_bomb and b["state"] == "carried" and site_at(p.x, p.y):
            inp["use"] = True
            return
        if p.team == "C" and b["state"] == "planted" and math.hypot(p.x - b["x"], p.y - b["y"]) < 1.0:
            inp["use"] = True
            return
        path = st["path"]
        while path and math.hypot(path[0][0] + 0.5 - p.x, path[0][1] + 0.5 - p.y) < 0.35:
            path.pop(0)
        if path and st["pause"] <= 0 and st["peek_t"] <= 0:
            tx, ty = path[0][0] + 0.5, path[0][1] + 0.5
            diff = angdiff(math.atan2(ty - p.y, tx - p.x), p.a)
            p.a += clamp(diff, -TURN_BOT * (0.55 + 0.45 * st["skill"]) * dt, TURN_BOT * dt)
            if abs(diff) < random.uniform(0.75, 1.15):
                inp["f"] = 1
            if random.random() < 0.04:
                st["pause"] = random.uniform(0.15, 0.5)

    # -- red
    def snapshot(self):
        b = self.bomb
        # 2.4: añade al snapshot del jugador: granadas en inventario, granada
        # actual, skin visual y timestamp hasta el que esta cegado por flash.
        # Mantenemos compatibilidad con clientes antiguos añadiendo campos al
        # final del array (los clientes viejos ignoran los indices nuevos).
        pl = [[p.id, round(p.x, 2), round(p.y, 2), round(p.a, 2), max(0, p.hp), p.team, p.ammo,
               1 if p.rel > 0 else 0, p.kills, p.deaths, p.headshots, 1 if p.bot else 0, p.name,
               1 if p.has_bomb else 0, round(p.prog, 1), 1 if p.alive else 0,
               WEAPON_ORDER.index(p.wname()), int(p.armor), p.money, 1 if p.kit else 0,
               # --- 2.4: campos nuevos
               p.grenades.get("he", 0), p.grenades.get("flash", 0), p.grenades.get("smoke", 0),
               p.cur_grenade, p.skin,
               round(max(0.0, p.flash_until - self.clock), 1)]
              for p in self.players.values()]
        # Kill feed estructurado: cada entrada es
        # [killer_id, killer_name, killer_team, victim_id, victim_name, victim_team, weapon, headshot].
        # Solo las entradas no expiradas; el HUD del 2.0 dibuja iconos por arma.
        kf = []
        for entry in self.feed:
            if len(entry) < 8:
                continue
            exp, txt, kid, vid, wpn, hs, kteam, vteam = entry
            if exp <= self.clock:
                continue
            kn = txt.split(" > ")[0] if " > " in txt else "?"
            vn = txt.split(" > ", 1)[1] if " > " in txt else "?"
            kf.append([kid, kn[:12], kteam, vid, vn[:12], vteam, wpn, 1 if hs else 0])
        # 2.4: lista de granadas en vuelo para que el cliente las dibuje.
        # Cada entrada es [type, x, y, z, owner_id] con tipos cortos.
        gs = [[g["type"], round(g["x"], 2), round(g["y"], 2), round(g["z"], 2), g["owner"]]
              for g in self.grenades]
        # 2.4: zonas de humo activas (para que el cliente dibuje niebla).
        sm = [[round(s["x"], 2), round(s["y"], 2), s["radius"],
               round(max(0.0, s["life"] - (self.clock - s["born_at"])), 1)]
              for s in self.smoke_zones]
        return {"ph": self.phase, "tm": round(max(0.0, self.timer), 1), "rd": self.round,
                "sc": [self.score["T"], self.score["C"]], "msg": self.msg,
                "bm": [b["state"], round(b["x"], 2), round(b["y"], 2), round(max(0.0, b["t"]), 1)],
                "pl": pl, "ev": self.ev[-6:],
                "fd": [t for (exp, t, *_rest) in self.feed if exp > self.clock],
                "kf": kf[-8:],
                "gs": gs, "sm": sm,
                "map": self.map_name,
                "maptitle": MAPS[self.map_name].title}


(I_ID, I_X, I_Y, I_A, I_HP, I_TEAM, I_AMMO, I_REL, I_K, I_D, I_HS, I_BOT, I_NAME, I_BOMB, I_PROG, I_ALIVE,
 I_WPN, I_ARMOR, I_MONEY, I_KIT,
 # --- 2.4: campos nuevos
 I_HE, I_FLASH, I_SMOKE, I_CUR_GREN, I_SKIN, I_FLASH_T) = range(26)


def pack(obj):
    return zlib.compress(json.dumps(obj, separators=(",", ":")).encode())


def unpack(data):
    return json.loads(zlib.decompress(data).decode())


def get_lan_interfaces():
    """Devuelve (IP, broadcast) de las interfaces IPv4 activas.

    2.5: cross-platform. En Linux usa fcntl+ioctl (rapido y preciso).
    En Windows usa socket.getaddrinfo con el hostname (fallback universal).
    En ambos casos filtra 127.x y 169.254.x (link-local).
    """
    found = []
    # --- Metodo 1: Linux con fcntl + ioctl ---
    if fcntl is not None:
        try:
            probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            for _, ifname in socket.if_nameindex():
                if ifname == "lo":
                    continue
                request = struct.pack("256s", ifname[:15].encode("utf-8"))
                try:
                    raw_ip = fcntl.ioctl(probe.fileno(), 0x8915, request)  # SIOCGIFADDR
                    raw_mask = fcntl.ioctl(probe.fileno(), 0x891B, request)  # SIOCGIFNETMASK
                    ip = socket.inet_ntoa(raw_ip[20:24])
                    mask = socket.inet_ntoa(raw_mask[20:24])
                    ip_n = struct.unpack("!I", socket.inet_aton(ip))[0]
                    mask_n = struct.unpack("!I", socket.inet_aton(mask))[0]
                    broadcast = socket.inet_ntoa(struct.pack("!I", (ip_n & mask_n) | (~mask_n & 0xffffffff)))
                    if not ip.startswith("127.") and not ip.startswith("169.254."):
                        found.append((ip, broadcast))
                except OSError:
                    continue
            probe.close()
        except (OSError, AttributeError):
            pass
    # --- Metodo 2: Windows / cross-platform con getaddrinfo ---
    # En Windows no hay fcntl ni if_nameindex. Usamos el hostname para
    # resolver la IP local. Menos preciso (solo devuelve 1 IP) pero funciona.
    if not found:
        try:
            hostname = socket.gethostname()
            # getaddrinfo devuelve todas las IPs del hostname.
            addrs = socket.getaddrinfo(hostname, None, socket.AF_INET,
                                       socket.SOCK_DGRAM)
            for addr in addrs:
                ip = addr[4][0]
                if not ip.startswith("127.") and not ip.startswith("169.254."):
                    found.append((ip, "255.255.255.255"))
        except (socket.gaierror, OSError):
            pass
    # --- Metodo 3: ultimo recurso - UDP connect trick ---
    # Abre un socket UDP y lo "conecta" a una IP cualquiera. El SO asigna
    # la IP de la interfaz de salida. No envia nada, solo descubre la IP.
    if not found:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            if ip and not ip.startswith("127.") and not ip.startswith("169.254."):
                found.append((ip, "255.255.255.255"))
        except OSError:
            pass
    # Quitar duplicados conservando el orden.
    return list(dict.fromkeys(found))


def get_lan_ips():
    return [ip for ip, _ in get_lan_interfaces()]


class Server:
    def __init__(self, world, port=PORT, name="Defusa"):
        self.world = world
        self.name = name
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("", port))
        self.sock.setblocking(False)
        self.clients = {}
        self.snap_t = 0.0

    def info(self):
        # 2.2: incluye el mapa actual en el paquete de descubrimiento LAN
        # para que el cliente lo muestre en la lista de servidores.
        return json.dumps({"name": self.name, "players": len(self.clients) + 1 if False else
                           self.world.count("T", True) + self.world.count("C", True),
                           "max": MAX_HUMANS, "ver": VERSION,
                           "map": self.world.map_name,
                           "maptitle": MAPS[self.world.map_name].title})

    def poll(self, now):
        while True:
            try:
                data, addr = self.sock.recvfrom(4096)
            except BlockingIOError:
                break
            except ConnectionError:
                continue
            except OSError:
                break
            if data == b"DEFUSA?":
                try:
                    self.sock.sendto(b"DEFUSA!" + self.info().encode(), addr)
                except OSError:
                    pass
                continue
            try:
                m = unpack(data)
            except Exception:
                continue
            k = m.get("k")
            if k == "join":
                if addr not in self.clients:
                    if len(self.clients) >= MAX_HUMANS:
                        self.send(addr, {"k": "full"})
                        continue
                    team = m.get("team", "T")
                    team = team if team in ("T", "C") else "T"
                    self.clients[addr] = self.world.add_player(str(m.get("name", "Jugador")), team)
                self.send(addr, {"k": "welcome", "id": self.clients[addr]})
            elif k == "in" and addr in self.clients:
                p = self.world.players.get(self.clients[addr])
                if p:
                    i = m.get("i", {})
                    # 2.4: acepta campos de granada y skin en el input.
                    # Si el cliente no los envia (version vieja), el valor
                    # por defecto es 0 / "classic" y no se hace nada.
                    skin = str(i.get("sk", "classic"))[:12]
                    if skin != p.skin and skin in ("classic", "arctic", "jungle", "desert", "urban"):
                        p.skin = skin
                    p.inp = {"f": clamp(float(i.get("f", 0)), -1, 1), "s": clamp(float(i.get("s", 0)), -1, 1),
                             "a": float(i.get("a", 0.0)), "fire": bool(i.get("fire")),
                             "use": bool(i.get("use")), "rel": bool(i.get("rel")),
                             "wq": int(i.get("wq", 0)), "w": int(i.get("w", 2)),
                             "bq": int(i.get("bq", 0)), "bi": str(i.get("bi", ""))[:10],
                             "gq": int(i.get("gq", 0)), "gt": str(i.get("gt", "he"))[:8],
                             "gc": int(i.get("gc", 0))}
                    p.seen = now
            elif k == "bye" and addr in self.clients:
                self.world.remove_player(self.clients.pop(addr))
        for addr, pid in list(self.clients.items()):
            p = self.world.players.get(pid)
            if p is None or now - p.seen > 6.0:
                self.world.remove_player(pid)
                del self.clients[addr]

    def send(self, addr, obj):
        try:
            self.sock.sendto(pack(obj), addr)
        except OSError:
            pass

    def broadcast(self, snap, now):
        if now - self.snap_t < 1.0 / SNAP_HZ:
            return
        self.snap_t = now
        data = pack(dict(snap, k="st"))
        for addr in self.clients:
            try:
                self.sock.sendto(data, addr)
            except OSError:
                pass

    def close(self):
        self.sock.close()


class LocalSession:
    """Partida local: solo o anfitrion LAN. El jugador humano es el id local."""

    def __init__(self, name, team, bots, host_lan, port=PORT, start_map=None):
        self.world = World(team_size=bots, start_map=start_map)
        self.my_id = self.world.add_player(name, team)
        self.world.new_round()
        self.server = Server(self.world, port, name + "'s game") if host_lan else None
        self.acc = 0.0
        self.last_snap = None
        self.last_map = None  # para que el cliente reconstruya la escena al cambiar

    def set_paused(self, value):
        self.world.paused = bool(value)

    def send_input(self, inp):
        p = self.world.players.get(self.my_id)
        if p:
            p.inp = dict(inp)

    def update(self, dt):
        now = time.time()
        if self.server:
            self.server.poll(now)
        self.acc = min(self.acc + dt, 0.25)
        while self.acc >= TICK:
            self.world.update(TICK)
            self.acc -= TICK
        self.last_snap = self.world.snapshot()
        if self.server:
            self.server.broadcast(self.last_snap, now)

    def snapshot(self):
        return self.last_snap

    def lost(self):
        return False

    def close(self):
        if self.server:
            self.server.close()


class NetSession:
    def __init__(self, host, port, name, team):
        self.addr = (host, port)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setblocking(False)
        self.my_id = None
        self.snap = None
        self.last_rx = time.time()
        self.last_join = 0.0
        self.name, self.team = name, team
        self.full = False

    def _send(self, obj):
        try:
            self.sock.sendto(pack(obj), self.addr)
        except OSError:
            pass

    def send_input(self, inp):
        if self.my_id is not None:
            # 2.4: envia gq/gt/gc (granadas) y sk (skin) al servidor.
            self._send({"k": "in", "i": {"f": inp["f"], "s": inp["s"], "a": round(inp["a"], 3),
                                         "fire": inp["fire"], "use": inp["use"], "rel": inp["rel"],
                                         "wq": inp.get("wq", 0), "w": inp.get("w", 2),
                                         "bq": inp.get("bq", 0), "bi": inp.get("bi", ""),
                                         "gq": inp.get("gq", 0), "gt": inp.get("gt", "he"),
                                         "gc": inp.get("gc", 0), "sk": inp.get("sk", "classic")}})

    def update(self, dt):
        now = time.time()
        if self.my_id is None and now - self.last_join > 0.5:
            self.last_join = now
            self._send({"k": "join", "name": self.name, "team": self.team})
        while True:
            try:
                data, _ = self.sock.recvfrom(8192)
            except (BlockingIOError, InterruptedError):
                break
            except ConnectionError:
                continue
            except OSError:
                break
            try:
                m = unpack(data)
            except Exception:
                continue
            self.last_rx = now
            if m.get("k") == "welcome":
                self.my_id = m["id"]
            elif m.get("k") == "full":
                self.full = True
            elif m.get("k") == "st":
                self.snap = m

    def snapshot(self):
        return self.snap if self.my_id is not None else None

    def lost(self):
        return self.full or time.time() - self.last_rx > 5.0

    def close(self):
        self._send({"k": "bye"})
        self.sock.close()


def _start_dedicated_from_menu(cfg, args):
    """Arranca un servidor dedicado desde el menu del juego.

    El servidor corre en un hilo daemon para que se detenga cuando el
    proceso principal termine. La funcion devuelve un mensaje con las
    IPs donde los amigos pueden conectarse. El usuario puede pulsar
    una tecla para volver al menu (el servidor sigue corriendo en
    segundo plano hasta que cierre el juego).

    2.4.2: el estado del servidor se guarda en _DEDICATED_SERVER para que
    el menu pueda mostrar un indicador persistente y permitir cerrarlo
    con un boton.
    """
    global _DEDICATED_SERVER
    import threading
    # Si ya hay un servidor corriendo, no arrancamos otro.
    if _DEDICATED_SERVER is not None and _DEDICATED_SERVER.get("running", False):
        srv = _DEDICATED_SERVER["server"]
        ips = _DEDICATED_SERVER.get("ips", [])
        ip_str = ", ".join("%s:%d" % (ip, PORT) for ip in ips) if ips else "?"
        return ("El servidor dedicado YA esta corriendo.\n\n"
                "IPs: %s\n\n"
                "Pulsa una tecla para volver al menu." % ip_str)
    # Crea el World y el Server sin jugador local.
    world = World(team_size=cfg.get("bots", 4), start_map=cfg.get("map", MAP_ORDER[0]))
    srv = Server(world, PORT, cfg.get("name", "Defusa") + " (dedicado)")
    ips = get_lan_ips()
    # El hilo del servidor corre el bucle principal. Usa una bandera
    # 'running' para que _stop_dedicated_server pueda detenerlo limpiamente.
    server_state = {"running": True}
    def _server_loop():
        last = time.time()
        try:
            while server_state["running"]:
                now = time.time()
                srv.poll(now)
                while now - last >= TICK:
                    world.update(TICK)
                    last += TICK
                if now - last > 0.5:
                    last = now
                srv.broadcast(world.snapshot(), now)
                time.sleep(0.004)
        except Exception:
            pass
        finally:
            try:
                srv.close()
            except Exception:
                pass
    t = threading.Thread(target=_server_loop, daemon=True)
    t.start()
    # Guarda el estado global para que el menu pueda consultarlo y cerrarlo.
    _DEDICATED_SERVER = {
        "server": srv,
        "thread": t,
        "state": server_state,
        "running": True,
        "ips": ips,
        "port": PORT,
        "name": cfg.get("name", "Defusa") + " (dedicado)",
        "map": cfg.get("map", MAP_ORDER[0]),
        "bots": cfg.get("bots", 4),
    }
    # Construye el mensaje con las IPs.
    if ips:
        ip_lines = "\n".join("   %s:%d" % (ip, PORT) for ip in ips)
        msg = ("SERVIDOR DEDICADO INICIADO\n\n"
               "Mapa: %s    Bots: %d por equipo\n"
               "Tu servidor esta corriendo en segundo plano.\n\n"
               "Comparte estas IPs con tus amigos para que se conecten:\n%s\n\n"
               "Los amigos deben:\n"
               "  1. Instalar defusa-fps\n"
               "  2. Ejecutar: defusa-fps\n"
               "  3. Menu > Unirse a partida LAN > I > escribir la IP\n\n"
               "Pulsa una tecla para volver al menu.\n"
               "Para detener el servidor: menu > Cerrar servidor dedicado."
               % (MAPS[cfg.get("map", MAP_ORDER[0])].title, cfg.get("bots", 4), ip_lines))
    else:
        msg = ("SERVIDOR DEDICADO INICIADO\n\n"
               "Mapa: %s    Bots: %d por equipo\n\n"
               "No se detectaron IPs LAN.\n"
               "Tu servidor esta corriendo en segundo plano.\n\n"
               "Para que tus amigos se conecten necesitas saber tu IP local.\n"
               "En otra terminal ejecuta: ip addr | grep inet\n\n"
               "Pulsa una tecla para volver al menu.\n"
               "Para detener el servidor: menu > Cerrar servidor dedicado."
               % (MAPS[cfg.get("map", MAP_ORDER[0])].title, cfg.get("bots", 4)))
    return msg


def _stop_dedicated_server():
    """Detiene el servidor dedicado que fue arrancado desde el menu.

    Pone la bandera 'running' a False para que el hilo del bucle salga
    limpiamente, y cierra el socket UDP. Devuelve un mensaje de
    confirmacion para mostrar al usuario.
    """
    global _DEDICATED_SERVER
    if _DEDICATED_SERVER is None or not _DEDICATED_SERVER.get("running", False):
        return "No hay ningun servidor dedicado corriendo."
    # Senala al hilo que debe detenerse.
    _DEDICATED_SERVER["state"]["running"] = False
    _DEDICATED_SERVER["running"] = False
    # Cierra el socket inmediatamente para liberar el puerto.
    try:
        _DEDICATED_SERVER["server"].close()
    except Exception:
        pass
    # Espera brevemente a que el hilo termine (max 1s).
    t = _DEDICATED_SERVER.get("thread")
    if t and t.is_alive():
        t.join(timeout=1.0)
    name = _DEDICATED_SERVER.get("name", "servidor")
    _DEDICATED_SERVER = None
    return "Servidor dedicado '%s' detenido.\nEl puerto UDP %d esta libre." % (name, PORT)


def _dedicated_server_running():
    """Devuelve True si hay un servidor dedicado corriendo desde el menu."""
    return _DEDICATED_SERVER is not None and _DEDICATED_SERVER.get("running", False)


def _dedicated_server_info():
    """Devuelve info del servidor dedicado para mostrar en el indicador,
    o None si no hay servidor corriendo."""
    if _DEDICATED_SERVER is None or not _DEDICATED_SERVER.get("running", False):
        return None
    return {
        "ips": _DEDICATED_SERVER.get("ips", []),
        "port": _DEDICATED_SERVER.get("port", PORT),
        "name": _DEDICATED_SERVER.get("name", "Defusa"),
        "map": _DEDICATED_SERVER.get("map", "?"),
        "bots": _DEDICATED_SERVER.get("bots", 0),
    }


def run_dedicated(args):
    """Arranca un servidor Defusa FPS sin interfaz grafica.

    2.4: esta funcion ahora:
    - Muestra todas las IPs detectadas (no solo localhost) para que el
      usuario sepa que IP compartir con sus amigos.
    - Soporta --public-port para cuando hay NAT/port-forwarding (la IP
      externa puede ser distinta de la local).
    - Genera un archivo .service de systemd con --gen-systemd para que
      el servidor arranque automaticamente en boot.
    """
    # 2.4: si el usuario pidio generar el .service de systemd, hazlo y sal.
    # Esto debe ir antes de crear el socket UDP.
    if getattr(args, "gen_systemd", False):
        _generate_systemd_service(args)
        return
    world = World(team_size=args.bots, start_map=args.map)
    srv = Server(world, args.port, args.name)
    # Muestra todas las IPs donde el servidor escucha.
    print("=" * 60)
    print("  Servidor Defusa FPS %s" % VERSION)
    print("=" * 60)
    print("  UDP port:    %d" % args.port)
    print("  Bots/equipo: %d" % args.bots)
    print("  Mapa inicial: %s (%s)" % (world.map_name, MAPS[world.map_name].title))
    print("  Nombre del servidor: %s" % args.name)
    print()
    print("  IPs donde tus amigos pueden conectarse:")
    ips = get_lan_ips()
    if ips:
        for ip in ips:
            print("    -> %s:%d" % (ip, args.port))
    else:
        print("    -> (no se detectaron IPs LAN)")
        print("       Comparte tu IP manualmente con: defusa-fps (menu) > Unirse a partida LAN > I")
    # IP publica si se especifico --public-ip.
    if getattr(args, "public_ip", None):
        print()
        print("  IP publica (con port-forwarding en el router):")
        print("    -> %s:%d" % (args.public_ip, args.port))
    print()
    print("  Para conectar desde otra PC:")
    print("    1. Instala defusa-fps en la otra PC")
    print("    2. Ejecuta: defusa-fps")
    print("    3. Menu > Unirse a partida LAN > I > escribe la IP de arriba")
    print()
    print("  Ctrl+C para detener el servidor.")
    print("=" * 60)
    last = time.time()
    try:
        while True:
            now = time.time()
            srv.poll(now)
            while now - last >= TICK:
                world.update(TICK)
                last += TICK
            if now - last > 0.5:
                last = now
            srv.broadcast(world.snapshot(), now)
            time.sleep(0.004)
    except KeyboardInterrupt:
        print("\nServidor detenido.")
    finally:
        srv.close()


def _generate_systemd_service(args):
    """Genera un archivo .service de systemd para que el servidor arranque
    automaticamente en boot. util para servidores dedicados 24/7.

    El archivo se escribe en stdout para que el usuario lo redirija a:
      /etc/systemd/system/defusa-fps.service
    y luego haga:
      systemctl daemon-reload
      systemctl enable --now defusa-fps
    """
    script_path = os.path.abspath(__file__)
    python_path = sys.executable
    service = """[Unit]
Description=Defusa FPS dedicated server
After=network.target

[Service]
Type=simple
ExecStart={python} {script} --server --port {port} --bots {bots} --name "{name}" --map {map} --no-update
Restart=on-failure
RestartSec=5
User={user}
# Opcional: limitar recursos
# MemoryMax=512M
# CPUQuota=50%

[Install]
WantedBy=multi-user.target
""".format(python=python_path, script=script_path, port=args.port, bots=args.bots,
           name=args.name, map=args.map, user=os.environ.get("USER", "nobody"))
    print("# Guarda este archivo como /etc/systemd/system/defusa-fps.service")
    print("# Despues ejecuta:")
    print("#   sudo systemctl daemon-reload")
    print("#   sudo systemctl enable --now defusa-fps")
    print("#")
    print(service)
    print("# Para ver logs: journalctl -u defusa-fps -f")
    print("# Para parar:     sudo systemctl stop defusa-fps")
    print("# Para desinstalar:")
    print("#   sudo systemctl disable --now defusa-fps")
    print("#   sudo rm /etc/systemd/system/defusa-fps.service")


# ---- Bot callouts -----------------------------------------------------------
# Frases cortas que los bots dicen (en el feed de kill) al conseguir una baja.
# Es puro sabor: no afecta a la jugabilidad ni a la IA, solo da personalidad.
_BOT_KILL_LINES = [
    "Got one", "Down", "Eliminated", "Target down", "Easy", "Clean shot",
    "Baja confirmada", "Cubierto", "Buena", "Secuencia limpia",
]
_BOT_CALL_LINES = [
    "Rushing A", "Rushing B", "Need backup", "Spotting enemy",
    "Bomb down", "Cover me", "Going for the plant", "Rotate to B",
]
def run_gui(args):
    if r3d is None:
        sys.exit("Falta python3-numpy (sudo apt install python3-numpy)")
    import pygame

    # 2.5: detecta Android para usar controles tactiles + config movil.
    _is_android = False
    try:
        from android_compat import is_android, android_config
        _is_android = is_android()
    except Exception:
        # Si android_compat falla por cualquier razon, continuamos sin el.
        # El juego seguira funcionando con controles de PC (que no
        # funcionaran en Android pero al menos no crashea).
        android_config = None
    if _is_android and android_config is None:
        _is_android = False

    try:
        pygame.init()
    except Exception as e:
        sys.exit("No se pudo inicializar pygame: %s" % e)
    try:
        pygame.mixer.init(22050, -16, 1, 512)
    except Exception:
        pass
    try:
        pygame.display.set_caption("Defusa FPS")
    except Exception:
        pass
    scene = r3d.Scene(GRID, SITES, SPAWNS, ACTIVE_MAP.theme)
    # 2.3: comprueba si el usuario quiere modo ultra (GPU). Lo intentamos
    # solo si se pidio explicitamente; si falla, caemos al modo software.
    # 2.5: en Android no usamos OpenGL (GLES != GL).
    use_gl = bool(getattr(args, "gl", False)) and not _is_android
    gl_renderer = None
    gl_screen = None
    if use_gl:
        try:
            import glrenderer
            if not glrenderer.is_available():
                sys.stderr.write("Defusa: OpenGL no disponible, usando modo software.\n")
                use_gl = False
        except Exception as e:
            sys.stderr.write("Defusa: no se pudo cargar glrenderer (%s).\n" % e)
            use_gl = False
    # 2.5: en Android usa resolucion mas baja y SCALED (sin RESIZABLE que
    # puede crashear en algunos dispositivos).
    if _is_android:
        # Config movil: si android_config fallo, usar valores por defecto.
        acfg = {"width": 720, "height": 480, "div": 4, "sensitivity": 0.0035}
        try:
            if android_config is not None:
                acfg = android_config()
        except Exception:
            pass
        try:
            screen = pygame.display.set_mode((acfg["width"], acfg["height"]), pygame.SCALED)
        except Exception:
            try:
                screen = pygame.display.set_mode((acfg["width"], acfg["height"]))
            except Exception:
                # Ultimo recurso: pantalla completa sin flags.
                screen = pygame.display.set_mode((0, 0))
    elif use_gl:
        screen = pygame.display.set_mode((1024, 640), pygame.OPENGL | pygame.DOUBLEBUF | pygame.RESIZABLE)
    else:
        screen = pygame.display.set_mode((1024, 640), pygame.RESIZABLE)
    fonts = {"s": pygame.font.Font(None, 22), "m": pygame.font.Font(None, 34), "l": pygame.font.Font(None, 72)}
    snd = make_sounds(pygame)
    # 2.5: en Android no existe USER; usar "Jugador" como fallback.
    _default_name = os.environ.get("USER") or os.environ.get("USERNAME") or "Jugador"
    cfg = {"name": _default_name[:12], "team": "C", "bots": 4,
           "map": MAP_ORDER[0], "skin": "classic", "server_play_too": False}
    clock = pygame.time.Clock()
    while True:
        choice = menu(pygame, screen, fonts, clock, cfg, args)
        if choice is None:
            break
        kind, param = choice
        # El menu puede cambiar el mapa seleccionado: hay que aplicarlo al
        # modulo antes de construir la escena inicial de la sesion.
        set_active_map(cfg["map"])
        scene = r3d.Scene(GRID, SITES, SPAWNS, ACTIVE_MAP.theme)
        # 2.4.1: servidor dedicado desde el menu. Arranca en un hilo para
        # que el menu siga activo y muestre las IPs. El servidor corre
        # hasta que el usuario vuelva al menu.
        if kind == "dedicated":
            dedicated_msg = _start_dedicated_from_menu(cfg, args)
            show_message(pygame, screen, fonts, clock, dedicated_msg)
            continue
        if kind == "stop_dedicated":
            # 2.4.2: detiene el servidor dedicado y muestra confirmacion.
            stop_msg = _stop_dedicated_server()
            show_message(pygame, screen, fonts, clock, stop_msg)
            continue
        if kind == "servidor":
            # 2.4.3: abre el submenu del servidor dedicado.
            sub_result = server_menu(pygame, screen, fonts, clock, cfg, args)
            if sub_result is None:
                break  # QUIT
            sub_kind, sub_param = sub_result
            if sub_kind == "join":
                # Conectarse al propio servidor (localhost) o a uno remoto.
                kind = "join"
                param = sub_param
                # Cae al bloque de NetSession mas abajo.
            elif sub_kind == "back":
                continue
            else:
                continue
        try:
            if kind == "solo":
                sess = LocalSession(cfg["name"], cfg["team"], max(1, cfg["bots"]), False,
                                    start_map=cfg["map"])
            elif kind == "host":
                sess = LocalSession(cfg["name"], cfg["team"], cfg["bots"], True,
                                    start_map=cfg["map"])
                ips = get_lan_ips()
                if ips:
                    ip_lines = "   ".join("%s:%d" % (ip, PORT) for ip in ips)
                    host_msg = ("Partida LAN iniciada (mapa: %s)\nComparte esta IP con tus amigos:\n"
                                % MAPS[cfg["map"]].title) + ip_lines + "\n\nPulsa una tecla para continuar"
                else:
                    host_msg = ("Partida LAN iniciada en el puerto %d (mapa: %s)\n"
                                "No pude detectar la IP de la red.\n"
                                "Usa 'I' en Unirse a partida LAN para escribirla manualmente.\n\n"
                                "Pulsa una tecla para continuar"
                                % (PORT, MAPS[cfg["map"]].title))
                show_message(pygame, screen, fonts, clock, host_msg)
            else:
                sess = NetSession(param[0], param[1], cfg["name"], cfg["team"])
        except OSError as e:
            show_message(pygame, screen, fonts, clock, "No se pudo iniciar: %s" % e)
            continue
        # 2.3: crea el GLRenderer si el usuario pidio modo GPU.
        if use_gl:
            try:
                gl_renderer = glrenderer.GLRenderer(GRID, ACTIVE_MAP.theme,
                                                     screen.get_width(),
                                                     screen.get_height())
            except Exception as e:
                sys.stderr.write("Defusa: fallo al crear GLRenderer (%s), "
                                 "usando CPU.\n" % e)
                gl_renderer = None
        res = play(pygame, screen, fonts, clock, sess, snd, scene, gl_renderer, skin=cfg.get("skin", "classic"))
        sess.close()
        if gl_renderer is not None:
            gl_renderer.close()
            gl_renderer = None
        release_mouse(pygame)
        if res == "quit":
            break
    pygame.quit()


def make_sounds(pygame):
    import array
    sr = 22050
    out = {}
    try:
        def noise(dur, vol, decay, lp=0.0):
            n, a, y = int(sr * dur), array.array("h"), 0.0
            for i in range(n):
                x = random.uniform(-1, 1)
                y = y * lp + x * (1 - lp)
                a.append(int(y * vol * math.exp(-decay * i / n) * 32767))
            return a

        def tone(freq, dur, vol):
            n = int(sr * dur)
            return array.array("h", [int(math.sin(2 * math.pi * freq * i / sr) * vol * 32767 *
                                         (1 - i / n)) for i in range(n)])

        def sweep(f0, f1, dur, vol):
            n = int(sr * dur)
            a = array.array("h")
            for i in range(n):
                t = i / n
                f = f0 + (f1 - f0) * t
                a.append(int(math.sin(2 * math.pi * f * i / sr) * vol * 32767 * (1 - t)))
            return a

        data = {"shot": noise(0.14, 0.6, 7, 0.3), "boom": noise(1.4, 0.95, 3, 0.93),
                "beep": tone(1100, 0.08, 0.4), "click": noise(0.05, 0.35, 3, 0.5),
                "ok": tone(660, 0.15, 0.5) + tone(880, 0.25, 0.5),
                # Nuevos efectos 2.0: hitmarker, headshot, paso, dano recibido.
                "hit": tone(1400, 0.04, 0.35) + tone(1900, 0.06, 0.30),
                "hs": sweep(800, 2200, 0.10, 0.55) + tone(2400, 0.10, 0.45),
                "step": noise(0.04, 0.18, 8, 0.25),
                "hurt": tone(220, 0.10, 0.55) + tone(180, 0.20, 0.45),
                "cash": tone(900, 0.06, 0.30) + tone(1200, 0.08, 0.30)}
        for k, v in data.items():
            out[k] = pygame.mixer.Sound(buffer=v.tobytes())
    except Exception:
        return {}
    return out


def play_snd(snd, name, dist=0.0):
    s = snd.get(name)
    if s:
        s.set_volume(clamp(1.0 - dist / 22.0, 0.0, 1.0))
        s.play()


def text(pygame, screen, font, s, pos, color=(255, 255, 255), center=False, shadow=True):
    img = font.render(s, True, color)
    r = img.get_rect()
    if center:
        r.center = pos
    else:
        r.topleft = pos
    if shadow:
        sh = font.render(s, True, (0, 0, 0))
        screen.blit(sh, (r.x + 2, r.y + 2))
    screen.blit(img, r)


def show_message(pygame, screen, fonts, clock, msg):
    lines = str(msg).split("\n")
    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            if e.type == pygame.KEYDOWN or e.type == pygame.MOUSEBUTTONDOWN:
                return
        screen.fill((15, 15, 22))
        w, h = screen.get_size()
        line_h = 42
        start_y = h // 2 - (len(lines) * line_h) // 2
        for i, line in enumerate(lines):
            color = (255, 205, 100) if i == 0 else (225, 225, 230)
            font = fonts["m"] if i == 0 else fonts["s"]
            text(pygame, screen, font, line, (w // 2, start_y + i * line_h), color, True)
        pygame.display.flip()
        clock.tick(30)


def _parse_ip_input(raw):
    """Limpia y valida una IP introducida por el usuario.
    Acepta:
      - "192.168.1.5"        → ("192.168.1.5", PORT)
      - "192.168.1.5:27015"  → ("192.168.1.5", 27015)
      - " 192.168.1.5 "      → ("192.168.1.5", PORT)  (strips spaces)
      - "localhost"           → ("127.0.0.1", PORT)
    Devuelve (ip, port) o None si es invalida.
    """
    if not raw:
        return None
    # Limpiar espacios y saltos de linea.
    raw = raw.strip().strip()
    if not raw:
        return None
    # Aceptar "localhost".
    if raw.lower() == "localhost":
        return ("127.0.0.1", PORT)
    # Si tiene ":puerto", separarlo.
    port = PORT
    if ":" in raw:
        parts = raw.rsplit(":", 1)
        raw = parts[0].strip()
        try:
            port = int(parts[1].strip())
        except ValueError:
            return None
    # Validar que parece una IP (4 numeros separados por puntos).
    parts = raw.split(".")
    if len(parts) != 4:
        return None
    for p in parts:
        try:
            n = int(p)
            if n < 0 or n > 255:
                return None
        except ValueError:
            return None
    return (raw, port)


def edit_text(pygame, screen, fonts, clock, title, value, maxlen):
    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return None
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_RETURN:
                    return value
                if e.key == pygame.K_ESCAPE:
                    return None
                if e.key == pygame.K_BACKSPACE:
                    value = value[:-1]
                elif e.unicode and e.unicode.isprintable() and len(value) < maxlen:
                    value += e.unicode
        screen.fill((15, 15, 22))
        w, h = screen.get_size()
        text(pygame, screen, fonts["m"], title, (w // 2, h // 2 - 50), (200, 200, 200), True)
        text(pygame, screen, fonts["m"], value + "_", (w // 2, h // 2), (255, 230, 120), True)
        text(pygame, screen, fonts["s"], "Enter: aceptar   Esc: cancelar", (w // 2, h // 2 + 60), (150, 150, 150), True)
        pygame.display.flip()
        clock.tick(30)


def scan_lan(pygame, screen, fonts, clock, cfg):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("", 0))
    sock.setblocking(False)
    found = {}
    last = 0.0
    sel = 0
    broadcasts = ["255.255.255.255"]
    broadcasts.extend(bcast for _, bcast in get_lan_interfaces())
    broadcasts = list(dict.fromkeys(broadcasts))
    try:
        while True:
            now = time.time()
            if now - last > 1.0:
                last = now
                # Consulta por broadcast global y por cada subred conectada.
                for dst in broadcasts:
                    try:
                        sock.sendto(b"DEFUSA?", (dst, PORT))
                    except OSError:
                        pass
                # También permite detectar una partida alojada en este equipo.
                try:
                    sock.sendto(b"DEFUSA?", ("127.0.0.1", PORT))
                except OSError:
                    pass
            while True:
                try:
                    data, addr = sock.recvfrom(2048)
                except (BlockingIOError, ConnectionError, InterruptedError):
                    break
                except OSError:
                    break
                if data.startswith(b"DEFUSA!"):
                    try:
                        info = json.loads(data[7:].decode())
                        found[addr[0]] = info
                    except Exception:
                        pass
            hosts = sorted(found)
            sel = clamp(sel, 0, max(0, len(hosts) - 1))
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return "quit"
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        return None
                    if e.key == pygame.K_UP:
                        sel -= 1
                    if e.key == pygame.K_DOWN:
                        sel += 1
                    if e.key == pygame.K_r:
                        found.clear()
                        last = 0.0
                    if e.key == pygame.K_RETURN and hosts:
                        return (hosts[sel], PORT)
                    if e.key == pygame.K_i:
                        ip = edit_text(pygame, screen, fonts, clock, "IP del servidor:", cfg.get("ip", ""), 40)
                        if ip:
                            # 2.6.1: limpiar y validar la IP.
                            parsed = _parse_ip_input(ip)
                            if parsed is None:
                                show_message(pygame, screen, fonts, clock,
                                             "IP invalida: %s\n\nFormatos validos:\n"
                                             "  192.168.1.5\n"
                                             "  192.168.1.5:27015\n"
                                             "  localhost" % ip)
                                continue
                            ip_clean, port_clean = parsed
                            cfg["ip"] = ip_clean
                            # Mostrar pantalla de conexion.
                            show_message(pygame, screen, fonts, clock,
                                         "Conectando a %s:%d...\n\n"
                                         "Si no conecta en 10 segundos:\n"
                                         "  - Verifica que el servidor este activo\n"
                                         "  - Verifica que esten en la misma red Wi-Fi\n"
                                         "  - Verifica que el firewall permita UDP %d" % (ip_clean, port_clean, port_clean))
                            return (ip_clean, port_clean)
            screen.fill((15, 15, 22))
            w, h = screen.get_size()
            text(pygame, screen, fonts["l"], "Partidas LAN", (w // 2, 75), (255, 200, 80), True)
            if not hosts:
                text(pygame, screen, fonts["m"], "Buscando servidores en la red local...", (w // 2, h // 2 - 12), (180, 180, 180), True)
                text(pygame, screen, fonts["s"], "Comprueba que ambos equipos estén en la misma Wi-Fi/LAN", (w // 2, h // 2 + 28), (140, 150, 165), True)
            for i, ip in enumerate(hosts):
                inf = found[ip]
                col = (255, 255, 120) if i == sel else (210, 210, 210)
                # 2.2: muestra el mapa del servidor si esta disponible.
                map_str = ""
                if inf.get("maptitle"):
                    map_str = "  [%s]" % inf["maptitle"]
                elif inf.get("map"):
                    map_str = "  [%s]" % inf["map"]
                text(pygame, screen, fonts["m"], "%s   %s:%d   jugadores %s/%s%s" % (
                    inf.get("name", "?"), ip, PORT, inf.get("players", "?"),
                    inf.get("max", "?"), map_str),
                    (w // 2, 155 + i * 44), col, True)
            text(pygame, screen, fonts["s"], "Enter: unirse   R: buscar otra vez   I: escribir IP   Esc: volver",
                 (w // 2, h - 50), (150, 150, 150), True)
            pygame.display.flip()
            clock.tick(30)
    finally:
        sock.close()


def release_mouse(pygame):
    """Ensure the pointer is visible, absolute and not grabbed by the game."""
    try:
        pygame.event.set_grab(False)
    except Exception:
        pass
    # Pygame 2 supports relative mode; older builds may not expose this API.
    try:
        pygame.mouse.set_relative_mode(False)
    except Exception:
        pass
    try:
        pygame.mouse.set_visible(True)
    except Exception:
        pass
    try:
        pygame.mouse.get_rel()
    except Exception:
        pass


def present_gl_frame(screen, gl_state):
    """Sube el contenido de la Surface 'screen' a OpenGL y hace flip.

    Solo se llama cuando arrancamos en modo GPU (pygame.OPENGL). En modo
    software normal, pygame.display.flip() basta y esta funcion no se usa.

    gl_state es un dict persistente que mantiene la textura GL y otros
    recursos entre frames. Se inicializa la primera vez con el tamano de
    pantalla actual; si cambia el tamano, se reconstruye.

    Implementacion:
      1. Lee los bytes de la Surface de software 'screen' con pygame.image.tostring.
      2. Sube esos bytes a una textura GL persistente con glTexSubImage2D.
      3. Dibuja un quad fullscreen con la textura (shader trivial).
      4. pygame.display.flip() presenta el backbuffer.

    El coste dominante es glTexSubImage2D (~3 ms en llvmpipe para 1024x640).
    En GPU real es < 1 ms porque usa DMA directo.
    """
    if gl_state is None:
        return False
    try:
        from OpenGL.GL import (glGenTextures, glBindTexture, glTexImage2D,
                                glTexSubImage2D, glTexParameteri,
                                glActiveTexture, glUseProgram, glUniform1i,
                                glUniform2f, glGetUniformLocation,
                                glDrawArrays, glViewport, glDisable,
                                GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
                                GL_TEXTURE_MIN_FILTER, GL_NEAREST, GL_RGB,
                                GL_UNSIGNED_BYTE, GL_TEXTURE0, GL_TRIANGLES,
                                GL_BLEND, GL_DEPTH_TEST)
    except ImportError:
        return False
    w, h = screen.get_size()
    # Inicializa recursos GL la primera vez o si cambia el tamano.
    key = ("present", w, h)
    if gl_state.get("key") != key:
        try:
            tex = glGenTextures(1)
            glBindTexture(GL_TEXTURE_2D, tex)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0,
                         GL_RGB, GL_UNSIGNED_BYTE, None)
            gl_state["key"] = key
            gl_state["tex"] = tex
        except Exception:
            return False
    tex = gl_state["tex"]
    # Convierte la Surface a bytes RGB. pygame.image.tostring es rapido.
    # La Surface de pygame es top-down; OpenGL espera bottom-up, asi que
    # usamos el modo 'flipped' de tostring para voltearla en el momento
    # del upload (mas barato que hacer flip en numpy).
    try:
        # 2.3: pygame.image.tostring esta deprecated en pygame 2.3+;
        # usamos tobytes si esta disponible, sino tostring.
        # 'pygame' se importa en run_gui antes de llamar a play(); aqui lo
        # resolvemos via sys.modules para no depender del orden de import.
        _pg = sys.modules.get("pygame")
        if _pg is None:
            import pygame as _pg
        if hasattr(_pg.image, "tobytes"):
            raw = _pg.image.tobytes(screen, "RGB", flipped=True)
        else:
            raw = _pg.image.tostring(screen, "RGB", flipped=True)
    except Exception as _e:
        sys.stderr.write("Defusa: present_gl_frame tostring failed: %s\n" % _e)
        return False
    glBindTexture(GL_TEXTURE_2D, tex)
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE, raw)
    # Dibuja un quad fullscreen usando el vertex shader del glrenderer.
    # El programa del glrenderer ya esta linkeado; aqui solo necesitamos
    # mapear la textura a pantalla. Lo mas simple: usar un programa
    # trivial dedicado al blit.
    blit_prog = gl_state.get("blit_prog")
    if blit_prog is None:
        try:
            from OpenGL.GL import (glCreateProgram, glCreateShader,
                                    glShaderSource, glCompileShader,
                                    glAttachShader, glLinkProgram,
                                    glGetShaderiv, glGetProgramiv,
                                    glGetShaderInfoLog, glGetProgramInfoLog,
                                    glGetUniformLocation,
                                    GL_VERTEX_SHADER, GL_FRAGMENT_SHADER,
                                    GL_COMPILE_STATUS, GL_LINK_STATUS)
            vs_src = """#version 330 core
out vec2 v_uv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    v_uv = p * 0.5;          // (0..1) para sampling de textura
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"""
            fs_src = """#version 330 core
in vec2 v_uv;
out vec4 frag_color;
uniform sampler2D u_tex;
void main() {
    frag_color = texture(u_tex, vec2(v_uv.x, 1.0 - v_uv.y));
}
"""
            vs = glCreateShader(GL_VERTEX_SHADER)
            glShaderSource(vs, vs_src)
            glCompileShader(vs)
            if not glGetShaderiv(vs, GL_COMPILE_STATUS):
                log = glGetShaderInfoLog(vs)
                if isinstance(log, bytes):
                    log = log.decode(errors="replace")
                raise RuntimeError("blit vs: %s" % log)
            fs = glCreateShader(GL_FRAGMENT_SHADER)
            glShaderSource(fs, fs_src)
            glCompileShader(fs)
            if not glGetShaderiv(fs, GL_COMPILE_STATUS):
                log = glGetShaderInfoLog(fs)
                if isinstance(log, bytes):
                    log = log.decode(errors="replace")
                raise RuntimeError("blit fs: %s" % log)
            prog = glCreateProgram()
            glAttachShader(prog, vs)
            glAttachShader(prog, fs)
            glLinkProgram(prog)
            if not glGetProgramiv(prog, GL_LINK_STATUS):
                log = glGetProgramInfoLog(prog)
                if isinstance(log, bytes):
                    log = log.decode(errors="replace")
                raise RuntimeError("blit link: %s" % log)
            gl_state["blit_prog"] = prog
            gl_state["u_tex"] = glGetUniformLocation(prog, "u_tex")
            blit_prog = prog
        except Exception as _e:
            sys.stderr.write("Defusa: present_gl_frame blit shader failed: %s\n" % _e)
            return False
    # Dibuja el quad fullscreen.
    glUseProgram(blit_prog)
    glViewport(0, 0, w, h)
    glDisable(GL_BLEND)
    glDisable(GL_DEPTH_TEST)
    glActiveTexture(GL_TEXTURE0)
    glBindTexture(GL_TEXTURE_2D, tex)
    glUniform1i(gl_state["u_tex"], 0)
    glDrawArrays(GL_TRIANGLES, 0, 3)
    return True


def _copy_to_clipboard(text):
    """Copia texto al portapapeles del sistema.

    2.5: cross-platform. Intenta varios metodos en orden:
    1. pygame.scrap (API nativa de SDL2, X11/Wayland/Windows)
    2. Windows: clip command (build-in en Windows 10+)
    3. Linux: xclip
    4. Linux: xsel

    Devuelve True si alguno funciono, False si todos fallaron.
    """
    text_bytes = text.encode("utf-8")
    # Metodo 1: pygame.scrap.
    try:
        import pygame as _pg
        if hasattr(_pg, "scrap"):
            _pg.scrap.init()
            _pg.scrap.put(_pg.SCRAP_TEXT, text_bytes)
            return True
    except Exception:
        pass
    # Metodo 2: Windows clip command.
    if sys.platform == "win32":
        try:
            subprocess.run(["clip"], input=text_bytes,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=3, shell=True)
            return True
        except Exception:
            pass
    # Metodo 3: xclip (Linux).
    if shutil.which("xclip"):
        try:
            subprocess.run(["xclip", "-selection", "clipboard"],
                           input=text_bytes, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=3)
            return True
        except Exception:
            pass
    # Metodo 4: xsel (Linux).
    if shutil.which("xsel"):
        try:
            subprocess.run(["xsel", "--clipboard", "--input"],
                           input=text_bytes, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=3)
            return True
        except Exception:
            pass
    return False


def server_menu(pygame, screen, fonts, clock, cfg, args):
    """Submenu del servidor dedicado.

    Permite:
    - Ver el estado del servidor (corriendo/detenido, IPs, mapa, bots)
    - Abrir el servidor (con opcion de jugar tambien o no)
    - Cerrar el servidor
    - Volver al menu principal

    El submenu se renderiza sobre el mismo fondo del menu principal para
    mantener la coherencia visual.
    """
    release_mouse(pygame)
    sel = 0
    # Estado visual compartido con el menu principal.
    if not hasattr(menu, "_state"):
        menu._state = {}
    state = menu._state
    while True:
        # Construye la lista de items segun el estado del servidor.
        running = _dedicated_server_running()
        info = _dedicated_server_info()
        if running:
            items = ["toggle", "copy_ip", "join_self", "back"]
        else:
            items = ["toggle", "play_too", "back"]
        sel = sel % len(items)
        release_mouse(pygame)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return None
            if e.type == pygame.KEYDOWN:
                it = items[sel]
                if e.key == pygame.K_UP:
                    sel = (sel - 1) % len(items)
                elif e.key == pygame.K_DOWN:
                    sel = (sel + 1) % len(items)
                elif e.key in (pygame.K_LEFT, pygame.K_RIGHT) and it == "play_too":
                    # Cicla si/no con flechas.
                    cfg["server_play_too"] = not cfg.get("server_play_too", False)
                elif e.key == pygame.K_RETURN:
                    if it == "toggle":
                        if running:
                            # Cerrar servidor.
                            stop_msg = _stop_dedicated_server()
                            show_message(pygame, screen, fonts, clock, stop_msg)
                        else:
                            # Abrir servidor.
                            start_msg = _start_dedicated_from_menu(cfg, args)
                            show_message(pygame, screen, fonts, clock, start_msg)
                            # Si el usuario eligio "jugar tambien", lanzar
                            # la partida local conectandose a localhost.
                            if cfg.get("server_play_too", False) and _dedicated_server_running():
                                return ("join", ("127.0.0.1", PORT))
                    elif it == "copy_ip":
                        # 2.4.4: copia la IP del servidor al portapapeles.
                        if info and info["ips"]:
                            ip_text = "%s:%d" % (info["ips"][0], info["port"])
                            ok = _copy_to_clipboard(ip_text)
                            if ok:
                                show_message(pygame, screen, fonts, clock,
                                             "IP copiada al portapapeles:\n\n%s\n\nYa puedes pegarla (Ctrl+V) donde quieras." % ip_text)
                            else:
                                show_message(pygame, screen, fonts, clock,
                                             "No se pudo copiar automaticamente.\n\nCopia manualmente:\n%s" % ip_text)
                        else:
                            show_message(pygame, screen, fonts, clock,
                                         "No hay IP disponible.\nEl servidor no detecto IPs LAN.")
                    elif it == "join_self":
                        # Conectarse al propio servidor (localhost).
                        return ("join", ("127.0.0.1", PORT))
                    elif it == "play_too":
                        # Cicla si/no con Enter tambien.
                        cfg["server_play_too"] = not cfg.get("server_play_too", False)
                    elif it == "back":
                        return ("back", None)
                elif e.key == pygame.K_ESCAPE:
                    return ("back", None)

        # --- Render del submenu ---
        w, h = screen.get_size()
        # Fondo cacheado (mismo que el menu principal).
        bg_key = ("menu_bg", w, h)
        if state.get("menu_bg_key") != bg_key:
            bg = pygame.Surface((w, h))
            for y in range(h):
                t = y / max(1, h - 1)
                r = int(12 + (24 - 12) * t)
                g = int(14 + (18 - 14) * t)
                b = int(20 + (38 - 20) * t)
                pygame.draw.line(bg, (r, g, b), (0, y), (w, y))
            import random as _rnd
            rng = _rnd.Random(7)
            for _ in range(40):
                sx = rng.randint(0, w - 1)
                sy = rng.randint(0, h - 1)
                sb = rng.randint(60, 160)
                bg.set_at((sx, sy), (sb, sb, sb + 20))
            state["menu_bg_key"] = bg_key
            state["menu_bg"] = bg
        screen.blit(state["menu_bg"], (0, 0))

        # Titulo.
        title_col = (255, int(200 + 25 * math.sin(state.get("menu_t", 0.0) * 1.5)),
                     int(80 + 20 * math.sin(state.get("menu_t", 0.0) * 0.9)))
        text(pygame, screen, fonts["l"], "SERVIDOR DEDICADO", (w // 2, 90), title_col, True)
        pygame.draw.line(screen, (255, 200, 80), (w // 2 - 220, 120), (w // 2 + 220, 120), 2)

        # --- Panel de estado ---
        panel_y = 150
        if running and info:
            # Servidor corriendo: muestra info completa.
            blink = int(time.time() * 2) % 2 == 0
            dot = "● ACTIVO" if blink else "○ ACTIVO"
            text(pygame, screen, fonts["m"], dot, (w // 2, panel_y), (100, 255, 100), True)
            ips_str = ", ".join("%s:%d" % (ip, info["port"]) for ip in info["ips"]) if info["ips"] else "(sin IP detectada)"
            map_title = MAPS.get(info["map"], MAPS[info["map"]]).title if info["map"] in MAPS else info["map"]
            lines = [
                "IPs: %s" % ips_str,
                "Nombre: %s" % info["name"],
                "Mapa: %s    Bots: %d por equipo" % (map_title, info["bots"]),
                "",
                "Tus amigos pueden conectarse con:",
                "  Menu > Unirse a partida LAN > I > escribir la IP de arriba",
            ]
            for i, line in enumerate(lines):
                col = (200, 220, 200) if line else (0, 0, 0)
                text(pygame, screen, fonts["s"], line, (w // 2, panel_y + 35 + i * 22), col, True)
        else:
            # Servidor detenido.
            text(pygame, screen, fonts["m"], "○ DETENIDO", (w // 2, panel_y), (200, 100, 100), True)
            text(pygame, screen, fonts["s"], "No hay ningun servidor dedicado corriendo.", (w // 2, panel_y + 35), (180, 180, 180), True)

        # --- Items del submenu ---
        item_y = 350
        labels = {}
        if running:
            labels["toggle"] = "CERRAR servidor"
            labels["copy_ip"] = "Copiar IP al portapapeles"
            labels["join_self"] = "Conectar yo mismo al servidor"
            labels["back"] = "Volver al menu principal"
        else:
            labels["toggle"] = "ABRIR servidor"
            labels["play_too"] = "Jugar tambien: %s" % ("SI" if cfg.get("server_play_too", False) else "NO")
            labels["back"] = "Volver al menu principal"

        for i, k in enumerate(items):
            col = (255, 255, 120) if i == sel else (215, 215, 215)
            if i == sel:
                # Fondo translucido + marcador lateral.
                marker = pygame.Surface((500, 32), pygame.SRCALPHA)
                marker.fill((255, 200, 80, 32))
                screen.blit(marker, (w // 2 - 250, item_y + i * 44 - 16))
                pygame.draw.polygon(screen, (255, 200, 80),
                                    [(w // 2 - 260, item_y + i * 44 - 6),
                                     (w // 2 - 248, item_y + i * 44),
                                     (w // 2 - 260, item_y + i * 44 + 6)])
            text(pygame, screen, fonts["m"], labels[k], (w // 2, item_y + i * 44), col, True)

        # Footer.
        text(pygame, screen, fonts["s"], "↑/↓ navegar   Enter seleccionar   Esc volver",
             (w // 2, h - 40), (140, 140, 150), True)
        text(pygame, screen, fonts["s"], "Version %s" % VERSION, (w // 2, h - 78), (130, 190, 230), True)

        state["menu_t"] = state.get("menu_t", 0.0) + 1.0 / 30.0
        pygame.display.flip()
        clock.tick(30)


def menu(pygame, screen, fonts, clock, cfg, args):
    release_mouse(pygame)
    sel = 0
    update_msg = ""
    # Estado visual del menu (degradado cacheado + animacion del titulo).
    # Se mantiene entre llamadas a menu() usando un atributo de la funcion.
    if not hasattr(menu, "_state"):
        menu._state = {}
    state = menu._state
    while True:
        # 2.4.3: un solo item "servidor" abre un submenu dedicado donde
        # el usuario puede ver el estado, abrir/cerrar el servidor y elegir
        # si quiere jugar tambien. Reemplaza los items dedicated/stop_dedicated.
        items = ["solo", "host", "join", "servidor", "team", "skin", "bots", "map", "name", "update", "quit"]
        # Mantener sel dentro del rango si cambio la lista.
        sel = sel % len(items)
        # Re-apply every frame so the cursor is released even after returning
        # from gameplay or when a platform/window manager restores mouse grab.
        release_mouse(pygame)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return None
            if e.type == pygame.KEYDOWN:
                it = items[sel]
                if e.key == pygame.K_UP:
                    sel = (sel - 1) % len(items)
                elif e.key == pygame.K_DOWN:
                    sel = (sel + 1) % len(items)
                elif e.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_RETURN):
                    d = -1 if e.key == pygame.K_LEFT else 1
                    if it == "team":
                        cfg["team"] = "T" if cfg["team"] == "C" else "C"
                        # 2.4: al cambiar de equipo, la skin debe ser valida
                        # para el nuevo equipo. Si no, vuelve a classic.
                        if cfg.get("skin", "classic") not in ("classic", "arctic", "jungle", "desert", "urban"):
                            cfg["skin"] = "classic"
                    elif it == "skin":
                        # 2.4: cicla entre las 5 skins disponibles.
                        skins = ["classic", "arctic", "jungle", "desert", "urban"]
                        idx = skins.index(cfg.get("skin", "classic")) if cfg.get("skin") in skins else 0
                        idx = (idx + d) % len(skins)
                        cfg["skin"] = skins[idx]
                    elif it == "bots":
                        cfg["bots"] = (cfg["bots"] + d) % 6
                    elif it == "map":
                        # Cicla por los mapas disponibles con flechas izq/der.
                        idx = MAP_ORDER.index(cfg["map"]) if cfg["map"] in MAP_ORDER else 0
                        idx = (idx + d) % len(MAP_ORDER)
                        cfg["map"] = MAP_ORDER[idx]
                    elif e.key == pygame.K_RETURN:
                        if it in ("solo", "host"):
                            return (it, None)
                        if it == "servidor":
                            # 2.4.3: abre el submenu del servidor dedicado.
                            return ("servidor", None)
                        if it == "join":
                            r = scan_lan(pygame, screen, fonts, clock, cfg)
                            if r == "quit":
                                return None
                            if r:
                                return ("join", r)
                        elif it == "name":
                            n = edit_text(pygame, screen, fonts, clock, "Tu apodo:", cfg["name"], 12)
                            if n:
                                cfg["name"] = n
                        elif it == "update":
                            # 2.2: usa el nuevo helper que distingue local
                            # vs GitHub y muestre el origen en el mensaje.
                            update_msg = "Buscando actualizaciones..."
                            pygame.display.flip()
                            try:
                                info = update_available_info()
                                if info is None:
                                    update_msg = "Ya tienes la ultima version: %s" % VERSION
                                else:
                                    remote_version, source = info
                                    update_msg = "Actualizando a %s (desde %s)..." % (remote_version, source)
                                    # Si es local, la ruta ya esta en 'source';
                                    # si es GitHub, check_for_updates descargara.
                                    if source.startswith("local:"):
                                        local_path = source.split("local: ", 1)[1].strip()
                                        if _install_deb(local_path):
                                            try: os.unlink(local_path)
                                            except OSError: pass
                                            os.execv(sys.executable, [sys.executable, os.path.abspath(__file__)]
                                                     + [a for a in sys.argv if a not in ("--no-update",)])
                                        else:
                                            update_msg = "No se pudo instalar %s (ejecuta: sudo apt-get install -y %s)" % (
                                                remote_version, local_path)
                                    else:
                                        # GitHub: usa check_for_updates que descarga e instala.
                                        if check_for_updates(silent=False):
                                            os.execv(sys.executable, [sys.executable, os.path.abspath(__file__)]
                                                     + [a for a in sys.argv if a not in ("--no-update",)])
                                        else:
                                            update_msg = "No se pudo instalar la version %s" % remote_version
                            except Exception as exc:
                                update_msg = "No se pudo comprobar: %s" % exc
                        elif it == "quit":
                            return None
        screen.fill((12, 14, 20))
        w, h = screen.get_size()
        # --- Fondo con degradado vertical y un sutil patron de puntos.
        # Solo se redibuja cada ~30 frames; se cachea en una Surface para
        # no malgastar CPU por frame. Es puramente decorativo.
        bg_key = ("menu_bg", w, h)
        if state.get("menu_bg_key") != bg_key:
            bg = pygame.Surface((w, h))
            for y in range(h):
                t = y / max(1, h - 1)
                # Interpola entre azul oscuro (12,14,20) y un azul mas profundo
                # con tinte purpura (24,18,38) para dar profundidad.
                r = int(12 + (24 - 12) * t)
                g = int(14 + (18 - 14) * t)
                b = int(20 + (38 - 20) * t)
                pygame.draw.line(bg, (r, g, b), (0, y), (w, y))
            # Puntos decorativos: pequenas estrellas simulando un mapa tactico.
            rng_state = random.Random(7)
            for _ in range(40):
                sx = rng_state.randint(0, w - 1)
                sy = rng_state.randint(0, h - 1)
                sb = rng_state.randint(60, 160)
                bg.set_at((sx, sy), (sb, sb, sb + 20))
            state["menu_bg_key"] = bg_key
            state["menu_bg"] = bg
        screen.blit(state["menu_bg"], (0, 0))
        # Linea horizontal de acento bajo el titulo.
        pygame.draw.line(screen, (255, 200, 80),
                         (w // 2 - 180, 120), (w // 2 + 180, 120), 2)
        # Titulo con leve animacion de brillo (solo color, sin deformar).
        title_phase = (state.get("menu_t", 0.0))
        title_col = (255, int(200 + 25 * math.sin(title_phase * 1.5)),
                     int(80 + 20 * math.sin(title_phase * 0.9)))
        text(pygame, screen, fonts["l"], "DEFUSA FPS", (w // 2, 90), title_col, True)
        text(pygame, screen, fonts["s"], "Terroristas plantan la bomba - Antiterroristas la desactivan",
             (w // 2, 145), (160, 160, 170), True)
        map_title = MAPS[cfg["map"]].title if cfg["map"] in MAPS else cfg["map"]
        labels = {"solo": "Jugar solo (contra bots)", "host": "Crear partida LAN",
                  "join": "Unirse a partida LAN",
                  "servidor": "Servidor dedicado...",
                  "team": "Equipo: " + ("Terroristas (T)" if cfg["team"] == "T" else "Antiterroristas (CT)"),
                  # 2.4: nombre legible para cada skin.
                  "skin": "Skin: %s" % {"classic": "Clasico", "arctic": "Artico",
                                          "jungle": "Jungla", "desert": "Desertico",
                                          "urban": "Urbano"}.get(cfg.get("skin", "classic"), cfg.get("skin", "classic")),
                  "bots": "Bots por equipo: %d%s" % (cfg["bots"], "  (sin bots)" if cfg["bots"] == 0 else ""),
                  "map": "Mapa inicial: %s  (rotacion auto)" % map_title,
                  "name": "Apodo: " + cfg["name"],
                  "update": "Buscar actualizaciones", "quit": "Salir"}
        for i, k in enumerate(items):
            # Indicador lateral (>) para la opcion seleccionada y un sutil
            # fondo translucido para que el cursor sea mas visible.
            col = (255, 255, 120) if i == sel else (215, 215, 215)
            if i == sel:
                marker = pygame.Surface((440, 32), pygame.SRCALPHA)
                marker.fill((255, 200, 80, 32))
                screen.blit(marker, (w // 2 - 220, 205 + i * 40 - 16))
                pygame.draw.polygon(screen, (255, 200, 80),
                                    [(w // 2 - 230, 205 + i * 40 - 6),
                                     (w // 2 - 218, 205 + i * 40),
                                     (w // 2 - 230, 205 + i * 40 + 6)])
            text(pygame, screen, fonts["m"], labels[k], (w // 2, 205 + i * 40), col, True)
        # 2.4.2: indicador persistente de servidor dedicado en la esquina
        # superior izquierda. Es discreto: solo 2 lineas de texto verde con
        # un punto parpadeante para que se vea "vivo". No molesta al menu.
        srv_info = _dedicated_server_info()
        if srv_info is not None:
            # Punto parpadeante (cada 0.5s) para indicar que esta activo.
            blink = int(time.time() * 2) % 2 == 0
            dot = "●" if blink else "○"
            ips_str = ", ".join("%s:%d" % (ip, srv_info["port"]) for ip in srv_info["ips"]) if srv_info["ips"] else "sin IP detectada"
            text(pygame, screen, fonts["s"], "%s SERVIDOR DEDICADO ACTIVO" % dot,
                 (14, 175), (100, 255, 100))
            text(pygame, screen, fonts["s"], "  %s  |  %s  |  mapa: %s  |  bots: %d" % (
                ips_str, srv_info["name"],
                MAPS.get(srv_info["map"], MAPS[srv_info["map"]]).title if srv_info["map"] in MAPS else srv_info["map"],
                srv_info["bots"]),
                 (14, 197), (140, 220, 140))
        footer_y = h - 78
        text(pygame, screen, fonts["s"], "Versión %s" % VERSION, (w // 2, footer_y), (130, 190, 230), True)
        if update_msg:
            text(pygame, screen, fonts["s"], update_msg, (w // 2, footer_y - 24), (150, 230, 160), True)
        # 2.2: muestra stats vitales acumuladas a la derecha del menu.
        # Carga las stats una vez por segundo para no golpear el disco cada frame.
        if state.get("menu_stats_t", 0.0) + 1.0 < time.time():
            state["menu_stats"] = load_stats()
            state["menu_stats_t"] = time.time()
        s = state.get("menu_stats", {})
        if s:
            kd = s.get("kills", 0) / max(1, s.get("deaths", 0))
            stats_lines = [
                "ESTADISTICAS",
                "K: %d   D: %d   HS: %d   K/D: %.2f" % (
                    s.get("kills", 0), s.get("deaths", 0),
                    s.get("headshots", 0), kd),
                "Partidas: %d  Ganadas: %d  Racha: %d" % (
                    s.get("matches_played", 0), s.get("matches_won", 0),
                    s.get("best_streak", 0)),
            ]
            for i, line in enumerate(stats_lines):
                # Alinear a la derecha restando el ancho del texto.
                tw = fonts["s"].size(line)[0]
                text(pygame, screen, fonts["s"], line,
                     (w - 14 - tw, 200 + i * 22), (200, 200, 220))
        text(pygame, screen,
             fonts["s"], "WASD mover  Ratón apuntar  Clic disparar  R recargar  E plantar/desactivar  B tienda  P auto-compra  1/2/3/Q armas  Tab marcador  F2 calidad  Esc menú",
             (w // 2, h - 40), (140, 140, 150), True)
        state["menu_t"] = state.get("menu_t", 0.0) + 1.0 / 30.0
        pygame.display.flip()
        clock.tick(30)


TEAM_COL = {"T": (214, 150, 60), "C": (70, 110, 220)}


# --- 2.6: tienda con 5 categorias paginadas ---------------------------------
SHOP_CATEGORIES = {
    1: "Pistolas",
    2: "Primarias",
    3: "Cuchillos",
    4: "Granadas",
    5: "Equipamiento",
}


def shop_items_by_category(team, category):
    """Devuelve los items de una categoria para un equipo.
    Las teclas 1-9 dentro de cada categoria compran el item correspondiente.
    Para cambiar de categoria: flechas izq/der o teclas 1-5 cuando no hay
    tienda abierta con items (se hace con Q/E para paginar).
    """
    if category == 1:  # Pistolas
        items = ["deagle", "r8", "cz75"]
        if team == "T":
            items.append("elite")
        else:
            items.append("fiveseven")
    elif category == 2:  # Primarias
        if team == "T":
            items = ["ak47", "galil", "sg552", "mp5", "sawedoff", "awp"]
        else:
            items = ["m4a1", "famas", "aug", "mp5", "awp"]
    elif category == 3:  # Cuchillos
        items = ["karambit", "butterfly", "bayonet", "talon", "flip"]
    elif category == 4:  # Granadas
        items = ["he", "flash", "smoke"]
    elif category == 5:  # Equipamiento
        items = ["armor"]
        if team == "C":
            items.append("kit")
    else:
        items = []
    out = []
    for iid in items:
        if iid in GRENADES:
            out.append((iid, GRENADES[iid]["name"], GRENADES[iid]["price"]))
        elif iid in WEAPONS:
            st = WEAPONS[iid]
            if st["team"] in (None, team):
                out.append((iid, st["name"], st["price"]))
        elif iid == "armor":
            out.append(("armor", "Chaleco kevlar", ARMOR_PRICE))
        elif iid == "kit" and team == "C":
            out.append(("kit", "Kit de desactivación", KIT_PRICE))
    return out


def shop_items(team):
    """Compatibilidad: devuelve todos los items en una lista plana.
    2.6: usar shop_items_by_category para la tienda con categorias."""
    out = []
    for cat in range(1, 6):
        out.extend(shop_items_by_category(team, cat))
    # Quitar duplicados manteniendo orden.
    seen = set()
    unique = []
    for item in out:
        if item[0] not in seen:
            seen.add(item[0])
            unique.append(item)
    return unique


def can_buy_now(snap):
    return snap["ph"] == "freeze" or (snap["ph"] == "live" and snap["tm"] >= ROUND_T - BUY_WINDOW)


def render(pygame, screen, fonts, snap, me, cam, state, show_score, gl_renderer=None):
    w, h = screen.get_size()
    px, py, pa, pp = cam
    scene = state["scene"]
    np_ = r3d.np
    div = state["div"]
    rw, rh = max(200, w // div), max(120, h // div)
    rh -= rh % 2
    zoom = state["zoom"]
    fov = math.radians(24 if zoom else 70)

    # ---- escena 3D
    # 2.3: si tenemos GLRenderer activo, lo usamos para el mundo (paredes,
    # suelo, techo, niebla, texturas procedurales). Eso corre en GPU.
    # Las cajas (personajes, props, arma) siguen dibujandose en CPU con
    # draw_boxes porque son mas complejas y su coste es bajo comparado
    # con el raycasting del mundo.
    if gl_renderer is not None:
        try:
            img, depth = gl_renderer.render_world(px, py, pa, rw, rh, fov, pp)
        except Exception:
            # Si GL falla en runtime, cae al renderer CPU en este frame.
            img, depth = scene.render_world(px, py, pa, rw, rh, fov, pp)
    else:
        img, depth = scene.render_world(px, py, pa, rw, rh, fov, pp)
    cam3 = scene.make_cam(px, py, r3d.EYE, pa, rw, fov, pp)
    if getattr(scene, "props", None):
        scene.draw_boxes(img, depth, cam3, scene.props, rw, rh, fogd=20.0)
    labels = []
    for r in snap["pl"]:
        if r[I_ID] == me[I_ID] or not r[I_ALIVE]:
            continue
        if not scene.visible(cam3, (r[I_X], r[I_Y], 0.55), 0.5, 0.62, depth, rw, rh):
            continue
        an = state["anim"].get(r[I_ID])
        moving = an is not None and state["now"] - an["mv"] < 0.25
        head_yaw = 0.0
        if r[I_TEAM] == me[I_TEAM]:
            # Mirada amistosa puramente visual: no modifica yaw ni paquetes LAN.
            # Los compañeros cercanos giran la cabeza hacia el jugador local.
            dxm, dym = me[I_X] - r[I_X], me[I_Y] - r[I_Y]
            ally_dist = math.hypot(dxm, dym)
            if 0.65 < ally_dist < 9.0:
                toward = math.atan2(dym, dxm)
                head_yaw = clamp(angdiff(toward, r[I_A]), -0.78, 0.78)
        # 2.4: extrae el skin del jugador del snapshot si esta disponible.
        skin = r[I_SKIN] if len(r) > I_SKIN else "classic"
        boxes = r3d.character_boxes(r[I_X], r[I_Y], r[I_A], r[I_TEAM], WEAPON_ORDER[r[I_WPN]],
                                    an["ph"] if an else 0.0, moving,
                                    bool(r[I_BOMB]) and r[I_TEAM] == "T", head_yaw=head_yaw,
                                    skin=skin)
        scene.draw_boxes(img, depth, cam3, boxes, rw, rh)
        if r[I_TEAM] == me[I_TEAM]:
            pr = scene.project(cam3, (r[I_X], r[I_Y], 1.28), rw, rh)
            if pr:
                labels.append((r[I_NAME], pr[0] * w / rw, pr[1] * h / rh))
    bm = snap["bm"]
    if bm[0] in ("dropped", "planted"):
        blink = int(state["now"] * 4) % 2 == 0
        if scene.visible(cam3, (bm[1], bm[2], 0.1), 0.2, 0.15, depth, rw, rh):
            scene.draw_boxes(img, depth, cam3, r3d.bomb_boxes(bm[1], bm[2], bm[0] == "planted", blink), rw, rh)
    # 2.4: dibuja las granadas en vuelo. El snapshot las trae como
    # [type, x, y, z, owner_id]. Usamos r3d.grenade_boxes() para el modelo.
    for g in snap.get("gs", []):
        try:
            gtype, gx, gy, gz, gowner = g
            yaw = 0.0  # el modelo es casi simetrico; no rotamos.
            if scene.visible(cam3, (gx, gy, gz), 0.1, 0.1, depth, rw, rh):
                gboxes = r3d.grenade_boxes(gtype, gx, gy, gz, yaw)
                scene.draw_boxes(img, depth, cam3, gboxes, rw, rh)
        except (IndexError, ValueError, TypeError):
            continue
    rec = state["recoil"]
    wid = WEAPON_ORDER[me[I_WPN]]
    if me[I_ALIVE] and not zoom:
        t9 = state["now"] * 9
        bob = (math.sin(t9) * 0.008, abs(math.cos(t9)) * 0.010) if state["moving"] else (0.0, 0.0)
        scene.draw_fp(img, rw, rh, math.radians(70), wid, me[I_TEAM], rec, bob,
                      math.sin(math.pi * state["rl"]), rec > 0.6)
    # --- Efectos 3D 2.0: particulas y estelas. Se dibujan en el mismo
    # buffer que el mundo para que oclusionen con el z-buffer correcto.
    if state.get("particles") and state["particles"].n > 0:
        state["particles"].draw(img, depth, cam3, rw, rh, fogd=22.0, size_px=2)
    for tr in state.get("tracers", []):
        r3d.draw_tracer(img, depth, cam3,
                        tr["x0"], tr["y0"], tr["z0"],
                        tr["x1"], tr["y1"], tr["z1"],
                        rw, rh, color=(255, 235, 160), fogd=22.0)
    arr = np_.clip(img, 0, 255).astype(np_.uint8)
    surf = pygame.image.frombuffer(arr.tobytes(), (rw, rh), "RGB")
    # Screen-shake: desplaza el blit del mundo y del HUD 2D para dar feedback
    # cinematico en danos y explosiones. El resto de la UI sigue aqui.
    sx = int(state.get("shake_x", 0.0))
    sy = int(state.get("shake_y", 0.0))
    screen.blit(pygame.transform.scale(surf, (w, h)), (sx, sy))

    # ---- 2D: etiquetas, mira, efectos
    for (nm, lx, ly) in labels:
        text(pygame, screen, fonts["s"], nm, (int(lx), int(ly)), (150, 255, 150), True)
    if zoom:
        key = ("scope", w, h)
        if state.get("scope_key") != key:
            ov = pygame.Surface((w, h), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 255))
            pygame.draw.circle(ov, (0, 0, 0, 0), (w // 2, h // 2), min(w, h) // 2 - 16)
            state["scope_key"], state["scope"] = key, ov
        screen.blit(state["scope"], (0, 0))
        pygame.draw.line(screen, (0, 0, 0), (w // 2 - min(w, h) // 2, h // 2), (w // 2 + min(w, h) // 2, h // 2), 1)
        pygame.draw.line(screen, (0, 0, 0), (w // 2, h // 2 - min(w, h) // 2), (w // 2, h // 2 + min(w, h) // 2), 1)
    elif me[I_ALIVE]:
        # Crosshair dinamico: la separacion de las lineas crece con el recoil
        # y el movimiento, igual que en CS 1.6, dando feedback visual de la
        # precision actual sin alterar la mecanica de spread del servidor.
        cx, cy = w // 2, h // 2
        wst_ = WEAPONS[WEAPON_ORDER[me[I_WPN]]]
        spread_vis = wst_["spread"] + wst_["move"] * (1.0 if state["moving"] else 0.0)
        gap = int(5 + 60 * spread_vis + 24 * state["recoil"])
        gap = clamp(gap, 4, 40)
        arm = 10
        ch_col = (80, 255, 80)
        if state["hitmarker"] > 0:
            # Hitmarker: dibuja una X blanca o roja segun si fue headshot.
            xcol = (255, 70, 70) if state["hitmarker_hs"] else (255, 240, 240)
            size = 8
            for sgn in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
                pygame.draw.line(screen, xcol,
                                 (cx + sgn[0] * 3, cy + sgn[1] * 3),
                                 (cx + sgn[0] * (size + 3), cy + sgn[1] * (size + 3)), 2)
            # Hitmarker desplaza levemente el crosshair al color del feedback.
            ch_col = xcol
        for (a, b, c, d) in ((-gap - arm, 0, -gap, 0), (gap, 0, gap + arm, 0),
                             (0, -gap - arm, 0, -gap), (0, gap, 0, gap + arm)):
            pygame.draw.line(screen, ch_col, (cx + a, cy + b), (cx + c, cy + d), 2)
        # Punto central: util para armas de precision (sniper sin zoom).
        pygame.draw.circle(screen, ch_col, (cx, cy), 1)
    if state["flash"] > 0:
        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        ov.fill((255, 0, 0, int(110 * min(1.0, state["flash"]))))
        screen.blit(ov, (0, 0))
    # 2.4: flashbang overlay. Si el jugador esta cegado, dibuja una capa
    # blanca semitransparente que decrece con el tiempo restante.
    flash_t = me[I_FLASH_T] if me and len(me) > I_FLASH_T else 0
    if flash_t > 0:
        # El flash es blanco al inicio y se desvanece. A 3s: alpha=200,
        # a 0s: alpha=0.
        alpha = int(220 * min(1.0, flash_t / 3.0))
        if alpha > 0:
            ov = pygame.Surface((w, h), pygame.SRCALPHA)
            ov.fill((255, 255, 255, alpha))
            screen.blit(ov, (0, 0))

    # --- Indicadores direccionales de dano: arcos rojos en el borde de
    # pantalla que apuntan hacia el enemigo que acabo de danar al jugador.
    # Solo se muestran los ultimos 1.6 segundos y se desvanecen con el tiempo.
    if me[I_ALIVE]:
        cx, cy = w // 2, h // 2
        radius = int(min(w, h) * 0.36)
        for (ang, born, dmg) in state["dmg_dirs"]:
            age = state["now"] - born
            if age > 1.6:
                continue
            alpha = int(220 * (1.0 - age / 1.6))
            # Angulo: 0 = frente, positivo = derecha (sentido horario).
            sa = math.sin(ang)
            ca = math.cos(ang)
            ax = int(cx + ca * radius)
            ay = int(cy + sa * radius)
            ov = pygame.Surface((40, 40), pygame.SRCALPHA)
            pygame.draw.polygon(ov, (255, 60, 60, alpha),
                                [(20, 6), (32, 28), (8, 28)])
            rot = pygame.transform.rotate(ov, -math.degrees(ang))
            rr = rot.get_rect(center=(ax, ay))
            screen.blit(rot, rr)

    # minimapa
    cs = 5
    mmx, mmy = 10, 10
    pygame.draw.rect(screen, (0, 0, 0), (mmx - 2, mmy - 2, W * cs + 4, H * cs + 4))
    for y in range(H):
        for x in range(W):
            v = GRID[y][x]
            if v:
                screen.fill((120, 120, 120) if v == 1 else (130, 90, 50), (mmx + x * cs, mmy + y * cs, cs, cs))
    for k, (x0, y0, x1, y1) in SITES.items():
        pygame.draw.rect(screen, (200, 60, 60), (mmx + x0 * cs, mmy + y0 * cs, (x1 - x0 + 1) * cs, (y1 - y0 + 1) * cs), 1)
        text(pygame, screen, fonts["s"], k, (mmx + (x0 + 2) * cs, mmy + (y0 + 1) * cs), (255, 120, 120), shadow=False)
    for r in snap["pl"]:
        if r[I_ALIVE] and r[I_TEAM] == me[I_TEAM]:
            c = (255, 255, 255) if r[I_ID] == me[I_ID] else TEAM_COL[r[I_TEAM]]
            pygame.draw.circle(screen, c, (int(mmx + r[I_X] * cs), int(mmy + r[I_Y] * cs)), 3)
    # Cono de vision del jugador local sobre el minimapa: util para que el
    # jugador vea hacia donde esta mirando en relacion con el resto del mapa.
    px_mm = int(mmx + px * cs)
    py_mm = int(mmy + py * cs)
    fov_cone = math.radians(70) / 2.0
    for sgn in (-1, 1):
        ex = px + math.cos(pa + sgn * fov_cone) * 4
        ey = py + math.sin(pa + sgn * fov_cone) * 4
        pygame.draw.line(screen, (255, 255, 200, 100),
                         (px_mm, py_mm), (int(mmx + ex * cs), int(mmy + ey * cs)), 1)
    pygame.draw.line(screen, (255, 255, 255), (px_mm, py_mm),
                     (mmx + int((px + math.cos(pa) * 2) * cs),
                      mmy + int((py + math.sin(pa) * 2) * cs)), 1)
    if bm[0] in ("planted", "dropped"):
        bx = int(mmx + bm[1] * cs)
        by = int(mmy + bm[2] * cs)
        # Bomba: pulsa segun el temporizador cuando esta plantada.
        rad = 3 + (2 if (bm[0] == "planted" and int(state["now"] * 4) % 2 == 0) else 0)
        pygame.draw.circle(screen, (255, 40, 40), (bx, by), rad)
        pygame.draw.circle(screen, (255, 180, 180), (bx, by), rad, 1)

    # HUD superior
    ttxt = "%d:%02d" % (int(snap["tm"]) // 60, int(snap["tm"]) % 60)
    if snap["ph"] == "freeze":
        ttxt = "Prepárate %d" % math.ceil(snap["tm"])
    text(pygame, screen, fonts["m"], ttxt, (w // 2, 24), (255, 255, 255), True)
    text(pygame, screen, fonts["m"], "T %d" % snap["sc"][0], (w // 2 - 120, 24), TEAM_COL["T"], True)
    text(pygame, screen, fonts["m"], "CT %d" % snap["sc"][1], (w // 2 + 120, 24), TEAM_COL["C"], True)
    # Nombre del mapa actual: se muestra justo debajo del marcador para que
    # el jugador sepa en que arena esta jugando y pueda planear su compra.
    map_title = snap.get("maptitle") or (MAPS.get(snap.get("map", ""), ACTIVE_MAP).title
                                          if isinstance(snap.get("map"), str) else ACTIVE_MAP.title)
    text(pygame, screen, fonts["s"], "Mapa: %s" % map_title, (w // 2, 48), (180, 200, 240), True)
    if bm[0] == "planted":
        # Indicador de bomba plantada: icono grande + cuenta regresiva en
        # color rojo pulsante cuando quedan menos de 10 segundos.
        sec_left = int(math.ceil(bm[3]))
        col = (255, 70, 70) if sec_left > 10 else (255, 30, 30)
        scale = 1.0 if sec_left > 10 else 1.0 + 0.18 * math.sin(state["now"] * 9)
        bomb_txt = "BOMBA  %d" % sec_left
        # Sombra para dar sensacion de urgencia.
        big = pygame.transform.rotozoom(fonts["m"].render(bomb_txt, True, col), 0, scale)
        big_rect = big.get_rect(center=(w // 2, 72))
        screen.blit(big, big_rect)
    # --- Kill feed enriquecido (2.0): icono de arma, skull en headshot y
    # color del equipo del asesino/victima. Mantiene compatibilidad: si un
    # servidor antiguo no envia 'kf', se cae al feed textual 'fd'.
    kf_entries = snap.get("kf") or []
    if not kf_entries:
        for i, line in enumerate(snap["fd"]):
            text(pygame, screen, fonts["s"], line, (w - 14 - fonts["s"].size(line)[0],
                                                     12 + i * 22), (240, 240, 240))
    else:
        for i, kf in enumerate(kf_entries):
            try:
                kid, kn, kteam, vid, vn, vteam, wpn, hs = kf
            except (TypeError, ValueError):
                continue
            kcol = TEAM_COL.get(kteam, (220, 220, 220))
            vcol = TEAM_COL.get(vteam, (220, 220, 220))
            # Compon: "killer [arma] victim" + icono de HS si procede.
            skull = " [HS]" if hs else ""
            weapon_name = WEAPONS.get(wpn, {}).get("name", wpn)
            label = "%s  [%s]  %s%s" % (kn[:10], weapon_name[:10], vn[:10], skull)
            label_w = fonts["s"].size(label)[0]
            tx = w - 14 - label_w
            ty = 12 + i * 22
            # Fondo semitransparente para legibilidad.
            bg = pygame.Surface((label_w + 14, 20), pygame.SRCALPHA)
            bg.fill((0, 0, 0, 150))
            screen.blit(bg, (tx - 7, ty - 2))
            text(pygame, screen, fonts["s"], kn[:10], (tx, ty), kcol)
            text(pygame, screen, fonts["s"], "[%s]" % weapon_name[:10],
                 (tx + fonts["s"].size(kn[:10])[0] + 6, ty), (255, 220, 120))
            text(pygame, screen, fonts["s"], vn[:10],
                 (tx + fonts["s"].size(kn[:10])[0] + 6 + fonts["s"].size("[%s]" % weapon_name[:10])[0] + 6,
                  ty), vcol)
            if hs:
                text(pygame, screen, fonts["s"], "[HS]",
                     (tx + fonts["s"].size(kn[:10])[0] + 6 + fonts["s"].size("[%s]" % weapon_name[:10])[0] + 6 +
                      fonts["s"].size(vn[:10])[0] + 4, ty), (255, 80, 80))
    # HUD inferior
    hpcol = (255, 80, 80) if me[I_HP] < 30 else (255, 255, 255)
    text(pygame, screen, fonts["l"], "%d" % me[I_HP], (24, h - 76), hpcol)
    wst = WEAPONS[WEAPON_ORDER[me[I_WPN]]]
    am = "Recargando..." if me[I_REL] else "%d / %d" % (me[I_AMMO], wst["mag"])
    text(pygame, screen, fonts["m"], am, (w - 230, h - 50), (255, 255, 255))
    text(pygame, screen, fonts["s"], wst["name"], (w - 230, h - 76), (200, 200, 200))
    # 2.4: muestra granadas en inventario + granada activa.
    he_n = me[I_HE] if len(me) > I_HE else 0
    fl_n = me[I_FLASH] if len(me) > I_FLASH else 0
    sm_n = me[I_SMOKE] if len(me) > I_SMOKE else 0
    cur_gren = me[I_CUR_GREN] if len(me) > I_CUR_GREN else "he"
    if he_n + fl_n + sm_n > 0:
        gren_str = "G [%s]  HE:%d  FB:%d  SM:%d" % (cur_gren.upper(), he_n, fl_n, sm_n)
        # Resalta la granada activa.
        col = (255, 220, 100) if cur_gren == "he" else (200, 200, 200)
        text(pygame, screen, fonts["s"], gren_str, (w - 230, h - 100), col)
    else:
        text(pygame, screen, fonts["s"], "Sin granadas (B para comprar)", (w - 230, h - 100), (160, 100, 100))
    text(pygame, screen, fonts["m"], "$ %d" % me[I_MONEY], (24, h - 118), (120, 230, 120))
    if me[I_ARMOR] > 0:
        text(pygame, screen, fonts["m"], "Chaleco %d" % me[I_ARMOR], (170, h - 52), (170, 200, 255))
    if me[I_KIT]:
        text(pygame, screen, fonts["s"], "Kit de desactivación", (170, h - 76), (150, 220, 255))
    buy_ok = can_buy_now(snap) and me[I_ALIVE]
    if buy_ok and not state["shop"]:
        # 2.2: muestra tambien P para auto-compra si hay loadout previo.
        text(pygame, screen, fonts["s"], "B: abrir tienda", (w // 2, 92), (140, 230, 140), True)
    # mensajes de acción
    here = site_at(px, py)
    if me[I_ALIVE]:
        if me[I_TEAM] == "T" and me[I_BOMB] and bm[0] == "carried":
            text(pygame, screen, fonts["m"],
                 ("Mantén E para plantar la bomba (sitio %s)" % here) if here else "Llevas la bomba: ve al sitio A o B",
                 (w // 2, h - 120), (255, 220, 120), True)
        elif me[I_TEAM] == "C" and bm[0] == "planted" and math.hypot(px - bm[1], py - bm[2]) < 1.3:
            text(pygame, screen, fonts["m"], "Mantén E para desactivar la bomba", (w // 2, h - 120), (120, 220, 255), True)
        if me[I_PROG] > 0:
            total = PLANT_T if me[I_TEAM] == "T" else DEFUSE_T * (0.5 if me[I_KIT] else 1.0)
            bw = 240
            pygame.draw.rect(screen, (0, 0, 0), (w // 2 - bw // 2 - 2, h - 90, bw + 4, 18))
            pygame.draw.rect(screen, (90, 230, 90), (w // 2 - bw // 2, h - 88, int(bw * min(1.0, me[I_PROG] / total)), 14))
    else:
        # 2.2: muestra el nombre del companero observado y como ciclar.
        spec_name = state.get("spec_name", "")
        spec_msg = "Estás muerto — observando a %s    [ / ]: cambiar" % (spec_name or "tu equipo")
        text(pygame, screen, fonts["m"], spec_msg, (w // 2, h - 120), (255, 120, 120), True)
    if snap["msg"] and snap["ph"] in ("over", "wait"):
        text(pygame, screen, fonts["m"], snap["msg"], (w // 2, h // 3), (255, 240, 140), True)

    # --- Overlay de fin de ronda (2.0): muestra el equipo ganador de la
    # ronda + el MVP (jugador con mas kills en el partido). Solo se muestra
    # durante 4 segundos tras el fin de ronda. No altera el resultado ni la
    # economia; es un panel informativo al estilo CS:GO.
    if state.get("round_end_show", 0.0) > 0 and snap["ph"] == "over":
        ov_w, ov_h = 420, 130
        ovx = w // 2 - ov_w // 2
        ovy = h // 3 + 60
        ov = pygame.Surface((ov_w, ov_h), pygame.SRCALPHA)
        ov.fill((8, 10, 18, 220))
        pygame.draw.rect(ov, (255, 200, 80), (0, 0, ov_w, ov_h), 2)
        screen.blit(ov, (ovx, ovy))
        msg = snap.get("msg") or ""
        win_team = "T" if "Terroristas" in msg and "Ganan los Terroristas" in msg else \
                   ("C" if "Antiterroristas" in msg else None)
        if win_team:
            head_col = TEAM_COL[win_team]
            text(pygame, screen, fonts["m"],
                 "RONDA GANADA POR %s" % ("TERRORISTAS" if win_team == "T" else "ANTITERRORISTAS"),
                 (w // 2, ovy + 24), head_col, True)
        # MVP: jugador con mas kills de toda la partida.
        all_players = list(snap["pl"])
        if all_players:
            mvp = max(all_players, key=lambda r: r[I_K])
            mvp_label = "MVP: %s  K:%d  HS:%d" % (mvp[I_NAME][:12], mvp[I_K], mvp[I_HS])
            text(pygame, screen, fonts["m"], mvp_label,
                 (w // 2, ovy + 60), (255, 220, 120), True)
            # Estadisticas resumidas: kills totales de cada equipo.
            tk = sum(r[I_K] for r in all_players if r[I_TEAM] == "T")
            ck = sum(r[I_K] for r in all_players if r[I_TEAM] == "C")
            text(pygame, screen, fonts["s"],
                 "Bajas T:%d  CT:%d  Ronda %d" % (tk, ck, snap["rd"]),
                 (w // 2, ovy + 90), (200, 200, 200), True)
            text(pygame, screen, fonts["s"],
                 "Próxima ronda en %d s" % max(0, int(snap["tm"])),
                 (w // 2, ovy + 108), (170, 200, 230), True)

    # --- FPS counter discreto en esquina superior izquierda del HUD.
    fps_now = state.get("fps_avg", 60.0)
    fps_col = (140, 230, 140) if fps_now >= 50 else (255, 220, 100) if fps_now >= 30 else (255, 100, 100)
    text(pygame, screen, fonts["s"], "%d FPS" % int(fps_now),
         (w - 78, h - 28), fps_col)

    if state["shop"] and buy_ok:
        # 2.6: tienda con 5 categorias. state["shop_cat"] guarda la pagina
        # actual (1-5). Flechas izq/der cambian de categoria.
        shop_cat = state.get("shop_cat", 1)
        items = shop_items_by_category(me[I_TEAM], shop_cat)
        pw, ph_ = 500, 120 + 40 * len(items) + 40
        x0, y0 = w // 2 - pw // 2, h // 2 - ph_ // 2
        ov = pygame.Surface((pw, ph_), pygame.SRCALPHA)
        ov.fill((10, 12, 20, 230))
        screen.blit(ov, (x0, y0))
        pygame.draw.rect(screen, (255, 200, 80), (x0, y0, pw, ph_), 2)
        text(pygame, screen, fonts["m"], "TIENDA     $ %d" % me[I_MONEY], (w // 2, y0 + 30), (255, 220, 120), True)
        # Barra de categorias (1-5).
        cat_y = y0 + 60
        for cat_num, cat_name in SHOP_CATEGORIES.items():
            cat_x = x0 + 20 + (cat_num - 1) * 95
            is_current = (cat_num == shop_cat)
            col = (255, 220, 100) if is_current else (160, 160, 170)
            bg_col = (50, 50, 60) if is_current else (30, 30, 40)
            pygame.draw.rect(screen, bg_col, (cat_x - 5, cat_y - 5, 90, 28), border_radius=4)
            text(pygame, screen, fonts["s"], "%d. %s" % (cat_num, cat_name),
                 (cat_x + 40, cat_y + 8), col, True)
        # Items de la categoria actual.
        for i, (iid, nm, price) in enumerate(items):
            ok = me[I_MONEY] >= price
            col = (130, 235, 130) if ok else (150, 100, 100)
            key_label = str(i + 1) if i < 9 else "0"
            text(pygame, screen, fonts["m"], "%s   %s" % (key_label, nm),
                 (x0 + 30, y0 + 100 + i * 40), col)
            text(pygame, screen, fonts["m"], "$%d" % price,
                 (x0 + pw - 120, y0 + 100 + i * 40), col)
        text(pygame, screen, fonts["s"], "1-9 comprar   ←/→ cambiar categoria   B / Esc: cerrar",
             (w // 2, y0 + ph_ - 22), (170, 170, 180), True)
    if show_score:
        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 170))
        screen.blit(ov, (0, 0))
        text(pygame, screen, fonts["m"], "Marcador   T %d - %d CT" % (snap["sc"][0], snap["sc"][1]),
             (w // 2, 80), (255, 255, 255), True)
        for col, team, label in ((w // 4, "T", "Terroristas"), (3 * w // 4, "C", "Antiterroristas")):
            text(pygame, screen, fonts["m"], label, (col, 130), TEAM_COL[team], True)
            rows = sorted([r for r in snap["pl"] if r[I_TEAM] == team], key=lambda r: -r[I_K])
            for i, r in enumerate(rows):
                c = (255, 255, 120) if r[I_ID] == me[I_ID] else (230, 230, 230)
                if not r[I_ALIVE]:
                    c = (150, 150, 150)
                text(pygame, screen, fonts["s"], "%-14s  K %d  M %d  HS %d" % (r[I_NAME], r[I_K], r[I_D], r[I_HS]),
                     (col - 120, 170 + i * 26), c)


def play(pygame, screen, fonts, clock, sess, snd, scene, gl_renderer=None, skin="classic"):
    # 2.5: detecta Android para usar controles tactiles + aim assist.
    _is_android = False
    touch_ctrl = None
    aim_assist = None
    touch_sensitivity = 0.0028
    try:
        from android_compat import is_android, TouchControls, AimAssist, android_config
        _is_android = is_android()
        if _is_android:
            acfg = android_config()
            touch_sensitivity = acfg.get("sensitivity", 0.0035)
            touch_ctrl = TouchControls(screen.get_width(), screen.get_height())
            aim_assist = AimAssist()
    except ImportError:
        pass

    # En Android no capturamos el raton ni ocultamos el cursor.
    if not _is_android:
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)
        pygame.mouse.get_rel()

    # 2.5: en Android, fuerza div=4 para rendimiento.
    initial_div = 4 if _is_android else 2

    state = {"now": 0.0, "recoil": 0.0, "flash": 0.0, "moving": False, "anim": {}, "scene": scene,
             "div": initial_div, "zoom": False, "shop": False, "rl": 0.0, "auto": not _is_android, "pause_menu": False, "pause_sel": 0, "graphics_menu": False, "quality": "bajo" if _is_android else "medio",
             # --- Estado 2.0: efectos visuales y feedback al jugador.
             "particles": r3d.Particles(768) if r3d else None,
             "tracers": [],          # lista de (x0,y0,z0,x1,y1,z1, born_at, life)
             "hitmarker": 0.0,       # temporizador > 0 muestra el hitmarker
             "hitmarker_hs": False,  # True si el ultimo impacto fue headshot
             "dmg_dirs": [],         # lista de (angulo, t_nacida) para indicador direccional
             "shake": 0.0,           # intensidad del screen-shake (decae con tiempo)
             "shake_x": 0.0, "shake_y": 0.0,
             "fps_avg": 60.0,
             "last_step_t": 0.0,     # controla pasos cuando el jugador se mueve
             "round_end_show": 0.0,  # temporizador del overlay de fin de ronda
             "skin": skin}  # 2.4: skin visual del jugador local
    cmd = {"wq": 0, "w": 2, "bq": 0, "bi": "", "gq": 0, "gt": "he", "gc": 0}
    ft, nframes = 0.03, 0
    view_a = 0.0
    view_p = 0.0
    last_rd = -1
    last_map = None        # detección de cambio de mapa para reconstruir la escena
    hp_prev = 100
    last_ev = None
    bomb_sec = None
    snap = me = None
    while True:
        dt = min(clock.tick(60) / 1000.0, 0.05)
        state["now"] += dt
        ft = ft * 0.93 + (clock.get_time() / 1000.0) * 0.07
        nframes += 1
        # Ajuste dinamico de resolucion: reduce el coste del raycasting antes de que
        # la caida de FPS sea demasiado visible. Nunca cambia la logica del juego.
        if state["auto"] and nframes % 30 == 0 and ft > 0.032 and state["div"] < 4:
            state["div"] += 1
        elif state["auto"] and nframes % 240 == 0 and ft < 0.019 and state["div"] > 2:
            state["div"] -= 1
        # Reconstruccion de la escena 3D cuando se rota de mapa (al terminar
        # una partida o al unirse a un servidor con un mapa distinto). El
        # objeto Scene cachea grid/sites/spawns en numpy, asi que hay que
        # crearlo de nuevo para que el raycasting refleje la nueva arena.
        cur_map = None
        if snap is not None:
            cur_map = snap.get("map")
        if cur_map is not None and cur_map != last_map:
            if cur_map in MAPS:
                set_active_map(cur_map)
                state["scene"] = r3d.Scene(GRID, SITES, SPAWNS, ACTIVE_MAP.theme)
                scene = state["scene"]
                # 2.3: actualiza el grid del GLRenderer cuando cambia el mapa.
                if gl_renderer is not None:
                    try:
                        gl_renderer.update_grid(GRID, theme=ACTIVE_MAP.theme)
                    except Exception:
                        pass
            last_map = cur_map
        slot_now = WEAPONS[WEAPON_ORDER[me[I_WPN]]]["slot"] if me else 2
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return "quit"
            if e.type == pygame.MOUSEWHEEL and me and not state["shop"]:
                cmd["wq"] += 1
                cmd["w"] = 3 - slot_now
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    if state["graphics_menu"]:
                        state["graphics_menu"] = False
                    elif state["shop"]:
                        state["shop"] = False
                    else:
                        state["pause_menu"] = not state["pause_menu"]
                        state["pause_sel"] = 0
                        if isinstance(sess, LocalSession) and sess.server is None:
                            sess.set_paused(state["pause_menu"])
                elif state["graphics_menu"]:
                    if e.key in (pygame.K_UP, pygame.K_DOWN):
                        order = ["bajo", "medio", "alto"]
                        idx = order.index(state["quality"])
                        idx = (idx + (1 if e.key == pygame.K_DOWN else -1)) % 3
                        state["quality"] = order[idx]
                    elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        state["div"] = {"alto": 1, "medio": 2, "bajo": 3}[state["quality"]]
                        state["auto"] = False
                        state["graphics_menu"] = False
                elif state["pause_menu"]:
                    pause_items = ["continuar", "config", "salir"]
                    if e.key == pygame.K_UP:
                        state["pause_sel"] = (state["pause_sel"] - 1) % len(pause_items)
                    elif e.key == pygame.K_DOWN:
                        state["pause_sel"] = (state["pause_sel"] + 1) % len(pause_items)
                    elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        it = pause_items[state["pause_sel"]]
                        if it == "continuar":
                            state["pause_menu"] = False
                            if isinstance(sess, LocalSession) and sess.server is None:
                                sess.set_paused(False)
                        elif it == "config":
                            state["graphics_menu"] = True
                        elif it == "salir":
                            if isinstance(sess, LocalSession) and sess.server is None:
                                sess.set_paused(False)
                            return "menu"

                elif e.key == pygame.K_F11:
                    pygame.display.toggle_fullscreen()
                elif e.key == pygame.K_F2:
                    state["auto"] = False
                    state["div"] = {2: 3, 3: 4, 4: 2}.get(state["div"], 2)
                elif e.key == pygame.K_b:
                    if snap and me and me[I_ALIVE] and can_buy_now(snap):
                        state["shop"] = not state["shop"]
                elif e.key == pygame.K_p:
                    # 2.2: auto-compra con P. Repite el loadout de la ronda
                    # anterior en una sola pulsacion. Solo funciona si se
                    # puede comprar (freeze o primeros 15s de live).
                    if snap and me and me[I_ALIVE] and can_buy_now(snap):
                        cmd["bq"] += 1
                        cmd["bi"] = "auto"
                elif state["shop"] and me:
                    # 2.6: tienda con 5 categorias paginadas.
                    # 1-9: comprar item de la categoria actual.
                    # Flechas izq/der: cambiar de categoria.
                    if e.key in (pygame.K_LEFT, pygame.K_RIGHT):
                        cur_cat = state.get("shop_cat", 1)
                        if e.key == pygame.K_LEFT:
                            cur_cat = max(1, cur_cat - 1)
                        else:
                            cur_cat = min(5, cur_cat + 1)
                        state["shop_cat"] = cur_cat
                    elif pygame.K_1 <= e.key <= pygame.K_9:
                        idx = e.key - pygame.K_1
                        cat = state.get("shop_cat", 1)
                        items = shop_items_by_category(me[I_TEAM], cat)
                        if idx < len(items):
                            cmd["bq"] += 1
                            cmd["bi"] = items[idx][0]
                    elif e.key == pygame.K_0:
                        idx = 9
                        cat = state.get("shop_cat", 1)
                        items = shop_items_by_category(me[I_TEAM], cat)
                        if idx < len(items):
                            cmd["bq"] += 1
                            cmd["bi"] = items[idx][0]
                elif e.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                    cmd["wq"] += 1
                    cmd["w"] = {pygame.K_1: 1, pygame.K_2: 2, pygame.K_3: 3}[e.key]
                elif e.key == pygame.K_q:
                    cmd["wq"] += 1
                    cmd["w"] = {1: 2, 2: 3, 3: 1}.get(slot_now, 2)
                elif e.key == pygame.K_g:
                    # 2.4: cicla entre tipos de granada disponibles.
                    # El servidor responde al contador 'gc' y cambia
                    # p.cur_grenade. El HUD muestra la granada activa.
                    if me and me[I_ALIVE]:
                        cmd["gc"] = cmd.get("gc", 0) + 1
                elif e.key == pygame.K_f:
                    # 2.4: lanza la granada seleccionada.Usa la tecla F
                    # porque el boton derecho del raton ya se usa para zoom
                    # con el AWP. Alternativa: SHIFT+clic tambien lanza.
                    if me and me[I_ALIVE] and not state["shop"] and not paused_local:
                        cmd["gq"] = cmd.get("gq", 0) + 1
                        cmd["gt"] = me[I_CUR_GREN] if len(me) > I_CUR_GREN else "he"
                elif e.key in (pygame.K_LEFTBRACKET, pygame.K_RIGHTBRACKET) and me and not me[I_ALIVE]:
                    # 2.2: ciclo de espectador al morir. [ y ] cambian de
                    # companero vivo a observar. No altera el gameplay, solo
                    # el objetivo de la camara del espectador.
                    if e.key == pygame.K_LEFTBRACKET:
                        state["spec_idx"] = state.get("spec_idx", 0) - 1
                    else:
                        state["spec_idx"] = state.get("spec_idx", 0) + 1
        # 2.5: en Android, procesa eventos touch; en PC, usa mouse.
        if _is_android and touch_ctrl is not None:
            # Procesa eventos touch del frame actual.
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return "quit"
                if e.type == pygame.FINGERDOWN:
                    actions = touch_ctrl.handle_event(e, pygame)
                    if "button_reload" in actions:
                        cmd["rel"] = True
                    if "button_shop" in actions:
                        if snap and me and me[I_ALIVE] and can_buy_now(snap):
                            state["shop"] = not state["shop"]
                    if "button_weapon" in actions:
                        cmd["wq"] += 1
                        cmd["w"] = {1: 2, 2: 3, 3: 1}.get(slot_now, 2)
                    if "button_grenade" in actions:
                        if me and me[I_ALIVE]:
                            cmd["gc"] = cmd.get("gc", 0) + 1
                    if "button_throw" in actions:
                        if me and me[I_ALIVE] and not state["shop"]:
                            cmd["gq"] = cmd.get("gq", 0) + 1
                            cmd["gt"] = me[I_CUR_GREN] if len(me) > I_CUR_GREN else "he"
                    if "button_use" in actions:
                        inp_use = True
                    if "tap_shoot" in actions:
                        touch_firing = True
                elif e.type == pygame.FINGERMOTION:
                    actions = touch_ctrl.handle_event(e, pygame)
                    if "aim_dx" in actions:
                        if not state["pause_menu"]:
                            view_a += actions["aim_dx"] * touch_sensitivity * (0.35 if state["zoom"] else 1.0)
                            view_p = clamp(view_p - actions["aim_dy"] * touch_sensitivity * 0.8,
                                           -1.15, 1.15)
                elif e.type == pygame.FINGERUP:
                    actions = touch_ctrl.handle_event(e, pygame)
                    if "tap_shoot" in actions:
                        touch_firing = True
                    if "button_use" in actions:
                        inp_use = False
                elif e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        if state["shop"]:
                            state["shop"] = False
                        else:
                            state["pause_menu"] = not state["pause_menu"]
                            state["pause_sel"] = 0
            # Obtiene movimiento del joystick virtual.
            jf, js = touch_ctrl.get_movement()
            # En Android: f = forward (joystick Y invertido), s = strafe (joystick X).
            # El joystick Y positivo = abajo en pantalla = atras.
            touch_firing = locals().get("touch_firing", False)
            inp_use = locals().get("inp_use", False)
            paused_local = state["pause_menu"]
            inp = {"f": 0 if paused_local else -jf,  # invertir: arrastrar arriba = adelante
                   "s": 0 if paused_local else js,
                   "a": view_a, "fire": touch_firing and not state["shop"] and not paused_local,
                   "use": inp_use and not paused_local,
                   "rel": False,
                   "sk": state.get("skin", "classic")}
            inp.update(cmd)
            # Aim assist: si esta disparando, corrige view_a hacia el enemigo
            # mas cercano dentro del cono. Solo en Android.
            if aim_assist and snap and me:
                aim_assist.update(view_a, snap, sess.my_id, me[I_TEAM],
                                  inp["fire"], angdiff)
                view_a = aim_assist.update(view_a, snap, sess.my_id, me[I_TEAM],
                                           inp["fire"], angdiff)
                inp["a"] = view_a
        else:
            # --- PC: mouse + keyboard como antes ---
            mx, my = pygame.mouse.get_rel()
            if not state["pause_menu"] and not state["graphics_menu"]:
                view_a += mx * 0.0028 * (0.35 if state["zoom"] else 1.0)
                view_p = clamp(view_p - my * 0.0022 * (0.65 if state["zoom"] else 1.0), -1.15, 1.15)
            k = pygame.key.get_pressed()
            buttons = pygame.mouse.get_pressed()
            paused_local = state["pause_menu"]
            inp = {"f": 0 if paused_local else int(k[pygame.K_w]) - int(k[pygame.K_s]),
                   "s": 0 if paused_local else int(k[pygame.K_d]) - int(k[pygame.K_a]),
                   "a": view_a, "fire": bool(buttons[0]) and not state["shop"] and not paused_local,
                   "use": bool(k[pygame.K_e]) and not paused_local,
                   "rel": bool(k[pygame.K_r]) and not paused_local,
                   # 2.4: skin persistente en el cfg del juego.
                   "sk": state.get("skin", "classic")}
            inp.update(cmd)
        sess.send_input(inp)
        sess.update(dt)
        if sess.lost():
            show_message(pygame, screen, fonts, clock, "Conexión perdida o servidor lleno")
            return "menu"
        snap = sess.snapshot()
        w, h = screen.get_size()
        if snap is None:
            screen.fill((10, 10, 16))
            # 2.6.1: feedback mas claro con timeout y la IP del servidor.
            elapsed = time.time() - getattr(sess, "last_rx", time.time())
            if elapsed > 10:
                # Timeout: el servidor no respondio en 10 segundos.
                show_message(pygame, screen, fonts, clock,
                             "No se pudo conectar.\n\n"
                             "Posibles causas:\n"
                             "  - El servidor no esta activo\n"
                             "  - La IP es incorrecta\n"
                             "  - El firewall bloquea UDP %d\n"
                             "  - No estan en la misma red Wi-Fi\n\n"
                             "Pulsa una tecla para volver al menu." % PORT)
                return "menu"
            text(pygame, screen, fonts["m"], "Conectando a %s:%d..." % (
                getattr(sess, "addr", ("?", 0))[0],
                getattr(sess, "addr", ("?", 0))[1]),
                (w // 2, h // 2 - 20), (200, 200, 200), True)
            text(pygame, screen, fonts["s"], "Esperando respuesta del servidor... (%.0fs)" % elapsed,
                 (w // 2, h // 2 + 20), (150, 150, 150), True)
            pygame.display.flip()
            continue
        me = next((r for r in snap["pl"] if r[I_ID] == sess.my_id), None)
        if me is None:
            screen.fill((10, 10, 16))
            text(pygame, screen, fonts["m"], "Sincronizando...", (w // 2, h // 2), (200, 200, 200), True)
            pygame.display.flip()
            continue
        if snap["rd"] != last_rd:
            last_rd = snap["rd"]
            view_a = 0.0 if me[I_TEAM] == "T" else math.pi
            view_p = 0.0
        if state["shop"] and not (me[I_ALIVE] and can_buy_now(snap)):
            state["shop"] = False
        cam = (me[I_X], me[I_Y], view_a, view_p)
        if not me[I_ALIVE]:
            # 2.2: ciclo de espectador con [ y ]. Elige por indice que companero
            # vivo observar (primero el propio equipo, luego cualquier vivo).
            mates = [r for r in snap["pl"] if r[I_ALIVE] and r[I_TEAM] == me[I_TEAM]] or \
                    [r for r in snap["pl"] if r[I_ALIVE]]
            if mates:
                idx = state.get("spec_idx", 0) % len(mates)
                spec_p = mates[idx]
                cam = (spec_p[I_X], spec_p[I_Y], spec_p[I_A], 0.0)
                # Guarda el nombre del espectado para mostrarlo en el HUD.
                state["spec_name"] = spec_p[I_NAME]
        # eventos de sonido
        evs = snap["ev"]
        if last_ev is None:
            last_ev = max([e[0] for e in evs], default=0)
        for e in evs:
            if e[0] <= last_ev:
                continue
            d = math.hypot(e[2] - cam[0], e[3] - cam[1])
            name = {"s": "shot", "b": "boom", "p": "ok", "d": "ok", "r": "click", "h": "ok",
                    # 2.4: eventos de granada.
                    "gt": "click",  # lanzamiento (sonido de pinza)
                    "ge": "boom",   # explosion HE
                    "gf": "ok",     # flashbang
                    "gs": "click"}.get(e[1])  # humo activado
            if name:
                play_snd(snd, name, d)
            if e[1] == "s" and e[4] == sess.my_id:
                state["recoil"] = 1.0
            # --- Eventos 2.0: particulas, hitmarker y screen-shake.
            et = e[1]
            ex, ey, epid = e[2], e[3], e[4]
            particles = state["particles"]
            if et == "b" and particles:
                # Explosion de la bomba: escombros + humo naranja.
                particles.spawn(ex, ey, 0.4, (255, 160, 60), count=80, speed=4.5,
                                life=1.1, spread=2.5)
                particles.spawn(ex, ey, 0.6, (90, 90, 95), count=40, speed=2.0,
                                life=1.8, spread=2.0)
                state["shake"] = max(state["shake"], 1.0)
                # Pequeno retardo para que el screen-shake coincida con el sonido.
            elif et == "w" and particles:
                # Impacto en pared: chispas + polvo.
                particles.spawn(ex, ey, 0.55, (230, 200, 130), count=10, speed=2.6,
                                life=0.32, spread=1.0)
                particles.spawn(ex, ey, 0.30, (140, 130, 120), count=5, speed=0.9,
                                life=0.55, spread=1.0)
                # Estela corta del disparo: orig en shooter, fin en pared.
                if epid == sess.my_id:
                    # Origen del disparo local: boca del arma en primera persona.
                    r3d.draw_tracer = r3d.draw_tracer  # noop; el tracer se dibuja en render
            elif et == "i" and particles:
                # Impacto en jugador: chispas rojas (sangre).
                particles.spawn(ex, ey, 0.90, (200, 30, 30), count=14, speed=2.2,
                                life=0.45, spread=1.4)
                particles.spawn(ex, ey, 1.05, (255, 120, 60), count=6, speed=1.5,
                                life=0.30, spread=1.2)
                # Si el impacto lo provoco el jugador local -> hitmarker.
                if epid == sess.my_id:
                    state["hitmarker"] = 0.45
                    play_snd(snd, "hit", min(d, 12.0))
                    # Si el evento tambien fue headshot (tipo 'h') se marca con HS.
            if et == "h" and particles:
                # Headshot: burst dorado + sonido agudo.
                particles.spawn(ex, ey, 1.05, (255, 220, 80), count=18, speed=3.0,
                                life=0.55, spread=1.5)
                if epid == sess.my_id:
                    state["hitmarker"] = 0.55
                    state["hitmarker_hs"] = True
                    play_snd(snd, "hs", min(d, 12.0))
                    # 2.2: registra el headshot en las stats persistentes.
                    try:
                        add_headshot_to_stats()
                    except Exception:
                        pass
            elif et == "i":
                state["hitmarker_hs"] = False
            # --- 2.4: partículas de eventos de granada.
            elif et == "ge" and particles:
                # Explosion HE: burst naranja + escombros grises.
                particles.spawn(ex, ey, 0.4, (255, 130, 30), count=50, speed=5.0,
                                life=0.6, spread=2.5)
                particles.spawn(ex, ey, 0.6, (90, 90, 95), count=30, speed=2.5,
                                life=1.2, spread=2.0)
                state["shake"] = max(state["shake"], 0.7)
            elif et == "gf" and particles:
                # Flashbang: burst blanco.
                particles.spawn(ex, ey, 1.0, (255, 255, 255), count=25, speed=3.0,
                                life=0.4, spread=1.5)
            elif et == "gs" and particles:
                # Humo activado: burst gris que se dispersa.
                particles.spawn(ex, ey, 0.4, (200, 200, 200), count=40, speed=2.0,
                                life=0.8, spread=2.0)
        if evs:
            last_ev = max(last_ev, evs[-1][0])
        # 2.2: registra bajas y muertes del jugador local consultando el
        # kill feed estructurado. La comparacion con kf_prev nos dice que
        # entradas son nuevas desde el frame anterior.
        if not hasattr(state, "_kf_seen_ids"):
            state["_kf_seen_ids"] = set()
        for kf in snap.get("kf", []):
            try:
                # kf = [killer_id, kn, kteam, victim_id, vn, vteam, weapon, hs]
                kid = kf[0]
                vid = kf[3]
                hs = kf[7]
                # Idempotencia: solo cuenta una vez por entrada.
                key = (kid, vid, snap["rd"])
                if key in state["_kf_seen_ids"]:
                    continue
                state["_kf_seen_ids"].add(key)
                # Solo cuenta lo que le pasa al jugador local.
                if kid == sess.my_id:
                    try:
                        add_kill_to_stats()
                    except Exception:
                        pass
                if vid == sess.my_id:
                    try:
                        add_death_to_stats()
                    except Exception:
                        pass
            except (IndexError, TypeError):
                continue
        if me[I_HP] < hp_prev and me[I_ALIVE]:
            state["flash"] = 1.0
            state["shake"] = max(state["shake"], 0.45)
            play_snd(snd, "hurt")
            # Indicador direccional: busca el enemigo vivo mas cercano y registra
            # su angulo relativo a la vista del jugador local.
            dmg_taken = hp_prev - me[I_HP]
            # Prioriza al enemigo mas cercano con angulo plausible (< 30 grados).
            best_enemy = None
            best_d = 999.0
            for r in snap["pl"]:
                if r[I_TEAM] == me[I_TEAM] or not r[I_ALIVE] or r[I_ID] == me[I_ID]:
                    continue
                dd = math.hypot(r[I_X] - me[I_X], r[I_Y] - me[I_Y])
                if dd < best_d:
                    best_d = dd
                    best_enemy = r
            if best_enemy is not None:
                ang = math.atan2(best_enemy[I_Y] - me[I_Y], best_enemy[I_X] - me[I_X]) - view_a
                # Normaliza a [-pi, pi].
                ang = (ang + math.pi) % (2 * math.pi) - math.pi
                state["dmg_dirs"].append((ang, state["now"], dmg_taken))
                state["dmg_dirs"] = state["dmg_dirs"][-6:]
        hp_prev = me[I_HP]
        bm = snap["bm"]
        if bm[0] == "planted":
            sec = int(bm[3])
            if sec != bomb_sec:
                bomb_sec = sec
                play_snd(snd, "beep")
        else:
            bomb_sec = None
        for r in snap["pl"]:
            an = state["anim"].setdefault(r[I_ID], {"x": r[I_X], "y": r[I_Y], "mv": -9.0, "ph": 0.0})
            if abs(r[I_X] - an["x"]) + abs(r[I_Y] - an["y"]) > 0.005:
                an["mv"] = state["now"]
                an["x"], an["y"] = r[I_X], r[I_Y]
            if state["now"] - an["mv"] < 0.25:
                an["ph"] += dt * 9.0
        wst = WEAPONS[WEAPON_ORDER[me[I_WPN]]]
        state["rl"] = min(1.0, state["rl"] + dt / wst["reload"]) if me[I_REL] else 0.0
        state["zoom"] = bool(buttons[2]) and WEAPON_ORDER[me[I_WPN]] == "awp" and bool(me[I_ALIVE]) and not state["shop"]
        state["recoil"] = max(0.0, state["recoil"] - dt * 8)
        state["flash"] = max(0.0, state["flash"] - dt * 2.5)
        state["moving"] = bool(inp["f"] or inp["s"]) and bool(me[I_ALIVE])
        # --- Actualizacion de efectos 2.0: particulas, hitmarker, shake.
        if state["particles"]:
            state["particles"].update(dt)
        state["hitmarker"] = max(0.0, state["hitmarker"] - dt)
        # Decaimiento del screen-shake: amplitud exponencial, offset aleatorio.
        if state["shake"] > 0:
            decay = math.exp(-dt * 6.0)
            state["shake"] *= decay
            amp = state["shake"] * 8.0
            state["shake_x"] = random.uniform(-amp, amp)
            state["shake_y"] = random.uniform(-amp, amp)
            if state["shake"] < 0.02:
                state["shake"] = 0.0
                state["shake_x"] = state["shake_y"] = 0.0
        else:
            state["shake_x"] = state["shake_y"] = 0.0
        # Limpieza de indicadores de dano expirados.
        state["dmg_dirs"] = [(a, t, d) for (a, t, d) in state["dmg_dirs"]
                             if state["now"] - t < 1.6]
        # Pasos: cuando el jugador se mueve por el suelo, reproduce paso cada ~0.32 s.
        if state["moving"] and me[I_ALIVE] and state["now"] - state["last_step_t"] > 0.32:
            state["last_step_t"] = state["now"]
            play_snd(snd, "step", 1.0)
        # Tracers del jugador local: cuando el recoil sube (= disparo propio),
        # generamos una estela desde la boca del arma hacia el centro de pantalla.
        # El render 3D la dibujara despues con z-test.
        if state["recoil"] > 0.92 and me[I_ALIVE]:
            # Solo una estela por disparo (cuando recoil sube a tope).
            state["tracers"].append({
                "x0": me[I_X] + math.cos(view_a) * 0.45,
                "y0": me[I_Y] + math.sin(view_a) * 0.45,
                "z0": 0.95,
                "x1": me[I_X] + math.cos(view_a) * 28.0,
                "y1": me[I_Y] + math.sin(view_a) * 28.0,
                "z1": 0.95 + math.sin(view_p) * 6.0,
                "born": state["now"],
                "life": 0.06})
            state["tracers"] = state["tracers"][-6:]
        # Caduca los tracers viejos.
        state["tracers"] = [t for t in state["tracers"]
                            if state["now"] - t["born"] < t["life"]]
        # Round-end overlay: lo mostramos 4 segundos cuando la fase cambia a "over".
        if snap["ph"] == "over":
            # 2.2: registra en stats la ronda ganada/perdida del jugador local
            # solo en el momento en que la fase cambia a "over" (no cada frame).
            if not state.get("round_counted_for_rd", -1) == snap["rd"]:
                state["round_counted_for_rd"] = snap["rd"]
                msg = snap.get("msg", "")
                my_team = me[I_TEAM]
                won = (my_team == "T" and "Ganan los Terroristas" in msg) or \
                      (my_team == "C" and "Ganan los Antiterroristas" in msg)
                try:
                    add_round_to_stats(won)
                except Exception:
                    pass
                # Si la partida termino (timer >= WIN_ROUNDS), registra match.
                if snap["sc"][0] >= WIN_ROUNDS or snap["sc"][1] >= WIN_ROUNDS:
                    try:
                        match_won = (my_team == "T" and snap["sc"][0] > snap["sc"][1]) or \
                                    (my_team == "C" and snap["sc"][1] > snap["sc"][0])
                        add_match_to_stats(match_won)
                    except Exception:
                        pass
            state["round_end_show"] = 4.0
        else:
            state["round_end_show"] = max(0.0, state["round_end_show"] - dt)
        # FPS suavizado para mostrar en HUD.
        state["fps_avg"] = state["fps_avg"] * 0.92 + (1.0 / max(dt, 1e-3)) * 0.08
        # 2.3: en modo GPU, render() escribe sobre una Surface de software
        # 'render_target' (que se crea la primera vez). Despues la subimos a
        # GL con present_gl_frame y hacemos flip. En modo CPU, render()
        # escribe directamente sobre 'screen' (que es una Surface de pygame
        # normal) y flip basta.
        if gl_renderer is not None:
            soft_key = ("rt", w, h)
            if state.get("rt_key") != soft_key:
                state["render_target"] = pygame.Surface((w, h))
                state["rt_key"] = soft_key
            render(pygame, state["render_target"], fonts, snap, me, cam, state,
                   bool(k[pygame.K_TAB]), gl_renderer=gl_renderer)
        else:
            render(pygame, screen, fonts, snap, me, cam, state, bool(k[pygame.K_TAB]),
                   gl_renderer=gl_renderer)
        # 2.3: en modo GPU, los overlays (pausa, configuracion) se dibujan
        # sobre el mismo render_target que el resto del HUD. En modo CPU,
        # sobre 'screen' directamente.
        overlay_target = state.get("render_target") if gl_renderer is not None else screen
        if overlay_target is None:
            overlay_target = screen
        if state["pause_menu"]:
            ov = pygame.Surface((w, h), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 185))
            overlay_target.blit(ov, (0, 0))
            text(pygame, overlay_target, fonts["l"], "PAUSA", (w // 2, h // 2 - 70), (255, 220, 100), True)
            if isinstance(sess, LocalSession) and sess.server is None:
                text(pygame, overlay_target, fonts["m"], "La partida está pausada para todos", (w // 2, h // 2), (235, 235, 235), True)
            else:
                text(pygame, overlay_target, fonts["m"], "Pausa solo local — la partida LAN continúa", (w // 2, h // 2), (235, 235, 235), True)
            pause_items = [("CONTINUAR", False), ("CONFIGURACION DE GRAFICOS", False), ("SALIR DE LA PARTIDA", False)]
            for i, (label, _) in enumerate(pause_items):
                col = (255, 220, 100) if i == state["pause_sel"] else (220, 220, 220)
                text(pygame, overlay_target, fonts["m"], label, (w // 2, h // 2 + 65 + i * 48), col, True)
            text(pygame, overlay_target, fonts["s"], "↑/↓ seleccionar   Enter aceptar   Esc volver", (w // 2, h - 35), (180, 180, 180), True)
        if state["graphics_menu"]:
            ov = pygame.Surface((w, h), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 220))
            overlay_target.blit(ov, (0, 0))
            text(pygame, overlay_target, fonts["l"], "CONFIGURACION", (w // 2, h // 2 - 120), (255, 220, 100), True)
            text(pygame, overlay_target, fonts["m"], "Calidad de graficos", (w // 2, h // 2 - 50), (235, 235, 235), True)
            vals = ["bajo", "medio", "alto"]
            for i, q in enumerate(vals):
                col = (255, 220, 100) if q == state["quality"] else (180, 180, 180)
                text(pygame, overlay_target, fonts["m"], q.upper(), (w // 2, h // 2 + i * 42), col, True)
            text(pygame, overlay_target, fonts["s"], "↑/↓ cambiar   Enter aplicar   Esc volver", (w // 2, h - 35), (180, 180, 180), True)
        # 2.3: en modo GPU, subimos la Surface final a GL y hacemos flip.
        # En modo software normal, pygame.display.flip() basta.
        if gl_renderer is not None:
            ok = present_gl_frame(state["render_target"], state.setdefault("_gl_present", {}))
            if not ok:
                # Si la presentacion GL falla, desactiva el renderer para
                # los siguientes frames y usa el modo CPU a partir de ahora.
                gl_renderer = None
                state["_gl_present"] = None
        # 2.5: en Android, dibuja los controles tactiles sobre la pantalla.
        if _is_android and touch_ctrl is not None and not state["pause_menu"]:
            touch_ctrl.draw(screen, pygame)
        pygame.display.flip()


def main():
    ap = argparse.ArgumentParser(description="Defusa FPS - shooter estilo CS 1.6 con LAN y modo bomba")
    ap.add_argument("--server", action="store_true", help="ejecutar solo el servidor (sin gráficos)")
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--bots", type=int, default=4, help="bots por equipo en modo servidor (0-5)")
    ap.add_argument("--name", default="Servidor Defusa")
    ap.add_argument("--map", default=MAP_ORDER[0],
                    help="mapa inicial (%s); tras cada partida se rota al siguiente" % " ".join(MAP_ORDER))
    ap.add_argument("--version", action="version", version=VERSION)
    ap.add_argument("--no-update", action="store_true", help="no comprobar actualizaciones de GitHub")
    # 2.2: helpers de actualizacion e informacion.
    ap.add_argument("--check-updates", action="store_true",
                    help="comprueba si hay actualizaciones y sale (no instala)")
    ap.add_argument("--install-update", metavar="PATH",
                    help="instala el .deb indicado (pide permisos)")
    ap.add_argument("--list-maps", action="store_true",
                    help="lista los mapas disponibles y sale")
    ap.add_argument("--list-weapons", action="store_true",
                    help="lista las armas disponibles y sale")
    # 2.3: modo GPU. Si se pasa, el juego arranca con OpenGL y usa la GPU
    # para el render del mundo. Si OpenGL no esta disponible, cae a CPU.
    ap.add_argument("--gl", action="store_true",
                    help="usar OpenGL para el render (GPU). Mas rapido en graficos altos.")
    # 2.4: helpers para servidor dedicado.
    ap.add_argument("--public-ip", metavar="IP",
                    help="IP publica del servidor (para mostrar cuando hay port-forwarding)")
    ap.add_argument("--gen-systemd", action="store_true",
                    help="genera un archivo .service de systemd para el servidor dedicado y sale")
    args = ap.parse_args()

    # Modos de un solo comando: responden y salen sin tocar el updater.
    if args.list_maps:
        for name in MAP_ORDER:
            m = MAPS[name]
            print("%-12s  %-18s  theme=%s  sites=%s" % (name, m.title, m.theme,
                                                          ", ".join(sorted(m.sites.keys()))))
        return
    if args.list_weapons:
        # Agrupa por slot para que sea legible.
        for slot in (2, 1, 3):
            label = {2: "Pistolas", 1: "Primarias", 3: "Cuerpo a cuerpo"}[slot]
            print("== %s ==" % label)
            for wname in WEAPON_ORDER:
                w = WEAPONS[wname]
                if w["slot"] != slot:
                    continue
                team = w["team"] or "ambos"
                pellets = w.get("pellets", 1)
                print("  %-10s  %-22s  $%-5d  dmg=%d%s  cd=%.2fs  team=%s" % (
                    wname, w["name"], w["price"], w["dmg"],
                    " x%d" % pellets if pellets > 1 else "", w["cd"], team))
        return
    if args.check_updates:
        info = update_available_info()
        if info is None:
            print("No hay actualizaciones. Version actual: %s" % VERSION)
        else:
            print("Actualizacion disponible: %s" % info[0])
            print("  Origen: %s" % info[1])
            # Mira donde estan los directorios locales de actualizaciones.
            print("  Directorios locales donde dejar un .deb:")
            for d in LOCAL_UPDATE_DIRS:
                print("    - %s" % d)
        return
    if args.install_update:
        path = os.path.abspath(args.install_update)
        if not os.path.exists(path):
            sys.exit("No existe: %s" % path)
        ok = _install_deb(path)
        if ok:
            print("Instalado correctamente.")
        else:
            sys.exit("No se pudo instalar. Intenta manualmente:\n  sudo apt-get install -y %s" % path)
        return

    args.bots = clamp(args.bots, 0, 5)
    if args.map not in MAPS:
        args.map = MAP_ORDER[0]
    # 2.2: el actualizador ahora es mas robusto. Sigue siendo opcional con
    # --no-update. Si hay una actualizacion local disponible, la instala sin
    # necesidad de red; si solo hay en GitHub, la descarga y pide permiso.
    # 2.5: en Android, saltar el auto-update. No se puede hacer os.execv
    # en Pydroid 3 (no se puede reemplazar el proceso Python en marcha).
    if not args.no_update and not _IS_ANDROID:
        try:
            if check_for_updates(silent=True):
                # Reinicia el proceso para que el nuevo codigo tome el control.
                os.execv(sys.executable, [sys.executable, os.path.abspath(__file__)]
                         + [a for a in sys.argv[1:] if a != "--no-update"])
        except Exception:
            # Nunca dejamos que el updater rompa el arranque del juego.
            pass
    if args.server or args.gen_systemd:
        run_dedicated(args)
    else:
        run_gui(args)


if __name__ == "__main__":
    # 2.5: en Android, captura cualquier crash y lo guarda en un log
    # para que el usuario pueda ver que paso.
    try:
        main()
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        # Escribe el error a un archivo de log.
        try:
            log_path = os.path.join(_config_dir(), "crash.log")
            with open(log_path, "w", encoding="utf-8") as f:
                f.write("Defusa FPS v%s crash:\n" % VERSION)
                f.write(tb)
            # En Android, mostrar el error en stderr para que Pydroid lo vea.
            sys.stderr.write(tb)
            sys.stderr.write("\nLog guardado en: %s\n" % log_path)
        except Exception:
            sys.stderr.write(tb)
        sys.exit(1)
