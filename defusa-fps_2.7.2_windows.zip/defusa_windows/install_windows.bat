@echo off
chcp 65001 >nul 2>&1
title Defusa FPS - Instalador para Windows

echo ============================================================
echo   Defusa FPS - Instalador para Windows
echo ============================================================
echo.

REM Verifica si Python esta instalado.
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no esta instalado en esta PC.
    echo.
    echo Necesitas instalar Python 3.10 o superior desde:
    echo   https://www.python.org/downloads/
    echo.
    echo Durante la instalacion, marca la casilla:
    echo   "Add Python to PATH"
    echo.
    echo Despues vuelve a ejecutar este instalador.
    echo.
    pause
    exit /b 1
)

echo [OK] Python detectado:
python --version
echo.

REM Instala las dependencias de Python.
echo ============================================================
echo   Instalando dependencias...
echo ============================================================
echo.
pip install pygame-ce numpy PyOpenGL PyOpenGL_accelerate pyinstaller
if errorlevel 1 (
    echo.
    echo [ERROR] No se pudieron instalar las dependencias.
    echo Asegurate de tener conexion a internet.
    pause
    exit /b 1
)
echo.
echo [OK] Dependencias instaladas.
echo.

REM Verifica que los archivos del juego existen.
if not exist "defusa.py" (
    echo [ERROR] No se encontro defusa.py en el directorio actual.
    echo Asegurate de ejecutar este instalador desde la carpeta del juego.
    pause
    exit /b 1
)
if not exist "r3d.py" (
    echo [ERROR] No se encontro r3d.py en el directorio actual.
    pause
    exit /b 1
)
if not exist "glrenderer.py" (
    echo [ADVERTENCIA] No se encontro glrenderer.py. El modo GPU no estara disponible.
    echo El juego funcionara en modo CPU.
)

REM Compila el .exe con PyInstaller.
echo ============================================================
echo   Creando ejecutable DefusaFPS.exe...
echo ============================================================
echo.
python build_exe.py
if errorlevel 1 (
    echo.
    echo [ERROR] No se pudo crear el ejecutable.
    echo Puedes jugar directamente con: python defusa.py
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   INSTALACION COMPLETA!
echo ============================================================
echo.
echo El ejecutable esta en: dist\DefusaFPS.exe
echo.
echo Puedes:
echo   1. Hacer doble clic en dist\DefusaFPS.exe para jugar
echo   2. Copiar dist\DefusaFPS.exe a cualquier carpeta
echo   3. Enviarselo a tus amigos (no necesitan instalar nada)
echo.
echo Para jugar en red LAN con amigos:
echo   - Uno crea un servidor (menu > Servidor dedicado)
echo   - Los demas se unen (menu > Unirse a partida LAN)
echo   - Todos deben estar en la misma red Wi-Fi
echo.
pause
