# -*- coding: utf-8 -*-
"""Script de build para crear un .exe standalone de Defusa FPS en Windows.

Uso en Windows (con Python 3.10+ instalado):
    pip install pyinstaller pygame-ce numpy PyOpenGL PyOpenGL_accelerate
    python build_exe.py

El resultado es una carpeta dist/DefusaFPS/ con:
    - defusa.exe (ejecutable standalone)
    - r3d.py, glrenderer.py (modulos)
    - Todas las dependencias de Python empaquetadas
    - iconos y assets

Despues puedes comprimir esa carpeta en un .zip y distribuirlo.
No necesita Python instalado en la PC del usuario final.
"""
import os
import sys
import shutil
import subprocess

# Directorio base: donde esta este script.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DIST_DIR = os.path.join(BASE_DIR, "dist")
BUILD_DIR = os.path.join(BASE_DIR, "build")
APP_NAME = "DefusaFPS"

def main():
    # Verifica que PyInstaller este instalado.
    try:
        import PyInstaller
    except ImportError:
        print("PyInstaller no esta instalado.")
        print("Instala con: pip install pyinstaller")
        sys.exit(1)

    # Limpia builds anteriores.
    for d in (DIST_DIR, BUILD_DIR):
        if os.path.exists(d):
            shutil.rmtree(d)

    # Argumentos para PyInstaller.
    # --onefile: crea un solo .exe (mas lento al arrancar pero mas facil
    #   de distribuir). Cambiar a --onedir si prefieres una carpeta.
    # --name: nombre del ejecutable.
    # --windowed: no muestra consola (modo grafico). Quitar si quieres
    #   ver mensajes de stderr.
    # --add-data: incluye r3d.py y glrenderer.py como datos.
    args = [
        "--onefile",
        "--windowed",
        "--name", APP_NAME,
        "--add-data", "r3d.py;.",
        "--add-data", "glrenderer.py;.",
        "--icon", "NONE",  # sin icono por ahora
        # Oculta warnings de importacion.
        "--log-level", "WARN",
        # El script principal.
        os.path.join(BASE_DIR, "defusa.py"),
    ]

    # En Linux, el separador de --add-data es ':' en vez de ';'.
    if sys.platform != "win32":
        args = [a.replace(";", ":") if "--add-data" in a else a for a in args]
        # En Linux no podemos usar --windowed (es para Windows).
        args = [a for a in args if a != "--windowed"]

    print("Ejecutando PyInstaller...")
    print("  Comando: pyinstaller", " ".join(args))
    print()

    # Llama a PyInstaller via modulo.
    import PyInstaller.__main__ as pyi
    pyi.run(args)

    # Verifica que el .exe se creo.
    if sys.platform == "win32":
        exe_path = os.path.join(DIST_DIR, APP_NAME + ".exe")
    else:
        exe_path = os.path.join(DIST_DIR, APP_NAME)
    if os.path.exists(exe_path):
        print()
        print("BUILD EXITOSO!")
        print("  Ejecutable:", exe_path)
        print("  Tamano: %.1f MB" % (os.path.getsize(exe_path) / 1024 / 1024))
        print()
        print("Para distribuir:")
        print("  1. Copia el archivo a la PC del usuario")
        print("  2. El usuario hace doble clic para jugar")
        print("  3. No necesita Python ni dependencias instaladas")
    else:
        print()
        print("ERROR: no se encontro el ejecutable en", exe_path)
        sys.exit(1)


if __name__ == "__main__":
    main()
