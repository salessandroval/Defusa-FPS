# -*- coding: utf-8 -*-
"""Renderizador hibrido OpenGL + numpy para Defusa FPS 2.3.

Filosofia:
- El mundo (paredes, suelo, techo con sus texturas procedurales y niebla) se
  dibuja con un fragment shader GLSL que corre en la GPU. Eso elimina el 70%
  del coste por frame que antes se iba en _floor/_brick/_ceil en numpy.
- Los personajes, props y el arma en primera persona siguen dibujandose en
  CPU con numpy y draw_boxes, despues se compositan encima.

El renderer expone:
  GLRenderer  - clase principal, con init/render/resize/close
  is_available() - dice si OpenGL + PyOpenGL + shaders compilan

Si algo falla (sin GPU, sin PyOpenGL, shaders no compilan), el juego cae
al renderer numpy original sin tocar el codigo del cliente.
"""
import math
import os

import numpy as np

# Imports perezosos: si PyOpenGL no esta instalado, is_available() devuelve
# False y el juego sigue funcionando con el motor numpy.
_OPENGL_OK = None
_GL = None


def _try_import_opengl():
    global _GL
    if _GL is not None:
        return _GL
    try:
        import OpenGL.GL as gl
        from OpenGL.GL import (glGenTextures, glBindTexture, glTexImage2D,
                                glTexParameteri, GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
                                GL_TEXTURE_MIN_FILTER, GL_NEAREST,
                                GL_TEXTURE_WRAP_S, GL_TEXTURE_WRAP_T, GL_REPEAT,
                                GL_RED, GL_R8I, GL_BYTE, GL_RGB, GL_UNSIGNED_BYTE,
                                GL_NEAREST, glFlush, glFinish)
        _GL = gl
        return gl
    except Exception:
        return None


def is_available():
    """Comprueba una sola vez si OpenGL + PyOpenGL + GLSL funcionan."""
    global _OPENGL_OK
    if _OPENGL_OK is not None:
        return _OPENGL_OK
    _OPENGL_OK = False
    gl = _try_import_opengl()
    if gl is None:
        return False
    try:
        import pygame
        # Reusa el display actual si existe; si no, crea uno temporal para
        # probar que el driver de video soporta OPENGL.
        # Solo comprobamos que el modulo carga y que las constantes basicas
        # existen: la prueba real se hace en runtime al construir el contexto.
        # Si pygame.OPENGL falla al crear el display, GLRenderer.init() se
        # encarga de lanzar y el llamador cae al fallback CPU.
        _OPENGL_OK = True
    except Exception:
        return False
    return _OPENGL_OK


# ============================================================ shaders GLSL
# ============================================================ shaders GLSL 1.20
# 2.6.1: reescritos a #version 120 para maxima compatibilidad.
# GLSL 1.20 funciona en OpenGL 2.1 (Intel HD, AMD viejas, Mali, Adreno).
# Usa attribute/varying en vez de in/out, y gl_FragColor en vez de out.
# Ademas usa un VBO real en vez de gl_VertexID (que no existe en 1.20).

_VERT_SRC = """#version 120
attribute vec2 a_pos;
attribute vec2 a_uv;
varying vec2 v_uv;
void main() {
    v_uv = a_uv;
    gl_Position = vec4(a_pos, 0.0, 1.0);
}
"""

_FRAG_SRC = """#version 120
varying vec2 v_uv;

uniform sampler2D u_map;
uniform vec2 u_map_size;
uniform vec2 u_player;
uniform float u_yaw;
uniform float u_pitch;
uniform float u_fov;
uniform vec2 u_resolution;
uniform int u_theme;

const float HW = 1.6;
const float EYE = 0.95;
const float NEAR = 0.04;
const float MAXD = 60.0;

float _hash(float a, float b) {
    return fract(abs(sin(a * 12.9898 + b * 78.233) * 43758.5453));
}

int cell_at(int x, int y) {
    if (x < 0 || y < 0 || x >= int(u_map_size.x) || y >= int(u_map_size.y)) return 1;
    vec2 uv = (vec2(float(x), float(y)) + 0.5) / u_map_size;
    float v = texture2D(u_map, uv).r;
    return int(v * 255.0 + 0.5);
}

vec3 brick_tex(float wx, float zw) {
    float rowf = zw / 0.22;
    float row = floor(rowf);
    float bx = (wx + mod(row, 2.0) * 0.275) / 0.55;
    float bi = floor(bx);
    float fb = bx - bi;
    float fr = rowf - row;
    bool mortar = (fb < 0.05) || (fr < 0.10);
    float h = _hash(bi, row);
    vec3 col = vec3(176.0, 150.0, 118.0) * (0.80 + 0.27 * h);
    bool bevel = (fb < 0.075) || (fr < 0.14) || (fb > 0.94);
    if (bevel && !mortar) col *= 0.88;
    if (mortar) col = vec3(105.0, 99.0, 92.0);
    if (zw < 0.12) col *= 0.72;
    if (zw > HW - 0.10) col *= 0.80;
    return col;
}

vec3 material_tex(float wx, float zw, int val, int theme) {
    vec3 a, b, c;
    if (theme == 0) { a = vec3(176.0,150.0,118.0); b = vec3(150.0,118.0,78.0); c = vec3(105.0,99.0,92.0); }
    else if (theme == 1) { a = vec3(126.0,142.0,112.0); b = vec3(96.0,108.0,82.0); c = vec3(72.0,78.0,66.0); }
    else if (theme == 2) { a = vec3(92.0,108.0,116.0); b = vec3(70.0,78.0,84.0); c = vec3(48.0,56.0,62.0); }
    else if (theme == 3) { a = vec3(156.0,118.0,92.0); b = vec3(132.0,92.0,70.0); c = vec3(92.0,78.0,70.0); }
    else if (theme == 4) { a = vec3(186.0,166.0,142.0); b = vec3(150.0,126.0,104.0); c = vec3(108.0,98.0,88.0); }
    else if (theme == 5) { a = vec3(110.0,120.0,128.0); b = vec3(82.0,92.0,100.0); c = vec3(58.0,66.0,72.0); }
    else if (theme == 6) { a = vec3(104.0,108.0,112.0); b = vec3(78.0,82.0,86.0); c = vec3(52.0,56.0,60.0); }
    else if (theme == 7) { a = vec3(86.0,92.0,98.0); b = vec3(62.0,68.0,74.0); c = vec3(42.0,46.0,50.0); }
    else if (theme == 8) { a = vec3(195.0,210.0,222.0); b = vec3(150.0,168.0,185.0); c = vec3(110.0,130.0,148.0); }
    else if (theme == 9) { a = vec3(138.0,134.0,128.0); b = vec3(110.0,104.0,96.0); c = vec3(78.0,72.0,68.0); }
    else { a = vec3(138.0,134.0,128.0); b = vec3(110.0,104.0,96.0); c = vec3(78.0,72.0,68.0); }

    float rowf = zw / 0.24;
    float row = floor(rowf);
    float u = wx / 0.72 + mod(row, 2.0) * 0.35;
    float fu = u - floor(u);
    float fr = rowf - row;
    bool seam = (fu < 0.045) || (fr < 0.09);
    float h = _hash(floor(u), row);
    vec3 base = a * (0.82 + 0.25 * h);
    if (seam) base = c;
    if (val >= 3) {
        if (val == 3) {
            bool stripe = mod(wx * 6.0, 1.0) < 0.08;
            if (stripe) base = b;
        } else if (val == 4) {
            bool warning = mod(wx * 5.0 + zw * 2.0, 1.0) < 0.16;
            if (warning) base = vec3(220.0, 150.0, 35.0);
        } else {
            base = b;
        }
    }
    if (theme == 8) {
        if (_hash(floor(wx * 3.0), floor(zw * 3.0)) > 0.78) {
            base = base * 0.4 + vec3(245.0, 248.0, 252.0) * 0.6;
        }
    }
    return base;
}

vec3 floor_tex(float fx, float fy, float rd) {
    float ix = floor(fx);
    float iy = floor(fy);
    float fu = fx - ix;
    float fv = fy - iy;
    float h = _hash(ix, iy);
    bool line = (fu < 0.025) || (fv < 0.025) || (fu > 0.975) || (fv > 0.975);
    bool fine_line = (mod(fx * 4.0, 1.0) < 0.012) || (mod(fy * 4.0, 1.0) < 0.012);
    float shade = (line ? 0.54 : 1.0) * (fine_line ? 0.88 : 1.0) * (0.84 + 0.16 * h);
    vec3 base = vec3(122.0, 116.0, 106.0);
    if (u_theme == 8) base = vec3(200.0, 210.0, 220.0);
    else if (u_theme == 9) base = vec3(110.0, 105.0, 100.0);
    return base * shade;
}

vec3 ceil_tex(float fx, float fy, float cd) {
    float fu = fract(fx);
    float fv = fract(fy);
    bool line = (fu < 0.04) || (fv < 0.04);
    bool panel = (mod(fx, 2.0) < 0.035) || (mod(fy, 2.0) < 0.035);
    float shade = line ? 0.68 : (panel ? 0.88 : 1.0);
    vec3 base = vec3(84.0, 86.0, 98.0) * shade;
    float lu = mod(fx, 4.0);
    float lv = mod(fy, 4.0);
    bool lamp = (abs(lu - 2.0) < 0.38) && (abs(lv - 2.0) < 0.38);
    if (lamp) base = vec3(255.0, 248.0, 225.0);
    return base;
}

void main() {
    float rw = u_resolution.x;
    float rh = u_resolution.y;
    float half_rh = rh * 0.5;
    float th = tan(u_fov * 0.5);
    float projx = (rw * 0.5) / th;
    float horizon = half_rh + u_pitch * projx;

    float col = gl_FragCoord.x / rw * 2.0 - 1.0;
    float fx = cos(u_yaw) + (-sin(u_yaw)) * col * th;
    float fy = sin(u_yaw) + cos(u_yaw) * col * th;
    float ypix = gl_FragCoord.y;

    vec3 color = vec3(0.0);
    float depth_out = MAXD;

    if (ypix >= horizon) {
        float ys = max(ypix + 0.5 - horizon, 0.01);
        float rd = EYE * projx / ys;
        float fxw = u_player.x + rd * fx;
        float fyw = u_player.y + rd * fy;
        color = floor_tex(fxw, fyw, rd);
        depth_out = rd;
    } else {
        float yc = max(horizon - (ypix + 0.5), 0.01);
        float cd = (HW - EYE) * projx / yc;
        float cxw = u_player.x + cd * fx;
        float cyw = u_player.y + cd * fy;
        color = ceil_tex(cxw, cyw, cd);
        depth_out = cd;
    }

    int mapx = int(floor(u_player.x));
    int mapy = int(floor(u_player.y));
    float ddx = abs(1.0 / (abs(fx) < 0.0000001 ? 0.0000001 : fx));
    float ddy = abs(1.0 / (abs(fy) < 0.0000001 ? 0.0000001 : fy));
    int stepx = fx < 0.0 ? -1 : 1;
    int stepy = fy < 0.0 ? -1 : 1;
    float sdx = (fx < 0.0 ? (u_player.x - float(mapx)) * ddx : (float(mapx + 1) - u_player.x) * ddx);
    float sdy = (fy < 0.0 ? (u_player.y - float(mapy)) * ddy : (float(mapy + 1) - u_player.y) * ddy);
    float t = MAXD;
    int side = 0;
    int val = 0;
    bool hit = false;
    for (int i = 0; i < 70; i++) {
        if (sdx < sdy) {
            t = sdx;
            sdx += ddx;
            mapx += stepx;
            side = 0;
        } else {
            t = sdy;
            sdy += ddy;
            mapy += stepy;
            side = 1;
        }
        if (t > MAXD) break;
        int cell = cell_at(mapx, mapy);
        if (cell > 0) {
            val = cell;
            hit = true;
            break;
        }
    }
    if (hit) {
        t = max(t, 0.02);
        float wallx = side == 0 ? u_player.y + t * fy : u_player.x + t * fx;
        float above = (HW - EYE) * projx / t;
        float below = EYE * projx / t;
        float top = horizon - above;
        float bot = horizon + below;
        if (ypix >= top && ypix < bot) {
            float zw = EYE - (ypix + 0.5 - horizon) * t / projx;
            vec3 col2;
            if (val == 1) {
                col2 = brick_tex(wallx, zw);
            } else {
                col2 = material_tex(wallx, zw, val, u_theme);
            }
            float base_shade;
            if (side == 0) {
                base_shade = stepx > 0 ? 0.68 : 0.80;
            } else {
                base_shade = stepy > 0 ? 0.92 : 1.0;
            }
            float fog = clamp(1.12 - t / 22.0, 0.10, 1.0);
            color = col2 * base_shade * fog;
            depth_out = t;
        }
    }

    float fog_final = clamp(1.12 - depth_out / 26.0, 0.10, 1.0);
    color *= fog_final;
    gl_FragColor = vec4(color / 255.0, 1.0);
}
"""


# Mapa de theme a entero (debe coincidir con el orden del shader).
THEME_INDEX = {
    "desert": 0, "temple": 1, "reactor": 2, "town": 3, "palace": 4,
    "warehouse": 5, "highway": 6, "rail": 7, "snow": 8, "castle": 9,
}


class GLRenderer:
    """Renderizador OpenGL del mundo. Devuelve (img, depth) como numpy,
    compatible con la salida de Scene.render_world() para que draw_boxes
    y el resto del pipeline CPU sigan funcionando sin cambios.

    Uso:
        gl = GLRenderer(grid, theme, w, h)
        img, depth = gl.render_world(px, py, yaw, rw, rh, fov, pitch)
        # ... usar img/depth igual que con scene.render_world
        gl.resize(new_w, new_h)
        gl.update_grid(new_grid)  # si cambia el mapa
        gl.close()
    """

    def __init__(self, grid, theme, win_w, win_h):
        self.theme = theme
        self.theme_idx = THEME_INDEX.get(theme, 0)
        # Convertimos el grid a uint8 (0=vacio, 1=pared, 2=caja).
        # Si hubiese valores > 2 (3=metal, 4=warning, etc.) se mantienen.
        self.grid = np.asarray(grid, dtype=np.uint8)
        self.gh, self.gw = self.grid.shape
        self.win_w = win_w
        self.win_h = win_h
        # El FBO de render puede ser de menor resolucion que la ventana;
        # se actualiza en resize().
        self._fb_w = win_w
        self._fb_h = win_h
        self._init_ok = False
        self._init_gl()

    def _init_gl(self):
        """Compila shaders, crea VAO/VBO/FBO/texture. Lanza si algo falla."""
        gl = _try_import_opengl()
        if gl is None:
            raise RuntimeError("PyOpenGL no disponible")
        try:
            from OpenGL.GL import (glCreateProgram, glCreateShader,
                                    glShaderSource, glCompileShader, glAttachShader,
                                    glLinkProgram, glDeleteShader, glGetProgramiv,
                                    glGetProgramInfoLog, glGetShaderiv,
                                    glGetShaderInfoLog, glUseProgram,
                                    glGetUniformLocation, glUniform1f, glUniform1i,
                                    glUniform2f, glGenVertexArrays, glBindVertexArray,
                                    glGenFramebuffers, glBindFramebuffer,
                                    glGenTextures, glBindTexture, glTexImage2D,
                                    glTexParameteri, glTexImage2D,
                                    GL_VERTEX_SHADER, GL_FRAGMENT_SHADER,
                                    GL_COMPILE_STATUS, GL_LINK_STATUS,
                                    GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
                                    GL_TEXTURE_MIN_FILTER, GL_NEAREST,
                                    GL_TEXTURE_WRAP_S, GL_TEXTURE_WRAP_T,
                                    GL_REPEAT, GL_RED, GL_R8, GL_UNSIGNED_BYTE,
                                    GL_COLOR_ATTACHMENT0, GL_FRAMEBUFFER,
                                    GL_RENDERBUFFER, glGenRenderbuffers,
                                    glBindRenderbuffer, glRenderbufferStorage,
                                    glFramebufferRenderbuffer,
                                    glFramebufferTexture2D, glDrawArrays,
                                    glViewport, glClearColor, glClear,
                                    glGetAttribLocation,
                                    GL_COLOR_BUFFER_BIT, GL_TRIANGLES, GL_LINEAR)
        except ImportError as e:
            raise RuntimeError("PyOpenGL incompleto: %s" % e)

        # Compila vertex shader.
        vs = glCreateShader(GL_VERTEX_SHADER)
        glShaderSource(vs, _VERT_SRC)
        glCompileShader(vs)
        if not glGetShaderiv(vs, GL_COMPILE_STATUS):
            log = glGetShaderInfoLog(vs).decode(errors="replace")
            raise RuntimeError("vertex shader: %s" % log)

        # Compila fragment shader.
        fs = glCreateShader(GL_FRAGMENT_SHADER)
        glShaderSource(fs, _FRAG_SRC)
        glCompileShader(fs)
        if not glGetShaderiv(fs, GL_COMPILE_STATUS):
            log = glGetShaderInfoLog(fs).decode(errors="replace")
            raise RuntimeError("fragment shader: %s" % log)

        # Linka el programa.
        prog = glCreateProgram()
        glAttachShader(prog, vs)
        glAttachShader(prog, fs)
        glLinkProgram(prog)
        if not glGetProgramiv(prog, GL_LINK_STATUS):
            log = glGetProgramInfoLog(prog).decode(errors="replace")
            raise RuntimeError("link: %s" % log)
        glDeleteShader(vs)
        glDeleteShader(fs)
        self.prog = prog
        glUseProgram(prog)

        # Localiza uniforms.
        self.u_map = glGetUniformLocation(prog, "u_map")
        self.u_map_size = glGetUniformLocation(prog, "u_map_size")
        self.u_player = glGetUniformLocation(prog, "u_player")
        self.u_yaw = glGetUniformLocation(prog, "u_yaw")
        self.u_pitch = glGetUniformLocation(prog, "u_pitch")
        self.u_fov = glGetUniformLocation(prog, "u_fov")
        self.u_resolution = glGetUniformLocation(prog, "u_resolution")
        self.u_theme = glGetUniformLocation(prog, "u_theme")

        # 2.6.1: VBO real con 6 vertices (2 triangulos que cubren la pantalla).
        # En GLSL 1.20 no existe gl_VertexID, asi que necesitamos un VBO.
        import numpy as _np
        # 2 triangulos: (-1,-1),(1,-1),(-1,1) y (1,-1),(1,1),(-1,1)
        # pos(2) + uv(2) = 4 floats por vertice, 6 vertices = 24 floats.
        quad = _np.array([
            -1, -1,  0, 0,   # tri 1 vert 0
             1, -1,  1, 0,   # tri 1 vert 1
            -1,  1,  0, 1,   # tri 1 vert 2
             1, -1,  1, 0,   # tri 2 vert 0
             1,  1,  1, 1,   # tri 2 vert 1
            -1,  1,  0, 1,   # tri 2 vert 2
        ], dtype=_np.float32)
        try:
            from OpenGL.GL import (glGenBuffers, glBindBuffer, glBufferData,
                                    glEnableVertexAttribArray, glVertexAttribPointer,
                                    GL_ARRAY_BUFFER, GL_STATIC_DRAW, GL_FLOAT)
            self.vbo = glGenBuffers(1)
            glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
            glBufferData(GL_ARRAY_BUFFER, quad.nbytes, quad, GL_STATIC_DRAW)
            # a_pos = atributo 0 (2 floats), a_uv = atributo 1 (2 floats).
            stride = 4 * 4  # 4 floats * 4 bytes = 16 bytes
            glEnableVertexAttribArray(0)
            glVertexAttribPointer(0, 2, GL_FLOAT, False, stride, None)
            glEnableVertexAttribArray(1)
            glVertexAttribPointer(1, 2, GL_FLOAT, False, stride, _np.ctypeslib.as_ctypes(_np.uintp(8)))
        except Exception as e:
            raise RuntimeError("VBO init failed: %s" % e)
        # Localizar attributos.
        self.a_pos = glGetAttribLocation(prog, "a_pos")
        self.a_uv = glGetAttribLocation(prog, "a_uv")

        # Textura del mapa: R8 (un canal de byte).
        self.map_tex = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, self.map_tex)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
        self._upload_grid()

        # Framebuffer + renderbuffer de profundidad + textura de color
        # para renderizar offscreen y luego leer el resultado a numpy.
        self._init_fbo()
        self._init_ok = True

    def _upload_grid(self):
        """Sube el grid actual a la textura del mapa."""
        try:
            from OpenGL.GL import (glBindTexture, glTexImage2D, GL_TEXTURE_2D,
                                    GL_RED, GL_UNSIGNED_BYTE)
        except ImportError:
            return
        # PyOpenGL espera (h, w, c) o un buffer de bytes plano.
        # grid es [gh, gw] uint8: se sube directo.
        glBindTexture(GL_TEXTURE_2D, self.map_tex)
        # internalformat=R8 (1 canal byte); algunos perfiles de PyOpenGL
        # no exponen GL_R8 como constante pero GL si lo acepta como entero.
        # Usamos GL_RED como internalformat que es el alias clasico y
        # funciona en todos los drivers modernos.
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RED, self.gw, self.gh, 0,
                     GL_RED, GL_UNSIGNED_BYTE, self.grid.tobytes())

    def _init_fbo(self):
        try:
            from OpenGL.GL import (glGenFramebuffers, glBindFramebuffer,
                                    glGenTextures, glBindTexture, glTexImage2D,
                                    glTexParameteri, glFramebufferTexture2D,
                                    glGenRenderbuffers, glBindRenderbuffer,
                                    glRenderbufferStorage, glFramebufferRenderbuffer,
                                    GL_TEXTURE_2D, GL_COLOR_ATTACHMENT0,
                                    GL_FRAMEBUFFER, GL_RENDERBUFFER,
                                    GL_DEPTH_COMPONENT24, GL_DEPTH_ATTACHMENT,
                                    GL_TEXTURE_MAG_FILTER, GL_TEXTURE_MIN_FILTER,
                                    GL_NEAREST, GL_RGB, GL_UNSIGNED_BYTE)
        except ImportError as e:
            raise RuntimeError("FBO init: %s" % e)
        self.fbo = glGenFramebuffers(1)
        glBindFramebuffer(GL_FRAMEBUFFER, self.fbo)
        # Textura de color RGB.
        self.color_tex = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, self.color_tex)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, self._fb_w, self._fb_h, 0,
                     GL_RGB, GL_UNSIGNED_BYTE, None)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                                GL_TEXTURE_2D, self.color_tex, 0)
        # Renderbuffer de profundidad (no se usa para z-test en CPU, pero
        # OpenGL requiere que el FBO este completo).
        self.rb = glGenRenderbuffers(1)
        glBindRenderbuffer(GL_RENDERBUFFER, self.rb)
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24,
                              self._fb_w, self._fb_h)
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                                    GL_RENDERBUFFER, self.rb)

    def resize(self, win_w, win_h):
        """Cambia el tamano del framebuffer interno. Llamar al redimensionar."""
        if win_w == self._fb_w and win_h == self._fb_h:
            return
        self.win_w = win_w
        self.win_h = win_h
        self._fb_w = win_w
        self._fb_h = win_h
        # Reconstruye el FBO al nuevo tamano.
        try:
            self._init_fbo()
        except Exception:
            # Si falla el resize, marcamos como no init y render() caera.
            self._init_ok = False

    def update_grid(self, grid, theme=None):
        """Recarga el mapa cuando se cambia de arena."""
        new_grid = np.asarray(grid, dtype=np.uint8)
        if new_grid.shape != self.grid.shape:
            self.grid = new_grid
            self.gh, self.gw = new_grid.shape
            self._upload_grid()
        elif not np.array_equal(new_grid, self.grid):
            self.grid = new_grid
            self._upload_grid()
        if theme is not None:
            self.theme = theme
            self.theme_idx = THEME_INDEX.get(theme, 0)

    def render_world(self, px, py, yaw, rw, rh, fov, pitch=0.0):
        """Ejecuta el shader y devuelve (img, depth) como numpy float32.
        La GPU no nos da depth buffer en float facilmente, asi que lo
        aproximamos con una pasada corta: aqui solo devolvemos el color
        y un depth aproximado a partir del color del cielo/suelo. El
        draw_boxes CPU va a refinar el depth leyendo del framebuffer de
        profundidad si esta disponible; si no, usa un depth grande para
        que todo se dibuje encima.
        """
        if not self._init_ok:
            # Fallback: devuelve img negro y depth infinito. El llamador
            # deberia haber comprobado is_available() antes.
            img = np.zeros((rh, rw, 3), np.float32)
            depth = np.full((rh, rw), 60.0, np.float32)
            return img, depth
        try:
            from OpenGL.GL import (glUseProgram, glUniform1f, glUniform1i,
                                    glUniform2f, glBindTexture, glActiveTexture,
                                    glViewport, glClearColor, glClear,
                                    glDrawArrays, glReadPixels, glBindFramebuffer,
                                    glFinish,
                                    GL_TEXTURE0, GL_TEXTURE_2D,
                                    GL_COLOR_BUFFER_BIT, GL_DEPTH_BUFFER_BIT,
                                    GL_RGB, GL_UNSIGNED_BYTE,
                                    GL_FRAMEBUFFER, GL_TRIANGLES,
                                    GL_DEPTH_COMPONENT)
        except ImportError:
            self._init_ok = False
            img = np.zeros((rh, rw, 3), np.float32)
            depth = np.full((rh, rw), 60.0, np.float32)
            return img, depth

        # El FBO se crea con tamano de ventana, pero el shader renderiza al
        # tamano pedido (rw, rh). Si (rw, rh) es menor, usamos el FBO a
        # tamano completo y luego cropeamos/escalamos. Lo mas simple:
        # ajustar el viewport a (rw, rh) y leer de ahi.
        if rw != self._fb_w or rh != self._fb_h:
            # Reservar FBO a este tamano exacto si cambio.
            # Evitar resize por frame: si el cambio es estable (mismo div),
            # el costo solo se paga la primera vez.
            self._fb_w = rw
            self._fb_h = rh
            try:
                self._init_fbo()
            except Exception:
                pass

        glBindFramebuffer(GL_FRAMEBUFFER, self.fbo)
        glViewport(0, 0, rw, rh)
        glClearColor(0.0, 0.0, 0.0, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        glUseProgram(self.prog)
        glUniform2f(self.u_player, float(px), float(py))
        glUniform1f(self.u_yaw, float(yaw))
        glUniform1f(self.u_pitch, float(pitch))
        glUniform1f(self.u_fov, float(fov))
        glUniform2f(self.u_resolution, float(rw), float(rh))
        glUniform1i(self.u_theme, int(self.theme_idx))
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, self.map_tex)
        glUniform1i(self.u_map, 0)
        glUniform2f(self.u_map_size, float(self.gw), float(self.gh))

        glDrawArrays(GL_TRIANGLES, 0, 6)
        glFinish()

        # Lee el framebuffer a numpy.
        # glReadPixels devuelve bytes RGB en orden de filas inferior->superior,
        # asi que hay que voltear verticalmente para que cuadre con el
        # array (rh, rw, 3) que espera el resto del pipeline.
        # IMPORTANTE: glPixelStorei(GL_PACK_ALIGNMENT, 1) para que no haya
        # padding entre filas (por defecto OpenGL alinea a 4 bytes, lo que
        # corrompe lecturas de anchos no multiplos de 4).
        try:
            from OpenGL.GL import glPixelStorei, GL_PACK_ALIGNMENT
            glPixelStorei(GL_PACK_ALIGNMENT, 1)
        except ImportError:
            pass
        raw = glReadPixels(0, 0, rw, rh, GL_RGB, GL_UNSIGNED_BYTE)
        img = np.frombuffer(raw, dtype=np.uint8).reshape(rh, rw, 3)
        img = np.flipud(img).copy().astype(np.float32)
        # El depth real esta en el depth buffer. Para evitar pedir
        # GL_DEPTH_COMPONENT (que requiere formato float y es lento de
        # leer), aproximamos: el color del pixel ya nos dice si es pared
        # cercana (color oscuro y detallado) o suelo/techo lejano. Para
        # que draw_boxes CPU (personajes, props) funcione, le damos un
        # depth por defecto alto (60.0 = lejos) en cielo/suelo/techo,
        # y un valor menor en las paredes. La correccion fina la hace el
        # z-test de draw_boxes comparando con su propio t.
        # Estrategia simple: depth uniforme alto. draw_boxes compara
        # contra depth[y0:y1,x0:x1].max() >= dep.min(); si depth es alto
        # (60), la condicion siempre es cierta y las cajas se dibujan
        # encima. Esto puede ocasionar que un personaje detras de una
        # pared se vea a traves de ella. Para evitarlo, aproximamos depth
        # de la pared con un valor bajo (0.01) solo en los pixeles que
        # el shader pinto como pared (los que no son suelo/techo).
        # Heuristica: el shader pinta suelo/techo con colores base muy
        # especificos (suelo gris-marron, techo azul). Cualquier otra
        # cosa es pared. Es una aproximacion, no perfecta.
        # Mejor enfoque: leer depth buffer real. Es mas lento pero
        # correcto. Lo hacemos solo si el FBO soporta GL_DEPTH_COMPONENT.
        try:
            depth_raw = glReadPixels(0, 0, rw, rh, GL_DEPTH_COMPONENT, GL_UNSIGNED_BYTE)
            depth = np.frombuffer(depth_raw, dtype=np.uint8).reshape(rh, rw)
            depth = np.flipud(depth).copy().astype(np.float32) / 255.0 * 60.0
        except Exception:
            # Si la lectura de profundidad falla, usamos depth uniforme
            # alto. draw_boxes va a dibujar las cajas encima.
            depth = np.full((rh, rw), 60.0, np.float32)
        return img, depth

    def close(self):
        """Libera recursos GL. Llamar al salir."""
        if not self._init_ok:
            return
        try:
            from OpenGL.GL import glDeleteProgram, glDeleteTextures, glDeleteFramebuffers
            glDeleteProgram(self.prog)
            glDeleteTextures([self.map_tex, self.color_tex])
            glDeleteFramebuffers(1, [self.fbo])
        except Exception:
            pass
        self._init_ok = False
