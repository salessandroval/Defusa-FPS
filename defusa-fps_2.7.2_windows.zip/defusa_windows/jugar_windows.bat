@echo off
chcp 65001 >nul 2>&1
title Defusa FPS

REM Jugar Defusa FPS directamente con Python (sin compilar .exe).
REM Si Python no esta instalado, muestra un mensaje de error.

python --version >nul 2>&1
if errorlevel 1 (
    echo Python no esta instalado en esta PC.
    echo.
    echo Opciones:
    echo   1. Instala Python desde https://www.python.org/downloads/
    echo      Marca "Add Python to PATH" durante la instalacion.
    echo      Despues instala las dependencias:
    echo        pip install pygame-ce numpy PyOpenGL
    echo      Y vuelve a ejecutar este archivo.
    echo.
    echo   2. O usa install_windows.bat para crear un .exe standalone.
    echo.
    pause
    exit /b 1
)

REM Verifica las dependencias.
python -c "import pygame, numpy" >nul 2>&1
if errorlevel 1 (
    echo Faltan dependencias de Python. Instalando...
    pip install pygame-ce numpy PyOpenGL
    if errorlevel 1 (
        echo No se pudieron instalar las dependencias.
        pause
        exit /b 1
    )
)

REM Arranca el juego.
python defusa.py %*
