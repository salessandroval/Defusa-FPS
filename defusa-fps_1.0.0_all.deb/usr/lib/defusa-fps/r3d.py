# -*- coding: utf-8 -*-
"""Motor 3D por software (numpy) de Defusa FPS.

- Mundo: paredes, suelo y techo con perspectiva y texturas procedurales.
- Objetos: cajas orientadas (personajes, armas, bomba) trazadas rayo a rayo con z-buffer.
Todo es geometría sencilla generada por código: no usa ningún recurso externo.
"""
import math

import numpy as np

HW = 1.6          # altura de las paredes
EYE = 0.95        # altura de los ojos
NEAR = 0.04
LIGHT = np.array([-0.35, -0.55, 0.75], np.float32)
LIGHT /= np.linalg.norm(LIGHT)

GLYPHS = {
    "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."],
}
TINT = np.array([(0, 0, 0), (215, 170, 40), (215, 170, 40), (200, 110, 60), (60, 100, 200)], np.float32)
AMT = np.array([0.0, 0.42, 0.42, 0.20, 0.20], np.float32)

COLORS = {"M": (62, 62, 68), "D": (34, 34, 38), "W": (128, 82, 44), "S": (160, 162, 170),
          "G": (72, 92, 62), "L": (120, 170, 230), "F": (255, 235, 120)}
EMISSIVE = {"L", "F"}

# (cx, cy, cz, hx, hy, hz, pitch_grados, color)   x=adelante  y=derecha  z=arriba
WEAPON_MODELS = {
    "usp": {"grip": (-0.005, 0, -0.03), "fore": (0.04, 0, -0.03), "muzzle": (0.16, 0, 0.03), "boxes": [
        (0.06, 0, 0.03, 0.10, 0.014, 0.020, 0, "M"), (0.05, 0, 0.005, 0.08, 0.012, 0.014, 0, "D"),
        (-0.01, 0, -0.035, 0.016, 0.013, 0.05, -12, "D")]},
    "deagle": {"grip": (-0.005, 0, -0.03), "fore": (0.05, 0, -0.03), "muzzle": (0.20, 0, 0.035), "boxes": [
        (0.08, 0, 0.035, 0.125, 0.017, 0.026, 0, "S"), (0.06, 0, 0.005, 0.09, 0.014, 0.016, 0, "M"),
        (-0.01, 0, -0.04, 0.018, 0.015, 0.055, -12, "D"), (0.14, 0, 0.065, 0.006, 0.005, 0.010, 0, "D")]},
    "mp5": {"grip": (-0.01, 0, -0.04), "fore": (0.20, 0, -0.01), "muzzle": (0.37, 0, 0.03), "boxes": [
        (0.05, 0, 0.025, 0.14, 0.018, 0.028, 0, "D"), (0.22, 0, 0.01, 0.06, 0.022, 0.022, 0, "D"),
        (0.31, 0, 0.03, 0.04, 0.008, 0.008, 0, "M"), (-0.16, 0, 0.01, 0.09, 0.012, 0.022, 5, "D"),
        (0.08, 0, -0.07, 0.010, 0.016, 0.060, 0, "D"), (-0.01, 0, -0.05, 0.014, 0.014, 0.045, -15, "D")]},
    "m3": {"grip": (-0.07, 0, -0.04), "fore": (0.22, 0, -0.005), "muzzle": (0.56, 0, 0.03), "boxes": [
        (0.28, 0, 0.03, 0.28, 0.010, 0.010, 0, "M"), (0.28, 0, 0.005, 0.26, 0.009, 0.009, 0, "M"),
        (0.22, 0, -0.005, 0.07, 0.020, 0.018, 0, "W"), (-0.02, 0, 0.02, 0.10, 0.018, 0.030, 0, "D"),
        (-0.22, 0, 0.0, 0.12, 0.015, 0.030, 6, "W"), (-0.07, 0, -0.05, 0.014, 0.014, 0.045, -15, "W")]},
    "ak47": {"grip": (-0.01, 0, -0.04), "fore": (0.30, 0, -0.01), "muzzle": (0.57, 0, 0.03), "boxes": [
        (0.06, 0, 0.03, 0.17, 0.016, 0.028, 0, "M"), (0.06, 0, 0.058, 0.14, 0.014, 0.006, 0, "M"),
        (0.30, 0, 0.015, 0.09, 0.021, 0.022, 0, "W"), (0.30, 0, 0.048, 0.09, 0.008, 0.007, 0, "M"),
        (0.46, 0, 0.03, 0.10, 0.007, 0.007, 0, "D"), (0.54, 0, 0.045, 0.005, 0.005, 0.016, 0, "D"),
        (-0.20, 0, 0.0, 0.12, 0.014, 0.030, 8, "W"), (-0.01, 0, -0.055, 0.014, 0.014, 0.045, -15, "W"),
        (0.10, 0, -0.075, 0.013, 0.017, 0.065, 20, "D")]},
    "m4a1": {"grip": (-0.01, 0, -0.04), "fore": (0.28, 0, -0.01), "muzzle": (0.50, 0, 0.025), "boxes": [
        (0.04, 0, 0.03, 0.16, 0.017, 0.030, 0, "D"), (0.28, 0, 0.025, 0.10, 0.020, 0.020, 0, "M"),
        (0.43, 0, 0.025, 0.06, 0.007, 0.007, 0, "D"), (-0.17, 0, 0.0, 0.10, 0.014, 0.028, 6, "D"),
        (0.04, 0, 0.065, 0.06, 0.008, 0.012, 0, "D"), (0.07, 0, -0.065, 0.012, 0.016, 0.055, 8, "D"),
        (-0.01, 0, -0.055, 0.014, 0.014, 0.045, -15, "D")]},
    "awp": {"grip": (-0.03, 0, -0.04), "fore": (0.22, 0, -0.01), "muzzle": (0.62, 0, 0.03), "boxes": [
        (0.0, 0, 0.02, 0.18, 0.020, 0.030, 0, "G"), (0.38, 0, 0.03, 0.20, 0.009, 0.009, 0, "D"),
        (0.59, 0, 0.03, 0.02, 0.012, 0.012, 0, "D"), (0.04, 0, 0.075, 0.10, 0.014, 0.014, 0, "D"),
        (0.145, 0, 0.075, 0.004, 0.011, 0.011, 0, "L"), (-0.22, 0, 0.0, 0.12, 0.018, 0.035, 6, "G"),
        (0.04, 0, -0.04, 0.012, 0.018, 0.040, 0, "D"), (-0.05, 0.04, 0.03, 0.012, 0.025, 0.005, 0, "D"),
        (-0.03, 0, -0.05, 0.014, 0.014, 0.045, -15, "D")]},
}

# Siluetas adicionales: se reutilizan piezas del motor para mantener el paquete ligero.
for _alias, _base in {
    "glock": "usp", "p228": "deagle", "fiveseven": "usp", "elite": "deagle",
    "xm1014": "m3", "tmp": "mp5", "mac10": "mp5", "ump45": "mp5", "p90": "mp5",
    "galil": "ak47", "famas": "m4a1", "sg552": "ak47", "aug": "m4a1",
    "scout": "awp", "g3sg1": "awp", "sg550": "awp", "m249": "m4a1",
}.items():
    WEAPON_MODELS[_alias] = WEAPON_MODELS[_base]


TEAM_LOOK = {
    "T": {"torso": (150, 110, 62), "legs": (92, 72, 42), "arms": (140, 102, 58), "head": (224, 182, 142),
          "hat": (58, 44, 30), "boots": (40, 32, 26), "glove": (40, 34, 30)},
    "C": {"torso": (52, 84, 168), "legs": (36, 46, 84), "arms": (48, 78, 158), "head": (224, 182, 142),
          "hat": (28, 38, 70), "boots": (24, 24, 30), "glove": (30, 30, 36)},
}


def _hash(a, b):
    return np.abs(np.sin(a * 12.9898 + b * 78.233) * 43758.5453) % 1.0


def frame(yaw):
    c, s = math.cos(yaw), math.sin(yaw)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]], np.float32)   # columnas: adelante, derecha, arriba


def rot_pitch(deg):
    p = math.radians(deg)
    c, s = math.cos(p), math.sin(p)
    return np.array([[c, 0, -s], [0, 1, 0], [s, 0, c]], np.float32)


def limb(a, b, half, col, em=False):
    a = np.asarray(a, np.float32)
    b = np.asarray(b, np.float32)
    d = b - a
    ln = float(np.linalg.norm(d))
    if ln < 1e-6:
        return None
    z = d / ln
    ref = np.array([1.0, 0.0, 0.0], np.float32) if abs(z[0]) < 0.9 else np.array([0.0, 1.0, 0.0], np.float32)
    x = np.cross(ref, z)
    x /= np.linalg.norm(x)
    y = np.cross(z, x)
    R = np.stack([x, y, z], axis=1).astype(np.float32)
    return ((a + b) / 2, R, np.array([half, half, ln / 2], np.float32), col, em)


def weapon_boxes(name, origin, Rw, flash=False):
    m = WEAPON_MODELS.get(name, WEAPON_MODELS["usp"])
    out = []
    for (cx, cy, cz, hx, hy, hz, pit, ck) in m["boxes"]:
        c = origin + Rw @ np.array([cx, cy, cz], np.float32)
        R = Rw @ rot_pitch(pit)
        out.append((c.astype(np.float32), R, np.array([hx, hy, hz], np.float32), COLORS[ck], ck in EMISSIVE))
    if flash:
        mz = origin + Rw @ np.array(m["muzzle"], np.float32)
        out.append((mz.astype(np.float32), Rw, np.array([0.02, 0.02, 0.02], np.float32), COLORS["F"], True))
    return out


def character_boxes(x, y, yaw, team, wname, phase, moving, bomb=False, head_yaw=0.0):
    L = TEAM_LOOK[team]
    Rp = frame(yaw)
    Rh = frame(yaw + float(head_yaw))
    F, Rt, U = Rp[:, 0], Rp[:, 1], Rp[:, 2]
    pos = np.array([x, y, 0.0], np.float32)
    out = []

    def box(c, e, col, R=None):
        out.append((np.asarray(c, np.float32), Rp if R is None else R, np.asarray(e, np.float32), col, False))

    sw = math.sin(phase) * 0.55 if moving else 0.0
    for side, ang in ((-1, sw), (1, -sw)):
        hip = pos + Rt * (0.075 * side) + U * 0.50
        foot = hip + F * (math.sin(ang) * 0.5) - U * (math.cos(ang) * 0.5)
        b = limb(hip, foot, 0.055, L["legs"])
        if b:
            out.append(b)
        box(foot + F * 0.035 + U * 0.03, (0.085, 0.06, 0.03), L["boots"])
    box(pos + U * 0.50, (0.08, 0.165, 0.04), L["boots"])                   # cinturón
    box(pos + U * 0.71, (0.075, 0.16, 0.21), L["torso"])                    # torso
    box(pos + U * 0.99, (0.075, 0.07, 0.08), L["head"], Rh)                     # cabeza
    box(pos + U * 1.035, (0.082, 0.077, 0.05), L["hat"], Rh)                    # casco/capucha
    head_fwd = Rh[:, 0]
    if team == "C":
        box(pos + head_fwd * 0.07 + U * 0.99, (0.012, 0.062, 0.022), (20, 20, 24), Rh)  # visor
    else:
        box(pos + head_fwd * 0.07 + U * 0.96, (0.012, 0.064, 0.030), L["hat"], Rh)      # pasamontañas
    if bomb:
        box(pos - F * 0.11 + U * 0.72, (0.05, 0.11, 0.09), (190, 40, 40))
    # arma y brazos
    m = WEAPON_MODELS.get(wname, WEAPON_MODELS["usp"])
    org = pos + F * 0.17 + Rt * 0.07 + U * 0.76
    out.extend(weapon_boxes(wname, org, Rp))
    hr = org + Rp @ np.array(m["grip"], np.float32)
    hl = org + Rp @ np.array(m["fore"], np.float32)
    for side, hand in ((1, hr), (-1, hl)):
        sh = pos + Rt * (0.20 * side) + U * 0.87
        el = (sh + hand) / 2 - U * 0.06 + Rt * (0.04 * side)
        for a, b in ((sh, el), (el, hand)):
            bl = limb(a, b, 0.042, L["arms"])
            if bl:
                out.append(bl)
        box(hand, (0.04, 0.04, 0.04), L["glove"])
    return out


def bomb_boxes(x, y, planted, blink):
    c = np.array([x, y, 0.0], np.float32)
    I = np.eye(3, dtype=np.float32)
    out = [(c + np.array([0, 0, 0.05], np.float32), I, np.array([0.13, 0.09, 0.05], np.float32), (48, 66, 42), False),
           (c + np.array([-0.05, 0, 0.105], np.float32), I, np.array([0.045, 0.035, 0.006], np.float32),
            (110, 255, 110) if planted else (70, 110, 70), planted),
           (c + np.array([0.06, 0, 0.105], np.float32), I, np.array([0.016, 0.016, 0.010], np.float32),
            (255, 40, 40) if (blink or not planted) else (90, 15, 15), bool(blink or not planted))]
    return out


class Scene:
    def __init__(self, grid, sites, spawns):
        self.grid = np.array(grid, dtype=np.int8)
        self.gh, self.gw = self.grid.shape
        self.kind = np.zeros(self.grid.shape, np.int8)
        for k, (x0, y0, x1, y1) in sites.items():
            self.kind[y0:y1 + 1, x0:x1 + 1] = 1 if k == "A" else 2
        for (x, y) in spawns["T"]:
            self.kind[y, x] = 3
        for (x, y) in spawns["C"]:
            self.kind[y, x] = 4
        self.sites = {k: ((x0 + x1 + 1) / 2.0, (y0 + y1 + 1) / 2.0) for k, (x0, y0, x1, y1) in sites.items()}
        self.glyph = {k: np.array([[ch == "#" for ch in row] for row in rows]) for k, rows in GLYPHS.items()}

    # ------------------------------------------------------------ mundo
    def render_world(self, px, py, yaw, rw, rh, fov, pitch=0.0):
        th = math.tan(fov / 2)
        projx = (rw / 2) / th
        half = rh // 2
        horizon = half + float(pitch) * projx
        fx, fy = math.cos(yaw), math.sin(yaw)
        rx, ry = -math.sin(yaw), math.cos(yaw)
        cols = ((np.arange(rw) + 0.5) / rw * 2 - 1).astype(np.float32)
        dx = (fx + rx * cols * th).astype(np.float32)
        dy = (fy + ry * cols * th).astype(np.float32)
        img = np.empty((rh, rw, 3), np.float32)
        depth = np.empty((rh, rw), np.float32)

        # suelo y techo con horizonte vertical para permitir mirar arriba/abajo
        fy0 = int(np.clip(math.ceil(horizon), 0, rh))
        if fy0 < rh:
            ys = np.arange(fy0, rh, dtype=np.float32) + 0.5 - horizon
            ys = np.maximum(ys, 0.01)
            rd = EYE * projx / ys
            fxw = px + rd[:, None] * dx[None, :]
            fyw = py + rd[:, None] * dy[None, :]
            img[fy0:] = self._floor(fxw, fyw, rd)
            depth[fy0:] = rd[:, None]
        cy1 = int(np.clip(math.ceil(horizon), 0, rh))
        if cy1 > 0:
            yc = horizon - (np.arange(0, cy1, dtype=np.float32) + 0.5)
            yc = np.maximum(yc, 0.01)
            cd = (HW - EYE) * projx / yc
            cxw = px + cd[:, None] * dx[None, :]
            cyw = py + cd[:, None] * dy[None, :]
            img[:cy1] = self._ceil(cxw, cyw, cd)
            depth[:cy1] = cd[:, None]

        # paredes (DDA vectorizado)
        mapx = np.full(rw, int(math.floor(px)), np.int32)
        mapy = np.full(rw, int(math.floor(py)), np.int32)
        ddx = np.abs(1.0 / np.where(np.abs(dx) < 1e-9, 1e-9, dx))
        ddy = np.abs(1.0 / np.where(np.abs(dy) < 1e-9, 1e-9, dy))
        stepx = np.where(dx < 0, -1, 1).astype(np.int32)
        stepy = np.where(dy < 0, -1, 1).astype(np.int32)
        sdx = np.where(dx < 0, (px - mapx) * ddx, (mapx + 1 - px) * ddx)
        sdy = np.where(dy < 0, (py - mapy) * ddy, (mapy + 1 - py) * ddy)
        t = np.full(rw, 60.0, np.float32)
        side = np.zeros(rw, np.int8)
        val = np.zeros(rw, np.int8)
        hit = np.zeros(rw, bool)
        for _ in range(70):
            xs = sdx < sdy
            tc = np.where(xs, sdx, sdy)
            mapx = np.clip(mapx + np.where(xs, stepx, 0), 0, self.gw - 1)
            mapy = np.clip(mapy + np.where(xs, 0, stepy), 0, self.gh - 1)
            sdx = np.where(xs, sdx + ddx, sdx)
            sdy = np.where(xs, sdy, sdy + ddy)
            cell = self.grid[mapy, mapx]
            new = (~hit) & (cell > 0)
            if new.any():
                t[new] = tc[new]
                side[new] = np.where(xs, 0, 1)[new]
                val[new] = cell[new]
                hit |= new
                if hit.all():
                    break
        t = np.maximum(t, 0.02)
        wallx = np.where(side == 0, py + t * dy, px + t * dx).astype(np.float32)
        above = (HW - EYE) * projx / t
        below = EYE * projx / t
        top, bot = horizon - above, horizon + below
        Y = (np.arange(rh, dtype=np.float32) + 0.5)[:, None]
        mask = (Y >= top[None, :]) & (Y < bot[None, :])
        yy, xx = np.nonzero(mask)
        if len(yy):
            zw = EYE - (yy + 0.5 - horizon) * t[xx] / projx
            wx = wallx[xx]
            v = val[xx]
            col = np.empty((len(yy), 3), np.float32)
            m1 = v == 1
            if m1.any():
                col[m1] = self._brick(wx[m1], zw[m1])
            m2 = ~m1
            if m2.any():
                col[m2] = self._crate(wx[m2], zw[m2])
            base = np.where(side == 0, np.where(stepx > 0, 0.68, 0.80), np.where(stepy > 0, 0.92, 1.0))
            sh = (base * np.clip(1.12 - t / 22.0, 0.10, 1.0)).astype(np.float32)
            col *= sh[xx][:, None]
            img[yy, xx] = col
            depth[yy, xx] = t[xx]
        return img, depth

    @staticmethod
    def _brick(wx, zw):
        rowf = zw / 0.22
        row = np.floor(rowf)
        bx = (wx + (row % 2) * 0.275) / 0.55
        bi = np.floor(bx)
        fb = bx - bi
        fr = rowf - row
        mortar = (fb < 0.05) | (fr < 0.10)
        h = _hash(bi, row)
        col = np.empty((len(wx), 3), np.float32)
        col[:] = (176, 150, 118)
        col *= (0.80 + 0.27 * h)[:, None]
        # Borde ligeramente oscuro para dar volumen a cada ladrillo.
        bevel = (fb < 0.075) | (fr < 0.14) | (fb > 0.94)
        col[bevel & ~mortar] *= 0.88
        col[mortar] = (105, 99, 92)
        col[zw < 0.12] *= 0.72
        col[zw > HW - 0.10] *= 0.80
        return col

    @staticmethod
    def _crate(wx, zw):
        uu = wx - np.floor(wx)
        vv = zw - np.floor(zw)
        border = (uu < 0.09) | (uu > 0.91) | (vv < 0.09) | (vv > 0.91)
        diag = (np.abs(uu - vv) < 0.06) | (np.abs(uu + vv - 1) < 0.06)
        plank = (uu * 7) % 1.0 < 0.06
        h = _hash(np.floor(wx), np.floor(zw))
        col = np.empty((len(wx), 3), np.float32)
        col[:] = (164, 112, 56)
        col *= (0.86 + 0.22 * h)[:, None]
        col[plank] *= 0.85
        col[diag] = (128, 86, 42)
        col[border] = (104, 68, 32)
        return col

    def _floor(self, fx, fy, rd):
        ix, iy = np.floor(fx), np.floor(fy)
        fu, fv = fx - ix, fy - iy
        ixi = np.clip(ix.astype(np.int32), 0, self.gw - 1)
        iyi = np.clip(iy.astype(np.int32), 0, self.gh - 1)
        h = _hash(ix, iy)
        line = (fu < 0.025) | (fv < 0.025) | (fu > 0.975) | (fv > 0.975)
        fine_line = ((fx * 4.0) % 1.0 < 0.012) | ((fy * 4.0) % 1.0 < 0.012)
        shade = np.where(line, 0.54, 1.0) * np.where(fine_line, 0.88, 1.0) * (0.84 + 0.16 * h)
        col = np.empty(fx.shape + (3,), np.float32)
        col[...] = (122, 116, 106)
        col *= shade[..., None].astype(np.float32)
        kind = self.kind[iyi, ixi]
        amt = AMT[kind][..., None]
        col = col * (1 - amt) + TINT[kind] * amt
        for k, (cx, cy) in self.sites.items():
            sid = 1 if k == "A" else 2
            m = kind == sid
            if not m.any():
                continue
            s = 0.45
            row = np.floor((cx + 3.5 * s - fx[m]) / s).astype(np.int32)
            cc = np.floor((fy[m] - (cy - 2.5 * s)) / s).astype(np.int32)
            inside = (row >= 0) & (row < 7) & (cc >= 0) & (cc < 5)
            bit = np.zeros(len(row), bool)
            bit[inside] = self.glyph[k][row[inside], cc[inside]]
            if bit.any():
                sub = col[m]
                sub[bit] = (225, 50, 35)
                col[m] = sub
        col *= np.clip(1.12 - rd / 22.0, 0.10, 1.0)[:, None, None].astype(np.float32)
        return col

    def _ceil(self, fx, fy, cd):
        ix, iy = np.floor(fx), np.floor(fy)
        fu, fv = fx - ix, fy - iy
        line = (fu < 0.04) | (fv < 0.04)
        col = np.empty(fx.shape + (3,), np.float32)
        col[...] = (84, 86, 98)
        panel = ((fx % 2.0) < 0.035) | ((fy % 2.0) < 0.035)
        col *= np.where(line, 0.68, np.where(panel, 0.88, 1.0))[..., None].astype(np.float32)
        col *= np.clip(1.12 - cd / 24.0, 0.12, 1.0)[:, None, None].astype(np.float32)
        lu, lv = fx % 4.0, fy % 4.0
        lamp = (np.abs(lu - 2.0) < 0.38) & (np.abs(lv - 2.0) < 0.38)
        col[lamp] = (255, 248, 225)
        return col

    # ------------------------------------------------------------ cajas
    @staticmethod
    def make_cam(px, py, pz, yaw, rw, fov, pitch=0.0):
        projx = (rw / 2) / math.tan(fov / 2)
        pos = np.array([px, py, pz], np.float32)
        cp, sp = math.cos(pitch), math.sin(pitch)
        cy, sy = math.cos(yaw), math.sin(yaw)
        fwd = np.array([cy * cp, sy * cp, sp], np.float32)
        right = np.array([-sy, cy, 0.0], np.float32)
        up = np.cross(fwd, right).astype(np.float32)
        return (pos, fwd, right, up, projx)

    @staticmethod
    def project(cam, p, rw, rh):
        pos, fwd, right, up, projx = cam
        rel = np.asarray(p, np.float32) - pos
        dep = float(rel @ fwd)
        if dep < NEAR:
            return None
        return rw / 2 + float(rel @ right) / dep * projx, rh / 2 - float(rel @ up) / dep * projx, dep

    _SIGNS = np.array([[sx, sy, sz] for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)], np.float32)

    def visible(self, cam, center, radius, hz, depth, rw, rh):
        """Prueba rápida de oclusión/encuadre de un grupo de cajas (cilindro envolvente)."""
        pos, fwd, right, up, projx = cam
        c = np.asarray(center, np.float32)
        corners = c + self._SIGNS * np.array([radius, radius, hz], np.float32)
        rel = corners - pos
        dep = rel @ fwd
        if dep.max() < NEAR:
            return False
        if dep.min() < NEAR:
            return True
        sx = rw / 2 + (rel @ right) / dep * projx
        sy = rh / 2 - (rel @ up) / dep * projx
        x0, x1 = max(0, int(sx.min())), min(rw, int(sx.max()) + 2)
        y0, y1 = max(0, int(sy.min())), min(rh, int(sy.max()) + 2)
        if x1 <= x0 or y1 <= y0:
            return False
        return bool(depth[y0:y1, x0:x1].max() >= dep.min())

    def draw_boxes(self, img, depth, cam, boxes, rw, rh, fogd=22.0):
        pos, fwd, right, up, projx = cam
        for (c, R, e, col, em) in boxes:
            corners = c + (self._SIGNS * e) @ R.T
            rel = corners - pos
            dep = rel @ fwd
            if dep.max() < NEAR:
                continue
            if dep.min() < NEAR:
                x0, x1, y0, y1 = 0, rw, 0, rh
            else:
                sx = rw / 2 + (rel @ right) / dep * projx
                sy = rh / 2 - (rel @ up) / dep * projx
                x0, x1 = max(0, int(math.floor(sx.min()))), min(rw, int(math.ceil(sx.max())) + 1)
                y0, y1 = max(0, int(math.floor(sy.min()))), min(rh, int(math.ceil(sy.max())) + 1)
            if x1 <= x0 or y1 <= y0:
                continue
            zr = depth[y0:y1, x0:x1]
            if zr.max() < dep.min():
                continue
            Xp = ((np.arange(x0, x1, dtype=np.float32) + 0.5 - rw / 2) / projx)[None, :]
            Yp = (-(np.arange(y0, y1, dtype=np.float32) + 0.5 - rh / 2) / projx)[:, None]
            va, vb, vc = fwd @ R, right @ R, up @ R             # ejes de la cámara en espacio local
            ol = (pos - c) @ R
            dls = []
            tn = tf = ax = None
            for i in range(3):
                di = va[i] + Xp * vb[i] + Yp * vc[i]
                dls.append(di)
                inv = 1.0 / np.where(np.abs(di) < 1e-9, np.float32(1e-9), di)
                ta = (-e[i] - ol[i]) * inv
                tb = (e[i] - ol[i]) * inv
                lo = np.minimum(ta, tb)
                hi = np.maximum(ta, tb)
                if i == 0:
                    tn, tf, ax = lo, hi, np.zeros(lo.shape, np.int8)
                else:
                    ax = np.where(lo > tn, np.int8(i), ax)
                    tn = np.maximum(tn, lo)
                    tf = np.minimum(tf, hi)
            hit = (tn < tf) & (tn > NEAR) & (tn < zr)
            if not hit.any():
                continue
            hy, hx = np.nonzero(hit)
            axh = ax[hit]
            tnh = tn[hit]
            dh = np.stack([dls[0][hit], dls[1][hit], dls[2][hit]], axis=-1)
            sign = -np.sign(dh[np.arange(len(axh)), axh])
            nrm = R[:, axh].T * sign[:, None]                   # normal en el mundo
            if em:
                shade = np.ones(len(axh), np.float32)
            else:
                shade = 0.55 + 0.62 * np.clip(nrm @ LIGHT, 0.0, 1.0)
                p = (ol + tnh[:, None] * dh) / e
                edge = (np.abs(p) > 0.88).sum(-1) >= 2
                shade = np.where(edge, shade * 0.72, shade)
                shade = shade * np.clip(1.12 - tnh / fogd, 0.14, 1.0)
            img[y0 + hy, x0 + hx] = np.asarray(col, np.float32) * shade[:, None]
            depth[y0 + hy, x0 + hx] = tnh

    # ------------------------------------------------------------ arma en primera persona
    def draw_fp(self, img, rw, rh, fov, wname, team, rec, bob, reload_frac, flash):
        cam = self.make_cam(0.0, 0.0, 0.0, 0.0, rw, fov)
        depth = np.full((rh, rw), 1e9, np.float32)
        L = TEAM_LOOK[team]
        Rw = frame(math.radians(-5.0)) @ rot_pitch(2.0 + rec * 7.0)
        org = np.array([0.46 - rec * 0.05, 0.15 + bob[0], -0.135 + bob[1] - reload_frac * 0.16], np.float32)
        boxes = weapon_boxes(wname, org, Rw, flash=flash)
        m = WEAPON_MODELS.get(wname, WEAPON_MODELS["usp"])
        hr = org + Rw @ np.array(m["grip"], np.float32)
        hl = org + Rw @ np.array(m["fore"], np.float32)
        for hand, start in ((hr, (0.05, 0.34, -0.45)), (hl, (0.05, -0.08, -0.45))):
            for a, b, hf in ((np.array(start, np.float32), hand, 0.040),):
                bl = limb(a, b, hf, L["arms"])
                if bl:
                    boxes.append(bl)
            boxes.append((hand, np.eye(3, dtype=np.float32), np.array([0.032, 0.032, 0.032], np.float32),
                          L["glove"], False))
        self.draw_boxes(img, depth, cam, boxes, rw, rh, fogd=1e9)
